class Notificacion {
  constructor({ msg, position }) {
    this.msg = msg;
    this.position = position;

    this.render();
  }

  render() {
    const notificacion = document.createElement("div");
    notificacion.className =
      "rounded border-s-4 border-red-500 bg-red-50 p-4 dark:border-red-600 dark:bg-red-900 alerta m-4";
    notificacion.innerHTML = `<strong class="block font-medium text-red-700 dark:text-red-200">${this.msg}</strong>`;

    const notificacionPrevia = document.querySelector(".alerta");
    notificacionPrevia?.remove();

    this.position.appendChild(notificacion);

    setTimeout(() => {
      notificacion.remove();
    }, 3000);
  }
}

export default Notificacion;
