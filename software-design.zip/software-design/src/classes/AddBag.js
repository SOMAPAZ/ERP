export default class AddBag {
  static #bag = [];

  static guardarLocalStorage(obj) {
    const dataLocal = this.obtenerLocalStorage();
    console.log(dataLocal);

    if (dataLocal) {
      this.#bag = [...dataLocal, obj];
    } else {
      this.#bag = [...this.#bag, obj];
    }

    localStorage.setItem("bag", JSON.stringify(this.#bag));
  }

  static obtenerLocalStorage() {
    const data = localStorage.getItem("bag");

    return JSON.parse(data);
  }
}
