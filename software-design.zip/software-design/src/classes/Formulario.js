class Formulario {
  constructor({ contenido, posicion }) {
    this.contenido = contenido;
    this.posicion = posicion;
  }

  render(actualizar = false, data = {}) {
    const bgModal = document.createElement("DIV");
    bgModal.className =
      "overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 bottom-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%)] max-h-full bg-gray-800 bg-opacity-50 dark:bg-opacity-80 modal-form";
    const contenedorModal = document.createElement("DIV");
    contenedorModal.className =
      "relative p-4 w-full max-w-2xl mx-auto mt-20 max-h-full";

    const contenido = document.createElement("DIV");
    contenido.className =
      "relative bg-white rounded-lg shadow dark:bg-gray-700";

    const header = document.createElement("DIV");
    header.className =
      "flex items-center justify-between p-4 md:p-5 border-b rounded-t dark:border-gray-600";
    const h3 = document.createElement("H3");
    h3.className = "text-xl font-semibold text-gray-900 dark:text-white";
    h3.textContent = actualizar ? "Actualizar" : "Agregar";
    header.appendChild(h3);

    const divNotificaciones = document.createElement("DIV");
    divNotificaciones.classList.add("errorVacio");

    const bodyModal = document.createElement("DIV");
    bodyModal.className = "p-4 md:p-5 space-y-4";

    // Inyectar contenido a la modal
    bodyModal.appendChild(this.contenido);
    // Fin de inyección

    const footer = document.createElement("DIV");
    footer.className =
      "flex items-center justify-end gap-4 p-4 md:p-5 border-t border-gray-200 rounded-b dark:border-gray-600";

    const btnGuardar = document.createElement("BUTTON");
    btnGuardar.className =
    "text-white bg-blue-700 hover:bg-blue-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700";
    btnGuardar.textContent = actualizar ? "Actualizar" : "Guardar";
    btnGuardar.onclick = () => actualizar ? this.actualizar(data) : this.guardar();

    const btnCancelar = document.createElement("BUTTON");
    btnCancelar.className =
      "text-white bg-red-700 hover:bg-red-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-red-600 dark:hover:bg-red-700";
    btnCancelar.textContent = "Cancelar";
    btnCancelar.onclick = () => document.querySelector(".modal-form")?.remove();

    footer.appendChild(btnCancelar);
    footer.appendChild(btnGuardar);

    contenido.appendChild(header);
    contenido.appendChild(divNotificaciones);
    contenido.appendChild(bodyModal);
    contenido.appendChild(footer);

    contenedorModal.appendChild(contenido);
    bgModal.appendChild(contenedorModal);

    this.posicion.appendChild(bgModal);
  }

  async guardar() {
    console.log("Guardando...");
  }

  async actualizar() {
    console.log("Actualizando...");
  }
}

export default Formulario;
