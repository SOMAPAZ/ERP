import AddBag from "./classes/AddBag.js";
import { db } from "./db/db.js";
import { Toast } from "./funciones.js";

const tbody = document.querySelector("tbody");
let usuarios = [];
let bag = [];

AddBag.obtenerLocalStorage().map((item) => {
  console.log(item);
});
render();

function getDatos() {
  usuarios = db;
}

function render() {
  const datos = getDatos();
  usuarios.map((item) => {
    const tr = document.createElement("tr");
    tr.className = "odd:bg-gray-800 even:bg-gray-900";

    const tdID = document.createElement("td");
    tdID.className = "px-4 py2";
    tdID.textContent = item.id;

    const tdNombre = document.createElement("td");
    tdNombre.textContent = item.Nombre;
    tdNombre.className = "px-4 py2";

    const tdDireccion = document.createElement("td");
    tdDireccion.className = "px-4 py2";
    tdDireccion.textContent = item.Direccion;

    const tdColonia = document.createElement("td");
    tdColonia.className = "px-4 py2";
    tdColonia.textContent = item.Colonia;

    const tdZona = document.createElement("td");
    tdZona.className = "px-4 py2";
    tdZona.textContent = item.Zona;

    const tdMesesRez = document.createElement("td");
    tdMesesRez.className = "px-4 py2";
    tdMesesRez.textContent = item.MesesRez;

    const tdMonto = document.createElement("td");
    tdMonto.className = "px-4 py2";
    tdMonto.textContent = item.Monto;

    const tdAgendar = document.createElement("th");
    const btnAgendar = document.createElement("button");
    btnAgendar.className =
      "text-sky-500 font-bold py-1 px-4 cursor-pointer font-bold hover:underline";
    btnAgendar.textContent = "+ Agendar";

    btnAgendar.onclick = (e) => {
      btnAgendar.textContent = "Agendado";
      btnAgendar.classList?.remove("text-sky-500");
      btnAgendar.classList.add("text-green-600");

      setTimeout(() => {
        tr.remove();
      }, 1000);

      addToBag(e);
    };

    tdAgendar.appendChild(btnAgendar);

    tr.appendChild(tdID);
    tr.appendChild(tdNombre);
    tr.appendChild(tdDireccion);
    tr.appendChild(tdColonia);
    tr.appendChild(tdZona);
    tr.appendChild(tdMesesRez);
    tr.appendChild(tdMonto);
    tr.appendChild(tdAgendar);

    tbody.appendChild(tr);
  });
}

function addToBag(e) {
  let objBag = {
    id: "",
    nombre: "",
    direccion: "",
    colonia: "",
    zona: "",
    mesesRez: "",
    monto: "",
  };

  Toast.fire({
    icon: "success",
    title: "Agregado exitosamente",
  });

  const nodeDatos = e.target.parentElement.parentElement;
  objBag.id = nodeDatos.querySelector("td:nth-child(1)").textContent;
  objBag.nombre = nodeDatos.querySelector("td:nth-child(2)").textContent;
  objBag.direccion = nodeDatos.querySelector("td:nth-child(3)").textContent;
  objBag.colonia = nodeDatos.querySelector("td:nth-child(4)").textContent;
  objBag.zona = nodeDatos.querySelector("td:nth-child(5)").textContent;
  objBag.mesesRez = nodeDatos.querySelector("td:nth-child(6)").textContent;
  objBag.monto = nodeDatos.querySelector("td:nth-child(7)").textContent;

  AddBag.guardarLocalStorage(objBag);
}
