<?php

namespace App\Config;

use PDO;
use PDOException;

class DatabaseConfig
{
    public static function getConnection()
    {
        $host = 'localhost';
        $dbname = 'master_facturaction';
        $username = 'root';
        $password = '';

        try {
            $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $conn;
        } catch (PDOException $e) {
            echo "Connection failed: " . $e->getMessage();
        }
    }
}
