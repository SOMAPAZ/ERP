<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="form-container">
        <h2>Editar Unidad</h2>
        <?php if (isset($unities)): ?>
            <form method="POST" action="/update-unities/<?php echo htmlspecialchars($unities['id']); ?>">
                <div class="form-group">
                    <label for="name" class="form-label">Nombre de la Unidad</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($unities['name']); ?>" required>
                </div>
                <button type="submit" class="btn-submit">Actualizar</button>
            </form>
        <?php else: ?>
            <p>Error: La unidad no está definida.</p>
        <?php endif; ?>
    </div>
</main>
<?php require_once __DIR__ . '/../layout/footer.php'; ?>