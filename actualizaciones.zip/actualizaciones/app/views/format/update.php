<?php require_once __DIR__ . '/../layout/header.php'; ?>

<main>
    <div class="form-container">

        <h2>Editar Formato</h2>
        <?php if (isset($format)): ?>
            <form method="POST" action="/update-format/<?php echo htmlspecialchars($format['id']); ?>">
                <div class="form-group">
                    <label for="year" class="form-label">Año</label>
                    <input type="text" class="form-control" id="year" name="year" value="<?php echo htmlspecialchars($format['year']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="id_account" class="form-label">Cuenta</label>
                    <select name="id_account" id="id_account" class="form-control" required>
                        <?php if (!empty($cuentas) && is_array($cuentas)): ?>
                            <?php foreach ($cuentas as $cuenta): ?>
                                <option value="<?= $cuenta['id'] ?>" <?= $format['id_account'] == $cuenta['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($cuenta['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <option value="">No cuentas disponibles</option>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="amount" class="form-label">Monto</label>
                    <input type="text" class="form-control" id="amount" name="amount" value="<?php echo htmlspecialchars($format['amount']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="iva" class="form-label">IVA</label>

                    <select name="iva" id="iva">
                        <option value="0" <?php echo $format['iva'] == 0 ? 'selected' : ''; ?>>No</option>
                        <option value="1" <?php echo $format['iva'] == 1 ? 'selected' : ''; ?>>Sí</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="edit" class="form-label">Edit</label>
                    <select name="edit" id="edit">
                        <option value="1" <?php echo $format['edit'] == 1 ? 'selected' : ''; ?>>Sí</option>
                        <option value="0" <?php echo $format['edit'] == 0 ? 'selected' : ''; ?>>No</option>
                    </select>
                </div>

                <button type="submit" class="btn-submit">Actualizar</button>
            </form>
        <?php else: ?>
            <p>Error: La notificación no está definida.</p>
        <?php endif; ?>

    </div>
    </form>

    </div>
</main>
<?php require_once __DIR__ . '/../layout/footer.php'; ?>