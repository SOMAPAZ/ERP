<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="form-container">
        <h2>Crear Nuevo Formato</h2>
        <form method="POST" action="/create-format">
            <div class="form-group">
                <label for="year" class="form-label">Año</label>
                <input type="text" class="form-control" id="year" name="year" required>
            </div>
            <div class="form-group">
                <label for="id_account" class="form-label">Cuenta</label>
                <select class="form-control" id="id_account" name="id_account" required>
                    <option value="">Seleccione una cuenta</option>
                    <?php foreach ($account as $acc): ?>
                        <option value="<?php echo htmlspecialchars($acc['id']); ?>">
                            <?php echo htmlspecialchars($acc['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="amount" class="form-label">Monto</label>
                <input type="text" class="form-control" id="amount" name="amount" required>
            </div>
            <div class="form-group">
                <label for="iva" class="form-label">¿Aplica IVA?</label>
                <select class="form-select" id="iva" name="iva" required>
                    <option value="1">Sí</option>
                    <option value="0">No</option>
                </select>
            </div>
            <div class="form-group">
                <label for="edit" class="form-label">¿Permitir Editar?</label>
                <select class="form-select" id="edit" name="edit" required>
                    <option value="1">Sí</option>
                    <option value="0">No</option>
                </select>
            </div>

            <button type="submit" class="btn-submit">Crear</button>
        </form>
    </div>
</main>
<?php require_once __DIR__ . '/../layout/footer.php'; ?>