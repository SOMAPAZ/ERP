<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="container mt-5">
        <h2>Lista de Formatos</h2>
        <a href="/create-format" class="btn btn-primary mb-3">Crear Formato</a>
        <?php if (!empty($formats)): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Año</th>
                        <th>Nombre</th>
                        <th>Monto</th>
                        <th>IVA</th>
                        <th>Edit</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($formats as $format): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($format['id']); ?></td>
                            <td><?php echo htmlspecialchars($format['year']); ?></td>
                            <td><?php echo htmlspecialchars($format['nombre']); ?></td>
                            <td>$<?php echo htmlspecialchars($format['amount']); ?></td>
                            <td><?php echo htmlspecialchars($format['iva']) > 0 ? 'Sí' : 'No'; ?></td>
                            <td><?php echo htmlspecialchars($format['edit']) > 0 ? 'Sí' : 'No'; ?></td>
                            <td>
                                <a href="/update-format/<?php echo $format['id']; ?>" class="btn btn-warning">Editar</a>
                                <a href="/delete-format/<?php echo $format['id']; ?>" class="btn btn-danger" onclick="return confirm('¿Estás seguro de que deseas eliminar este formato?');">Eliminar</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No hay formatos disponibles.</p>
        <?php endif; ?>
    </div>
</main>
<?php require_once __DIR__ . '/../layout/footer.php'; ?>