<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="container mt-5">
        <h2>Lista de Tarifas de Servicios Medidos</h2>
        <a href="/create-measured" class="btn btn-primary mb-3">Crear Tarifa de Servicios Medidos</a>
        <?php if (!empty($measured)): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Año</th>
                        <th>Tipo de Toma</th>
                        <th>Tipo de Consumo</th>
                        <th>Monto</th>
                        <th>IVA</th>
                        <th>Límite Inferior</th>
                        <th>Límite Superior</th>
                        <th>Exc. M3</th>
                        <th>IVA Exc.</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($measured as $measured): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($measured['id']); ?></td>
                            <td><?php echo htmlspecialchars($measured['year']); ?></td>
                            <td><?php echo htmlspecialchars($measured['tipo_toma']); ?></td>
                            <td><?php echo htmlspecialchars($measured['tipo_consumo']); ?></td>
                            <td>$<?php echo htmlspecialchars(number_format($measured['amount'], 2, '.', ',')); ?></td>
                            <td><?php echo htmlspecialchars($measured['iva']) > 0 ? 'Sí' : 'No'; ?></td>
                            <td><?php echo htmlspecialchars($measured['liminf']); ?></td>
                            <td><?php echo htmlspecialchars($measured['limsup']); ?></td>
                            <td>$<?php echo htmlspecialchars(number_format($measured['excm3'], 2, '.', ',')); ?></td>
                            <td><?php echo htmlspecialchars($measured['iva_exc']) > 0 ? 'Sí' : 'No'; ?></td>
                            <td>
                                <a href="/update-measured/<?php echo $measured['id']; ?>" class="btn btn-warning">Editar</a>
                                <a href="/delete-measured/<?php echo $measured['id']; ?>" class="btn btn-danger" onclick="return confirm('¿Estás seguro de que deseas eliminar este servicio medido?');">Eliminar</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No hay servicios medidos disponibles.</p>
        <?php endif; ?>
    </div>
</main>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>