<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="form-container">
        <h2>Crear Nuevo Tarifa de Servicios Medidos</h2>
        <form method="POST" action="/create-measured">
            <div class="form-group">
                <label for="year" class="form-label">Año</label>
                <input type="text" class="form-control" id="year" name="year" required>
            </div>
            <div class="form-group">
                <label for="id_intaketype" class="form-label">Tipo de Toma</label>
                <select class="form-control" id="id_intaketype" name="id_intaketype" required>
                    <option value="">Seleccione un tipo de toma</option>
                    <?php foreach ($intakeType as $intake): ?>
                        <option value="<?php echo htmlspecialchars($intake['id']); ?>">
                            <?php echo htmlspecialchars($intake['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="id_consumtype" class="form-label">Tipo de Consumo</label>
                <select class="form-control" id="id_consumtype" name="id_consumtype" required>
                    <option value="">Seleccione un tipo de consumo</option>
                    <?php foreach ($consumeType as $consume): ?>
                        <option value="<?php echo htmlspecialchars($consume['id']); ?>">
                            <?php echo htmlspecialchars($consume['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="amount" class="form-label">Monto</label>
                <input type="text" class="form-control" id="amount" name="amount" required>
            </div>
            <div class="form-group">
                <label for="iva" class="form-label">¿Aplica IVA?</label>
                <select class="form-select" id="iva" name="iva" required>
                    <option value="1">Sí</option>
                    <option value="0">No</option>
                </select>
            </div>
            <div class="form-group">
                <label for="liminf" class="form-label">Límite Inferior</label>
                <input type="text" class="form-control" id="liminf" name="liminf" required>
            </div>
            <div class="form-group">
                <label for="limsup" class="form-label">Límite Superior</label>
                <input type="text" class="form-control" id="limsup" name="limsup" required>
            </div>
            <div class="form-group">
                <label for="edit" class="form-label">¿Permitir Editar?</label>
                <select class="form-select" id="edit" name="edit" required>
                    <option value="1">Sí</option>
                    <option value="0">No</option>
                </select>
            </div>
            <div class="form-group">
                <label for="excm3" class="form-label">Exc. M3</label>
                <input type="text" class="form-control" id="excm3" name="excm3" required>
            </div>
            <div class="form-group">
                <label for="iva_exc" class="form-label">¿Aplica IVA Exc.?</label>
                <select class="form-select" id="iva_exc" name="iva_exc" required>
                    <option value="1">Sí</option>
                    <option value="0">No</option>
                </select>
            </div>
            <button type="submit" class="btn-submit">Crear</button>
        </form>
    </div>
</main>
<?php require_once __DIR__ . '/../layout/footer.php'; ?>