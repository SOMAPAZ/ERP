<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="form-container">
        <h2>Editar Tarifa de Servicios Medidos</h2>
        <?php if (isset($measured)): ?>
            <form method="POST" action="/update-measured/<?php echo htmlspecialchars($measured->id); ?>">
                <div class="form-group">
                    <label for="year" class="form-label">Año</label>
                    <input type="text" class="form-control" id="year" name="year" value="<?php echo htmlspecialchars($measured->year); ?>" required>
                </div>
                <div class="form-group">
                    <label for="id_intaketype" class="form-label">Tipo de Toma</label>
                    <select name="id_intaketype" id="id_intaketype" class="form-control" required>
                        <?php if (!empty($intake_type) && is_array($intake_type)): ?>
                            <?php foreach ($intake_type as $intake_type): ?>
                                <option value="<?= $intake_type['id'] ?>" <?= $measured->id_intaketype == $intake_type['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($intake_type['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <option value="">No tipos de toma disponibles</option>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="id_consumtype" class="form-label">Tipo de Consumo</label>
                    <select name="id_consumtype" id="id_consumtype" class="form-control" required>
                        <?php if (!empty($consume_type) && is_array($consume_type)): ?>
                            <?php foreach ($consume_type as $consume_type): ?>
                                <option value="<?= $consume_type['id'] ?>" <?= $measured->id_consumtype == $consume_type['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($consume_type['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <option value="">No tipos de consumo disponibles</option>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="amount" class="form-label">Monto</label>
                    <input type="text" class="form-control" id="amount" name="amount" value="<?php echo htmlspecialchars($measured->amount); ?>" required>
                </div>
                <div class="form-group">
                    <label for="iva" class="form-label">IVA</label>
                    <select name="iva" id="iva">
                        <option value="0" <?php echo $measured->iva == 0 ? 'selected' : ''; ?>>No</option>
                        <option value="1" <?php echo $measured->iva == 1 ? 'selected' : ''; ?>>Sí</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="liminf" class="form-label">Límite Inferior</label>
                    <input type="text" class="form-control" id="liminf" name="liminf" value="<?php echo htmlspecialchars($measured->liminf); ?>" required>
                </div>
                <div class="form-group">
                    <label for="limsup" class="form-label">Límite Superior</label>
                    <input type="text" class="form-control" id="limsup" name="limsup" value="<?php echo htmlspecialchars($measured->limsup); ?>" required>
                </div>
                <div class="form-group">
                    <label for="excm3" class="form-label">Exc. M3</label>
                    <input type="text" class="form-control" id="excm3" name="excm3" value="<?php echo htmlspecialchars($measured->excm3); ?>" required>
                </div>
                <div class="form-group">
                    <label for="iva_exc" class="form-label">IVA Exc.</label>

                    <select name="iva_exc" id="iva_exc">
                        <option value="0" <?php echo $measured->iva_exc == 0 ? 'selected' : ''; ?>>No</option>
                        <option value="1" <?php echo $measured->iva_exc == 1 ? 'selected' : ''; ?>>Sí</option>
                    </select>
                </div>
                <button type="submit" class="btn-submit">Actualizar</button>
            </form>
        <?php else: ?>
            <p>Error: El servicio medido no está definido.</p>
        <?php endif; ?>
    </div>
</main>
<?php require_once __DIR__ . '/../layout/footer.php'; ?>