<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="container mt-5">
        <h2>Lista de Zonas</h2>
        <a href="/create-zone" class="btn btn-primary mb-3">Crear Zona</a>
        <?php if (!empty($zones)): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($zones as $zone): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($zone['id']); ?></td>
                            <td><?php echo htmlspecialchars($zone['name']); ?></td>
                            <td>
                                <a href="/update-zone/<?php echo $zone['id']; ?>" class="btn btn-warning">Editar</a>
                                <a href="/delete-zone/<?php echo $zone['id']; ?>" class="btn btn-danger" onclick="return confirm('¿Estás seguro de que deseas eliminar esta zona?');">Eliminar</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No hay zonas disponibles.</p>
        <?php endif; ?>
    </div>
</main>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>