<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="form-container">
        <h2>Editar Zona</h2>
        <?php if (isset($zone)): ?>
            <form method="POST" action="/update-zone/<?php echo htmlspecialchars($zone['id']); ?>">
                <div class="form-group">
                    <label for="name" class="form-label">Nombre de la Zona</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($zone['name']); ?>" required>
                </div>
                <button type="submit" class="btn-submit">Actualizar</button>
            </form>
        <?php else: ?>
            <p>Error: La zona no está definida.</p>
        <?php endif; ?>
    </div>
</main>
<?php require_once __DIR__ . '/../layout/footer.php'; ?>