<?php require_once __DIR__ . '/../layout/header.php'; ?>

<div class="form-container">
    <h2>Crear Nueva Colonia</h2>
    <form method="POST" action="/create-colony">
        <div class="form-group">
            <label for="name" class="form-label">Nombre de la Colonia</label>
            <input type="text" class="form-control" id="name" name="name" required>
        </div>
        <button type="submit" class="btn btn-submit">Crear</button>
        <a href="/colonyIndex" class="btn btn-secondary">Cancelar</a>
    </form>
</div>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>