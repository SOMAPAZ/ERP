<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="container mt-5">
        <h2>Colonias</h2>
        <a href="/create-colony" class="btn btn-primary mb-3">Crear Colonia</a>
        <div id="colonia-tabla"></div>
    </div>
    <script src="/js/colony.js"></script>
</main>

<!-- <main>
    <div class="container mt-5">
        <h2>Lista de Colonias</h2>
        <a href="/create-colony" class="btn btn-primary mb-3">Crear Colonia</a>
        <?php if (!empty($colonies)): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($colonies as $colony): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($colony['id']); ?></td>
                            <td><?php echo htmlspecialchars($colony['name']); ?></td>
                            <td>
                                <a href="/update-colony/<?php echo $colony['id']; ?>" class="btn btn-warning">Editar</a>
                                <a href="/delete-colony/<?php echo $colony['id']; ?>" class="btn btn-danger" onclick="return confirm('¿Estás seguro de que deseas eliminar esta colonia?');">Eliminar</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No hay colonias disponibles.</p>
        <?php endif; ?>
    </div>
</main> -->
<?php require_once __DIR__ . '/../layout/footer.php'; ?>