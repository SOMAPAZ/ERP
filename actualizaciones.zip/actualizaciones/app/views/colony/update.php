<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="form-container">
        <h2>Editar Colonia</h2>
        <?php if (isset($colony)): ?>
            <form method="POST" action="/update-colony/<?php echo htmlspecialchars($colony['id']); ?>">
                <div class="form-group">
                    <label for="name" class="form-label">Nombre de la Colonia</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($colony['name']); ?>" required>
                </div>
                <button type="submit" class="btn-submit">Actualizar</button>
            </form>
        <?php else: ?>
            <p>Error: La colonia no está definida.</p>
        <?php endif; ?>
    </div>
</main>
<?php require_once __DIR__ . '/../layout/footer.php'; ?>