<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="form-container">
        <h2>Editar Prioridad</h2>
        <?php if (isset($priority)): ?>
            <form method="POST" action="/update-priority/<?php echo htmlspecialchars($priority['id']); ?>">
                <div class="form-group">
                    <label for="name" class="form-label">Nombre de la Prioridad</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($priority['name']); ?>" required>
                </div>
                <button type="submit" class="btn-submit">Actualizar</button>
            </form>
        <?php else: ?>
            <p>Prioridad no encontrada.</p>
        <?php endif; ?>
    </div>
</main>
<?php require_once __DIR__ . '/../layout/footer.php'; ?>