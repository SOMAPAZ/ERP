<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="container mt-5">
        <h2>Prioridades</h2>
        <a href="/create-priority" class="btn btn-primary mb-3">Crear Prioridad</a>
        <div id="prioridad-tabla"></div>
    </div>
    <script src="/js/prioryty.js"></script>
</main>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>