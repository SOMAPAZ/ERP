<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="container mt-5">
        <h2>Lista de Prioridades</h2>
        <a href="/create-priority" class="btn btn-primary mb-3">Crear Prioridad</a>
        <?php if (!empty($priorities)): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($priorities as $priority): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($priority['id']); ?></td>
                            <td><?php echo htmlspecialchars($priority['name']); ?></td>
                            <td>
                                <a href="/update-priority/<?php echo $priority['id']; ?>" class="btn btn-warning">Editar</a>
                                <a href="/delete-priority/<?php echo $priority['id']; ?>" class="btn btn-danger" onclick="return confirm('¿Estás seguro de que deseas eliminar esta prioridad?');">Eliminar</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No hay prioridades disponibles.</p>
        <?php endif; ?>
    </div>
</main>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>