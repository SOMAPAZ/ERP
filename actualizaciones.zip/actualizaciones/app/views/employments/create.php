<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="form-container">
        <h2>Crear Nuevo Empleado</h2>
        <form method="POST" action="/create-employment">
            <div class="form-group">
                <label for="name" class="form-label">Nombre del Empleado</label>
                <input type="text" class="form-control" id="name" name="name" required>
            </div>
            <div class="form-group">
                <label for="lastaname" class="form-label">Apellido del Empleado</label>
                <input type="text" class="form-control" id="lastaname" name="lastaname" required>
            </div>
            <div class="form-group">
                <label for="mail" class="form-label">Email del Empleado</label>
                <input type="email" class="form-control" id="mail" name="mail" required>
            </div>
            <div class="form-group">
                <label for="password" class="form-label">Contraseña del Empleado</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <div class="form-group">
                <label for="id_rol" class="form-label">Seleccionar Rol</label>
                <select class="form-control" id="id_rol" name="id_rol" required>
                    <option value="" disabled selected>Selecciona un rol</option>
                    <?php foreach ($roles as $role): ?>
                        <option value="<?php echo $role['id']; ?>"><?php echo htmlspecialchars($role['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="btn-submit">Crear</button>
            <a href="?controller=main&action=employmentIndex" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>
</main>
<?php require_once __DIR__ . '/../layout/header.php'; ?>