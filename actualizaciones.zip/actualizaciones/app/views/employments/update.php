<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="form-container">
        <h2>Editar Empleado</h2>
        <?php if (isset($employment)): ?>
            <form method="POST" action="/update-employment/<?php echo htmlspecialchars($employment->id); ?>">
                <div class="form-group">
                    <label for="name" class="form-label">Nombre de la Empleado</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?= htmlspecialchars($employment->name) ?>" required>
                </div>
                <div class="form-group">
                    <label for="lastaname" class="form-label">Apellido</label>
                    <input type="text" class="form-control" id="lastaname" name="lastaname" value="<?php echo htmlspecialchars($employment->lastaname); ?>" required>
                </div>
                <div class="form-group">
                    <label for="mail" class="form-label">Email</label>
                    <input type="text" class="form-control" id="mail" name="mail" value="<?php echo htmlspecialchars($employment->mail); ?>" required>
                </div>
                <div class="form-group">
                    <label for="password" class="form-label">Contraseña</label>
                    <input type="password" class="form-control" id="password" name="password" value="<?php echo htmlspecialchars($employment->password); ?>" required>
                </div>
                <div class="form-group">
                    <label for="id_rol" class="form-label">Rol</label>
                    <select name="id_rol" id="id_rol" class="form-control" required>
                        <?php if (!empty($roles) && is_array($roles)): ?>
                            <?php foreach ($roles as $role): ?>
                                <option value="<?= $role['id'] ?>" <?= $employment->id_rol == $role['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($role['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <option value="">No roles available</option>
                        <?php endif; ?>
                    </select>
                </div>
                <button type="submit" class="btn-submit">Actualizar</button>
            </form>
        <?php else: ?>
            <p>Error: El empleado no está definido.</p>
        <?php endif; ?>
</main>
<?php require_once __DIR__ . '/../layout/footer.php'; ?>