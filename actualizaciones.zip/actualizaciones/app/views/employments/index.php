<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main class="bg-white dark:bg-gray-800 m-0">
    <div class="w-full max-w-7xl mx-auto py-6 px-4 overflow-x-scroll ">
        <h2 class="dark:text-white text-center text-3xl mb-3 uppercase font-bold">Lista de Empleados</h2>
        <div class="flex justify-center">
            <button id="crear-empleado" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mb-3">Crear Empleado</button>
        </div>
        <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400 uppercase ">
            <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                <tr>

                    <th>Id</th>
                    <th scope="col" class="px-6 py-3">
                        Nombre</th>

                    <th scope="col" class="px-6 py-3">
                        Email</th>
                    <th scope="col" class="px-6 py-3">
                        Rol</th>
                    <th scope="col" class="px-6 py-3">
                        Acciones</th>
                </tr>
            </thead>
            <tbody id="empleados-tabla">
                <tr id="nodatos" class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                    <td colspan="7" style="text-align: center;">Sin datos disponibles</td>
                </tr>

            </tbody>
        </table>

    </div>
</main>
<script src="/js/employment.js"></script>
<?php require_once __DIR__ . '/../layout/footer.php'; ?>