<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="container mt-5">
        <h2>Lista de Empleados</h2>
        <a href="/create-employment" class="btn btn-primary mb-3">Crear Empleado</a>
        <?php if (!empty($employments)): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Apellido</th>
                        <th>Email</th>
                        <th>Contraseña</th>
                        <th>Rol</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($employments as $employment): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($employment['id']); ?></td>
                            <td><?php echo htmlspecialchars($employment['name']); ?></td>
                            <td><?php echo htmlspecialchars($employment['lastaname']); ?></td>
                            <td><?php echo htmlspecialchars($employment['mail']); ?></td>
                            <td><?php echo htmlspecialchars($employment['password']) !== '' ? 'Contraseña Encriptada' : 'Contraseña Clave'; ?></td>
                            <td><?php echo htmlspecialchars($employment['nombre_rol']); ?></td>
                            <td>
                                <a href="/update-employment/<?php echo $employment['id']; ?>" class="btn btn-warning">Editar</a>
                                <a href="/delete-employment/<?php echo $employment['id']; ?>" class="btn btn-danger" onclick="return confirm('¿Estás seguro de que deseas eliminar este empleado?');">Eliminar</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No hay empleados disponibles.</p>
        <?php endif; ?>
    </div>
</main>
<?php require_once __DIR__ . '/../layout/footer.php'; ?>