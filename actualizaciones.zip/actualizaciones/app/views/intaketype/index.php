<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>

    <div class="container mt-5">
        <h2>Lista de Tipos de Toma</h2>
        <a href="/create-intakeType" class="btn btn-primary mb-3">Crear Tipo de Toma</a>
        <?php if (!empty($intakeTypes)): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($intakeTypes as $intakeType): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($intakeType['id']); ?></td>
                            <td><?php echo htmlspecialchars($intakeType['name']); ?></td>
                            <td>
                                <a href="/update-intakeType/<?php echo $intakeType['id']; ?>" class="btn btn-warning">Editar</a>
                                <a href="/delete-intakeType/<?php echo $intakeType['id']; ?>" class="btn btn-danger" onclick="return confirm('¿Estás seguro de que deseas eliminar este tipo de toma?');">Eliminar</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No hay tipos de toma disponibles.</p>
        <?php endif; ?>
    </div>
</main>



<?php require_once __DIR__ . '/../layout/footer.php'; ?>