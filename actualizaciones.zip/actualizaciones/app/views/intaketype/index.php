<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="container mt-5">
        <h2>Tipos de Tomas</h2>
        <a href="/create-intakeType" class="btn btn-primary mb-3">Crear Tipo de Toma</a>
        <div id="intaketype-tabla"></div>
    </div>
    <script src="/js/intaketype.js"></script>
</main>


<?php require_once __DIR__ . '/../layout/footer.php'; ?>