<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="form-container">
        <h2>Editar Tipo de Toma</h2>
        <?php if (isset($intakeType)): ?>
            <form method="POST" action="/update-intakeType/<?php echo htmlspecialchars($intakeType['id']); ?>">
                <div class="form-group">
                    <label for="name" class="form-label">Nombre de la Tipo de Toma</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($intakeType['name']); ?>" required>
                </div>
                <button type="submit" class="btn-submit">Actualizar</button>
            </form>
        <?php else: ?>
            <p>Error: El tipo de toma no está definido.</p>
        <?php endif; ?>
    </div>
</main>
<?php require_once __DIR__ . '/../layout/footer.php'; ?>