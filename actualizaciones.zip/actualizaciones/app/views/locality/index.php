<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="container mt-5">
        <h2>Localidades</h2>
        <a href="/create-locality" class="btn btn-primary mb-3">Crear Localidad</a>
        <div id="localidad-tabla"></div>
    </div>
    <script src="/js/locality.js"></script>
</main>
<?php require_once __DIR__ . '/../layout/footer.php'; ?>