<?php require_once __DIR__ . '/../layout/header.php'; ?>

<main>
    <div class="container mt-5">
        <h2>Lista de Localidades</h2>
        <a href="/create-locality" class="btn btn-primary mb-3">Crear Localidad</a>
        <?php if (!empty($localities)): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($localities as $locality): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($locality['id']); ?></td>
                            <td><?php echo htmlspecialchars($locality['name']); ?></td>
                            <td>
                                <a href="/update-locality/<?php echo $locality['id']; ?>" class="btn btn-warning">Editar</a>
                                <a href="/delete-locality/<?php echo $locality['id']; ?>" class="btn btn-danger" onclick="return confirm('¿Estás seguro de que deseas eliminar esta localidad?');">Eliminar</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No hay localidades disponibles.</p>
        <?php endif; ?>
    </div>
</main>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>