<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="form-container">
        <h2>Editar Localidad</h2>
        <?php if (isset($locality)): ?>
            <form method="POST" action="/update-locality/<?php echo htmlspecialchars($locality['id']); ?>">
                <div class="form-group">
                    <label for="name" class="form-label">Nombre de la Localidad</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($locality['name']); ?>" required>
                </div>
                <button type="submit" class="btn-submit">Actualizar</button>
            </form>
        <?php else: ?>
            <p>Localidad no encontrada.</p>
        <?php endif; ?>
    </div>
</main>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>