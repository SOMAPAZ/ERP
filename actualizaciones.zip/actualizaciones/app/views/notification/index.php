<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="container mt-5">
        <h2>Lista de Notificaciones</h2>
        <a href="/create-notification" class="btn btn-primary mb-3">Crear Notificación</a>
        <?php if (!empty($notifications)): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Año</th>
                        <th>Nombre</th>
                        <th>Monto</th>
                        <th>IVA</th>
                        <th>Edit</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($notifications as $notification): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($notification['id']); ?></td>
                            <td><?php echo htmlspecialchars($notification['year']); ?></td>
                            <td><?php echo htmlspecialchars($notification['nombre']); ?></td>
                            <td>$<?php echo htmlspecialchars($notification['amount']); ?></td>
                            <td><?php echo htmlspecialchars($notification['iva']) > 0 ? 'Sí' : 'No'; ?></td>
                            <td><?php echo htmlspecialchars($notification['edit']) > 0 ? 'Sí' : 'No'; ?></td>
                            <td>
                                <a href="/update-notification/<?php echo $notification['id']; ?>" class="btn btn-warning">Editar</a>
                                <a href="/delete-notification/<?php echo $notification['id']; ?>" class="btn btn-danger" onclick="return confirm('¿Estás seguro de que deseas eliminar esta notificación?');">Eliminar</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No hay notificaciones disponibles.</p>
        <?php endif; ?>
    </div>
</main>
<?php require_once __DIR__ . '/../layout/footer.php'; ?>