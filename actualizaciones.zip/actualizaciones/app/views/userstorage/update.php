<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="form-container">
        <h2>Editar Storage</h2>
        <?php if (isset($userStorage)): ?>
            <form method="POST" action="/update-userStorage/<?php echo htmlspecialchars($userStorage['id']); ?>">
                <div class="form-group">
                    <label for="name" class="form-label">Nombre de Storage</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($userStorage['name']); ?>" required>
                </div>
                <button type="submit" class="btn-submit">Actualizar</button>
            </form>
        <?php else: ?>
            <p>Error: Storage no encontrado.</p>
        <?php endif; ?>
    </div>
</main>
<?php require_once __DIR__ . '/../layout/footer.php'; ?>