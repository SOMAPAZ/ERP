<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="container mt-5">
        <h2>Lista de Categorías</h2>
        <a href="/create-category" class="btn btn-primary mb-3">Crear Categoría</a>
        <?php if (!empty($categories)): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($categories as $category): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($category['id']); ?></td>
                            <td><?php echo htmlspecialchars($category['name']); ?></td>
                            <td>
                                <a href="/update-category/<?php echo  $category['id']; ?>" class="btn btn-warning">Editar</a>
                                <a href="/delete-category/<?php echo $category['id']; ?>" class="btn btn-danger" onclick="return confirm('¿Estás seguro de que deseas eliminar esta categoría?');">Eliminar</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No hay categorías disponibles.</p>
        <?php endif; ?>
    </div>
    <script src="/js/category.js"></script>
</main>
<?php require_once __DIR__ . '/../layout/footer.php'; ?>