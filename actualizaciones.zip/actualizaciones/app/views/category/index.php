<?php require_once __DIR__ . '/../layout/header.php'; ?>

<main>
    <div class="container mt-5">
        <h2>Lista de Categorias</h2>
        <a href="/create-category" class="btn btn-primary mb-3">Crear Categoria</a>
        <div id="categoria-tabla"></div>
    </div>
    <script src="/js/category.js"></script>
</main>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>