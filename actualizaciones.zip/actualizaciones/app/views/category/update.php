<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="form-container">
        <h2>Editar Categoría</h2>
        <?php if (isset($category)): ?>
            <form method="POST" action="/update-category/<?php echo htmlspecialchars($category['id']); ?>">
                <div class="form-group">
                    <label for="name" class="form-label">Nombre de la Categoría</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($category['name']); ?>" required>
                </div>
                <button type="submit" class="btn-submit">Actualizar</button>
            </form>
        <?php else: ?>
            <p>Error: La categoría no está definida.</p>
        <?php endif; ?>
    </div>
</main>
<?php require_once __DIR__ . '/../layout/footer.php'; ?>