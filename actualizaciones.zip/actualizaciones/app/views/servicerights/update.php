<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="form-container">
        <h2>Editar Servicio</h2>
        <?php if (isset($service_rights)): ?>
            <form method="POST" action="/update-serviceRights/<?php echo htmlspecialchars($service_rights->id); ?>">
                <div class="form-group">
                    <label for="year" class="form-label">Año</label>
                    <input type="text" class="form-control" id="year" name="year" value="<?php echo htmlspecialchars($service_rights->year); ?>" required>
                </div>
                <div class="form-group">
                    <label for="id_service" class="form-label">Servicio</label>
                    <select name="id_service" id="id_service" class="form-control" required>
                        <?php if (!empty($service) && is_array($service)): ?>
                            <?php foreach ($service as $serv): ?>
                                <option value="<?= $serv['id'] ?>" <?= $service_rights->id_service == $serv['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($serv['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <option value="">No servicios disponibles</option>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="id_intaketype" class="form-label">Tipo de Toma</label>
                    <select name="id_intaketype" id="id_intaketype" class="form-control" required>
                        <?php if (!empty($intake_type) && is_array($intake_type)): ?>
                            <?php foreach ($intake_type as $intake_type): ?>
                                <option value="<?= $intake_type['id'] ?>" <?= $service_rights->id_intaketype == $intake_type['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($intake_type['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <option value="">No tipos de toma disponibles</option>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="iva" class="form-label">IVA</label>

                    <select name="iva" id="iva">
                        <option value="0" <?php echo $service_rights->iva == 0 ? 'selected' : ''; ?>>No</option>
                        <option value="1" <?php echo $service_rights->iva == 1 ? 'selected' : ''; ?>>Sí</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="amount" class="form-label">Monto</label>
                    <input type="text" class="form-control" id="amount" name="amount" value="<?php echo htmlspecialchars($service_rights->amount); ?>" required>
                </div>
                <button type="submit" class="btn-submit">Actualizar</button>
            </form>
        <?php else: ?>
            <p>Error: El servicio no está definido.</p>
        <?php endif; ?>
    </div>
</main>
<?php require_once __DIR__ . '/../layout/footer.php'; ?>