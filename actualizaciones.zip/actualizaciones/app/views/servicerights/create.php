<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="form-container">
        <h2>Crear Nuevo Servicio</h2>
        <form method="POST" action="/create-serviceRights">
            <div class="form-group">
                <label for="year" class="form-label">Año</label>
                <input type="text" class="form-control" id="year" name="year" required>
            </div>
            <div class="form-group">
                <label for="id_service" class="form-label">Servicio</label>
                <select class="form-control" id="id_service" name="id_service" required>
                    <option value="">Seleccione un servicio</option>
                    <?php foreach ($service as $serv): ?>
                        <option value="<?php echo htmlspecialchars($serv['id']); ?>">
                            <?php echo htmlspecialchars($serv['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="id_intaketype" class="form-label">Tipo de Toma</label>
                <select class="form-control" id="id_intaketype" name="id_intaketype" required>
                    <option value="">Seleccione un tipo de toma</option>
                    <?php foreach ($intakeType as $intake): ?>
                        <option value="<?php echo htmlspecialchars($intake['id']); ?>">
                            <?php echo htmlspecialchars($intake['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="amount" class="form-label">Monto</label>
                <input type="text" class="form-control" id="amount" name="amount" required>
            </div>
            <div class="form-group">
                <label for="iva" class="form-label">¿Aplica IVA?</label>
                <select class="form-select" id="iva" name="iva" required>
                    <option value="1">Sí</option>
                    <option value="0">No</option>
                </select>
            </div>
            <button type="submit" class="btn-submit">Crear</button>
        </form>
    </div>
</main>
<?php require_once __DIR__ . '/../layout/footer.php'; ?>