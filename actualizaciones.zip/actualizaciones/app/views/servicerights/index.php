<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="container mt-5">
        <h2>Lista de Servicios</h2>
        <a href="/create-serviceRights" class="btn btn-primary mb-3">Crear Servicio</a>
        <?php if (!empty($serviceRights)): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Año</th>
                        <th>Servicio</th>
                        <th>Tipo de Toma</th>
                        <th>IVA</th>
                        <th>Monto</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($serviceRights as $serviceRight): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($serviceRight['id']); ?></td>
                            <td><?php echo htmlspecialchars($serviceRight['year']); ?></td>
                            <td><?php echo htmlspecialchars($serviceRight['servicio']); ?></td>
                            <td><?php echo htmlspecialchars($serviceRight['tipo_toma']); ?></td>
                            <td><?php echo htmlspecialchars($serviceRight['iva']) > 0 ? 'Sí' : 'No'; ?></td>
                            <td>$<?php echo htmlspecialchars(number_format($serviceRight['amount'], 2, '.', ',')); ?></td>
                            <td>
                                <a href="/update-serviceRights/<?php echo $serviceRight['id']; ?>" class="btn btn-warning">Editar</a>
                                <a href="/delete-serviceRights/<?php echo $serviceRight['id']; ?>" class="btn btn-danger" onclick="return confirm('¿Estás seguro de que deseas eliminar este servicio?');">Eliminar</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No hay servicios disponibles.</p>
        <?php endif; ?>
    </div>
</main>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>