<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualizaciones</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</head>

<body class="bg-gray-100 dark:bg-gray-800">
    <header class="bg-blue-500 text-white">
        <div class="flex justify-center items-center px-6 py-4">
            <div class="text-3xl font-bold text-center justify-center font-semibold uppercase">Actualizaciones</div>
        </div>
    </header>
    <nav class="bg-blue-700">
        <ul class="flex justify-center space-x-4">
            <li class="relative group">
                <a href="#" class="block px-4 py-2 text-white">Gestión de Datos ▼</a>
                <ul class="absolute hidden group-hover:block dark:bg-gray-700 bg-blue-500 text-white min-w-[200px] space-y-2">
                    <li><a href="/categoryIndex" class="block px-4 py-2 hover:bg-gray-600">Categorías</a></li>
                    <li><a href="/colonyIndex" class="block px-4 py-2 hover:bg-gray-600">Colonias</a></li>
                    <li><a href="/consumeTypeIndex" class="block px-4 py-2 hover:bg-gray-600">Tipos de Consumo</a></li>
                    <li><a href="/intakeTypeIndex" class="block px-4 py-2 hover:bg-gray-600">Tipos de Toma</a></li>
                    <li><a href="/localityIndex" class="block px-4 py-2 hover:bg-gray-600">Localidades</a></li>
                    <li><a href="/materialsIndex" class="block px-4 py-2 hover:bg-gray-600">Materiales</a></li>
                    <li><a href="/priorityIndex" class="block px-4 py-2 hover:bg-gray-600">Prioridades</a></li>
                    <li><a href="/unitiesIndex" class="block px-4 py-2 hover:bg-gray-600">Unidades</a></li>
                    <li><a href="/userStorageIndex" class="block px-4 py-2 hover:bg-gray-600">Almacenamiento de Usuarios</a></li>
                    <li><a href="/zoneIndex" class="block px-4 py-2 hover:bg-gray-600">Zonas</a></li>
                </ul>
            </li>
            <li class="relative group">
                <a href="#" class="block px-4 py-2 text-white">Gestión de Usuarios ▼</a>
                <ul class="absolute hidden group-hover:block dark:bg-gray-700 bg-blue-500 text-white min-w-[200px] space-y-2">
                    <li><a href="/userIndex" class="block px-4 py-2 hover:bg-gray-600">Usuarios</a></li>
                    <li><a href="/employmentIndex" class="block px-4 py-2 hover:bg-gray-600">Empleados</a></li>
                    <li><a href="/incidenceIndex" class="block px-4 py-2 hover:bg-gray-600">Incidencias</a></li>
                    <li><a href="/rolesIndex" class="block px-4 py-2 hover:bg-gray-600">Roles</a></li>
                </ul>
            </li>
            <li class="relative group">
                <a href="#" class="block px-4 py-2 text-white hover:bg-gray-600">Gestión de Tarifas ▼</a>
                <!-- Submenú Tarifa de Servicios -->
                <ul class="absolute hidden group-hover:block dark:bg-gray-700 bg-blue-500 text-white min-w-[200px] space-y-2">
                    <!-- Submenú Tarifas de Servicios -->
                    <li class="relative group">
                        <a href="#" class="block px-4 py-2 hover:bg-gray-600">Tarifas de Servicios ▼</a>
                        <ul class="absolute hidden group-hover:block dark:bg-gray-700 bg-blue-500 text-white min-w-[200px] space-y-2 left-full top-0">
                            <li><a href="/rateIndex" class="block px-4 py-2 hover:bg-gray-600">Tarifas de Servicios Fijos</a></li>
                            <li><a href="/measuredIndex" class="block px-4 py-2 hover:bg-gray-600">Tarifas de Servicios Medidos</a></li>
                        </ul>
                    </li>
                    <!-- Otras opciones de Gestión de Tarifas -->
                    <li><a href="/serviceRightsIndex" class="block px-4 py-2 hover:bg-gray-600">Tarifas de Derechos</a></li>
                    <li><a href="/formatIndex" class="block px-4 py-2 hover:bg-gray-600">Tarifas Formatos y Constancias</a></li>
                    <li><a href="/notificationIndex" class="block px-4 py-2 hover:bg-gray-600">Tarifas Notificaciones</a></li>
                </ul>
            </li>
        </ul>
    </nav>
</body>