<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema CRUD</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/css/style.css">
</head>

<body>
    <header>
        <div class="header-line">
            <div class="logo">
                <label>Logo</label>
            </div>
        </div>
        <nav class="menu-bar">
            <ul class="menu">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle">Gestión de Datos</a>
                    <ul class="dropdown-menu">
                        <li><a href="/categoryIndex">Categorías</a></li>
                        <li><a href="/colonyIndex">Colonias</a></li>
                        <li><a href="/consumeTypeIndex">Tipos de Consumo</a></li>
                        <li><a href="/intakeTypeIndex">Tipos de Toma</a></li>
                        <li><a href="/localityIndex">Localidades</a></li>
                        <li><a href="/materialsIndex">Materiales</a></li>
                        <li><a href="/priorityIndex">Prioridades</a></li>
                        <li><a href="/rolesIndex">Roles</a></li>
                        <li><a href="/unitiesIndex">Unidades</a></li>
                        <li><a href="/userStorageIndex">Storages</a></li>
                        <li><a href="/zoneIndex">Zonas</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle">Gestión de Usuarios</a>
                    <ul class="dropdown-menu">
                        <li><a href="/userIndex">Usuarios</a></li>
                        <li><a href="/employmentIndex">Empleados</a></li>
                        <li><a href="/incidenceIndex">Incidencias</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle">Gestión de Tarifas</a>
                    <ul class="dropdown-menu">
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle">Tarifas de Servicios</a>
                            <ul class="dropdown-submenu">
                                <li><a href="/rateIndex">Tarifas de Servicios Fijos</a></li>
                                <li><a href="/measuredIndex">Tarifas de Servicios Medidos</a></li>
                            </ul>
                        </li>
                        <li><a href="/serviceRightsIndex">Tarifas de Derechos</a></li>
                        <li><a href="/formatIndex">Tarifas Formatos y Constancias</a></li>
                        <li><a href="/notificationIndex">Tarifas Notificaciones</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
    </header>


</body>

</html>