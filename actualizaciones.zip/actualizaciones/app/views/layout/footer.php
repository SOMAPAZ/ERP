    </main>
    <footer>
        <div class="footer-content">
            <p>&copy; 2024 Sistema de Actualizaciones. Todos los derechos reservados.</p>
        </div>
    </footer>
    </body>

    </html>