<!-- Footer -->
<footer class="bg-gray-100 dark:bg-gray-800  py-4 text-center">
    <p class="text-gray-600">Derechos Reservados &copy; 2024</p>
</footer>

</html>