    <footer>

        <div class="footer-content">
            <p>&copy; 2024 Sistema de Actualizaciones. Todos los derechos reservados.</p>
        </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    </body>

    </html>