<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="container mt-5">
        <h2>Lista de Roles</h2>
        <a href="/create-roles" class="btn btn-primary mb-3">Crear Roles</a>
        <?php if (!empty($roles)): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($roles as $rol): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($rol['id']); ?></td>
                            <td><?php echo htmlspecialchars($rol['name']); ?></td>
                            <td>
                                <a href="/update-roles/<?php echo $rol['id']; ?>" class="btn btn-warning">Editar</a>
                                <a href="/delete-roles/<?php echo $rol['id']; ?>" class="btn btn-danger" onclick="return confirm('¿Estás seguro de que deseas eliminar este rol?');">Eliminar</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No hay roles disponibles.</p>
        <?php endif; ?>
    </div>
</main>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>