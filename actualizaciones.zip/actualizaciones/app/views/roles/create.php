<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="form-container">
        <h2>Crear Nuevo Role</h2>
        <form method="POST" action="/create-roles">
            <div class="form-group">
                <label for="name" class="form-label">Nombre del Role</label>
                <input type="text" class="form-control" id="name" name="name" required>
            </div>
            <button type="submit" class="btn-submit">Crear</button>
            <a href="?controller=main&action=rolesIndex" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>
</main>
<?php require_once __DIR__ . '/../layout/footer.php'; ?>