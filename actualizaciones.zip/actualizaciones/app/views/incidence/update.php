<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="form-container">
        <h2>Editar Incidencia</h2>
        <?php if (isset($incidence)): ?>
            <form method="POST" action="/update-incidence/<?php echo htmlspecialchars($incidence['id']); ?>">
                <div class="form-group">
                    <label for="name" class="form-label">Nombre de la Incidencia</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($incidence['name']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="id_category" class="form-label">Categoría</label>
                    <select name="id_category" id="id_category" class="form-control" required>
                        <?php if (!empty($categories) && is_array($categories)): ?>
                            <?php foreach ($categories as $category): ?>
                                <option value="<?= $category['id'] ?>" <?= $incidence['id_category'] == $category['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($category['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <option value="">No categories available</option>
                        <?php endif; ?>
                    </select>
                </div>
                <button type="submit" class="btn-submit">Actualizar</button>
            </form>
        <?php else: ?>
            <p>Error: La incidencia no está definida.</p>
        <?php endif; ?>
    </div>
</main>
<?php require_once __DIR__ . '/../layout/footer.php'; ?>