<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="form-container">
        <h2>Crear Nueva Incidencia</h2>
        <form method="POST" action="/create-incidence">
            <div class="form-group">
                <label for="name" class="form-label">Nombre de la Incidencia</label>
                <input type="text" class="form-control" id="name" name="name" required>
            </div>
            <div class="form-group">
                <label for="name_category" class="form-label">Seleccionar Categoría</label>
                <select class="form-control" id="name_category" name="id_category" required>
                    <option value="" disabled selected>Selecciona una categoría</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?php echo $category['id']; ?>"><?php echo htmlspecialchars($category['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="btn-submit">Crear</button>
            <a href="?controller=main&action=incidenceIndex" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>
</main>
<?php require_once __DIR__ . '/../layout/footer.php'; ?>