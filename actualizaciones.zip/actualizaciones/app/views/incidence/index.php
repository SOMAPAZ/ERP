<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="container mt-5">
        <h2>Lista de Incidencias</h2>
        <a href="/create-incidence" class="btn btn-primary mb-3">Crear Incidencia</a>
        <?php if (!empty($incidences)): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Nombre Categoría</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($incidences as $incidence): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($incidence['id']); ?></td>
                            <td><?php echo htmlspecialchars($incidence['name']); ?></td>
                            <td><?php echo htmlspecialchars($incidence['name_category']); ?></td>
                            <td>
                                <a href="/update-incidence/<?php echo $incidence['id']; ?>" class="btn btn-warning">Editar</a>
                                <a href="/delete-incidence/<?php echo $incidence['id']; ?>" class="btn btn-danger" onclick="return confirm('¿Estás seguro de que deseas eliminar esta incidencia?');">Eliminar</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No hay incidencias disponibles.</p>
        <?php endif; ?>
    </div>
</main>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>