<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main class="bg-white dark:bg-gray-800 m-0">
    <div class="w-full  mx-auto py-6 px-4 overflow-x-scroll">
        <h2 class="dark:text-white text-center text-3xl mb-3 uppercase font-bold">Lista de Usuarios</h2>
        <div class="flex justify-center">
            <button id="crear-usuario" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mb-3">Crear Usuario</button>
        </div>
        <!-- <a href="/create-user" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mb-3">Crear Usuario</a> -->
        <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400 uppercase ">
            <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                <tr>
                    <th scope="col" class="px-6 py-3">Acciones</th>
                    <th scope="col" class="px-6 py-3">Id</th>
                    <th scope="col" class="px-6 py-3">Nombre</th>
                    <th scope="col" class="px-6 py-3">Tipo de Persona</th>
                    <th scope="col" class="px-6 py-3">Teléfono</th>
                    <th scope="col" class="px-6 py-3">Dirección</th>
                    <th scope="col" class="px-6 py-3">Referencias</th>
                    <th scope="col" class="px-6 py-3">Colonia</th>
                    <th scope="col" class="px-6 py-3">Localidad</th>
                    <th scope="col" class="px-6 py-3">Zona</th>
                    <th scope="col" class="px-6 py-3">Cuadra</th>
                    <th scope="col" class="px-6 py-3"># Int</th>
                    <th scope="col" class="px-6 py-3"># Ext</th>
                    <th scope="col" class="px-6 py-3">Correo</th>
                    <th scope="col" class="px-6 py-3">RFC</th>
                    <th scope="col" class="px-6 py-3">Clave Elector</th>
                    <th scope="col" class="px-6 py-3">Drenaje</th>
                    <th scope="col" class="px-6 py-3">Tipo de Usuario</th>
                    <th scope="col" class="px-6 py-3">Tipo de Toma</th>
                    <th scope="col" class="px-6 py-3">Tipo de Servicio</th>
                    <th scope="col" class="px-6 py-3">Estado de Servicio</th>
                    <th scope="col" class="px-6 py-3">Tipo de Consumo</th>
                </tr>
            </thead>
            <tbody id="usuario-tabla">

                <tr id="userdatos" class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                    <td colspan="7">No hay usuarios disponibles.</td>
            </tbody>

        </table>
        <div id="controles-paginacion" class="flex justify-center items-center mt-4"></div>
    </div>

</main>
<script src="/js/user.js"></script>
<?php require_once __DIR__ . '/../layout/footer.php'; ?>