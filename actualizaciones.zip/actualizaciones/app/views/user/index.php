<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="container mt-5" id="userIndex">
        <h2>Lista de Usuarios</h2>
        <a href="/create-user" class="btn btn-primary mb-3">Crear Usuario</a>
        <?php if (!empty($users)): ?>
            <table class="table" id="userTable">
                <thead>
                    <tr>
                        <th>ID User</th>
                        <th>Nombre</th>
                        <th>Apellidos</th>
                        <th>Tipo de Persona</th>
                        <th>Teléfono</th>
                        <th>Dirección</th>
                        <th>Referencias</th>
                        <th>Colonia</th>
                        <th>Localidad</th>
                        <th>Zona</th>
                        <th>Cuadra</th>
                        <th># Int</th>
                        <th># Ext</th>
                        <th>Correo</th>
                        <th>RFC</th>
                        <th>Clave Elector</th>
                        <th>Drenaje</th>
                        <th>Tipo de Usuario</th>
                        <th>Tipo de Toma</th>
                        <th>Tipo de Servicio</th>
                        <th>Estado de Servicio</th>
                        <th>Tipo de Consumo</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody id="userTableBody">
                    <?php if (isset($users) && !empty($users)): ?>
                        <?php foreach ($users as $user): ?>
                            <tr>
                                <td><?php echo strtoupper($user['id']); ?></td>
                                <td><?php echo htmlspecialchars($user['user']); ?></td>
                                <td><?php echo htmlspecialchars($user['lastname']); ?></td>
                                <td><?php echo $user['id_typeperson'] == 1 ? 'Moral' : 'Fisica'; ?></td>
                                <td><?php echo $user['phone'] ?: 'Sin Teléfono'; ?></td>
                                <td><?php echo $user['address'] ?: 'Sin Dirección'; ?></td>
                                <td><?php echo $user['reference'] ?: 'Sin Referencia'; ?></td>
                                <td><?php echo $user['name_colony'] ?: 'Sin Colonia'; ?></td>
                                <td><?php echo $user['name_locality'] ?: 'Sin Localidad'; ?></td>
                                <td><?php echo $user['name_zone'] ?: 'Sin Zona'; ?></td>
                                <td><?php echo $user['block'] ?: 'Sin Cuadra'; ?></td>
                                <td><?php echo $user['int_num'] ?: 'Sin Número'; ?></td>
                                <td><?php echo $user['ext_num'] ?: 'Sin Número'; ?></td>
                                <td><?php echo $user['mail'] ?: 'Sin Correo'; ?></td>
                                <td><?php echo $user['rfc'] ?: 'Sin RFC'; ?></td>
                                <td><?php echo $user['clave_elector'] ?: 'Sin Clave'; ?></td>
                                <td><?php echo $user['drenaje'] == 1 ? 'Sí' : 'No'; ?></td>
                                <td><?php echo $user['name_user_type'] ?: 'Sin Tipo'; ?></td>
                                <td><?php echo $user['name_intake_type'] ?: 'Sin Tipo'; ?></td>
                                <td><?php echo $user['name_service_type'] ?: 'Sin Tipo'; ?></td>
                                <td><?php echo $user['name_service_status'] ?: 'Sin Estado'; ?></td>
                                <td><?php echo $user['name_consume_type'] ?: 'Sin Tipo'; ?></td>
                                <td>
                                    <a href="/update-user/<?php echo $user['id']; ?>" class="btn btn-warning">Editar</a>
                                    <a href="/delete-user/<?php echo $user['id']; ?>" class="btn btn-danger" onclick="return confirm('¿Estás seguro de que deseas eliminar este usuario?');">Eliminar</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="20">No hay usuarios disponibles.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No hay usuarios disponibles.</p>
        <?php endif; ?>
</main>
<?php require_once __DIR__ . '/../layout/footer.php'; ?>