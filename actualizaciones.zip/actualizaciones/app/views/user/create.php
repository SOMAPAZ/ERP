<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="form-container">
        <h2>Crear Nuevo Usuario</h2>
        <form method="POST" action="/create-user">
            <div class="form-group">
                <label for="typepeople" class="form-label">Tipo de Persona:</label>
                <select name="typepeople" id="typepeople">
                    <option value="0">Persona Fisica</option>
                    <option value="1">Persona Moral</option>
                </select>
            </div>
            <div class="form-group">
                <label for="user" class="form-label">Nombre (S):</label>
                <input type="text" class="form-control" id="user" name="user" required>
            </div>
            <div class="form-group">
                <label for="lastname" class="form-label">Apellido (S):</label>
                <input type="text" class="form-control" id="lastname" name="lastname">
            </div>
            <div class="form-group">
                <label for="phone" class="form-label">Teléfono</label>
                <input type="text" class="form-control" id="phone" name="phone">
            </div>
            <div class="form-group">
                <label for="address" class="form-label">Dirección</label>
                <input type="text" class="form-control" id="address" name="address">
            </div>
            <div class="form-group">
                <label for="reference" class="form-label">Referencia</label>
                <input type="text" class="form-control" id="reference" name="reference">
            </div>
            <div class="form-group">
                <label for="id_colony" class="form-label">Colonia</label>
                <select class="form-control" id="id_colony" name="id_colony" required>
                    <option value="" disabled selected>Selecciona una colonia</option>
                    <?php foreach ($colonies as $colony): ?>
                        <option value="<?php echo $colony['id']; ?>"><?php echo htmlspecialchars($colony['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="id_locality" class="form-label">Localidad</label>
                <select class="form-control" id="id_locality" name="id_locality" required>
                    <option value="" disabled selected>Selecciona una localidad</option>
                    <?php foreach ($localities as $locality): ?>
                        <option value="<?php echo $locality['id']; ?>"><?php echo htmlspecialchars($locality['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="id_zone" class="form-label">Zona</label>
                <select class="form-control" id="id_zone" name="id_zone" required>
                    <option value="" disabled selected>Selecciona una zona</option>
                    <?php foreach ($zones as $zone): ?>
                        <option value="<?php echo $zone['id']; ?>"><?php echo htmlspecialchars($zone['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="block" class="form-label">Cuadra</label>
                <input type="text" class="form-control" id="block" name="block">
            </div>
            <div class="form-group">
                <label for="int_num" class="form-label"># Int</label>
                <input type="text" class="form-control" id="int_num" name="int_num">
            </div>
            <div class="form-group">
                <label for="ext_num" class="form-label"># Ext</label>
                <input type="text" class="form-control" id="ext_num" name="ext_num">
            </div>
            <div class="form-group">
                <label for="mail" class="form-label">Correo</label>
                <input type="email" class="form-control" id="mail" name="mail">
            </div>
            <div class="form-group">
                <label for="rfc" class="form-label">RFC</label>
                <input type="text" class="form-control" id="rfc" name="rfc">
            </div>
            <div class="form-group">
                <label for="clave_elector" class="form-label">Clave Elector</label>
                <input type="text" class="form-control" id="clave_elector" name="clave_elector">
            </div>
            <div class="form-group">
                <label for="drenaje" class="form-label">Drenaje</label>
                <select class="form-control" id="drenaje" name="drenaje">
                    <option value="1">Si</option>
                    <option value="0">No</option>
                </select>
            </div>
            <div class="form-group">
                <label for="id_usertype" class="form-label">Tipo de Usuario</label>
                <select class="form-control" id="id_usertype" name="id_usertype" required>
                    <option value="" disabled selected>Selecciona un tipo de usuario</option>
                    <?php foreach ($userTypes as $userType): ?>
                        <option value="<?php echo $userType['id']; ?>"><?php echo htmlspecialchars($userType['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="id_servicetype" class="form-label">Tipo de Servicio</label>
                <select class="form-control" id="id_servicetype" name="id_servicetype" required>
                    <option value="" disabled selected>Selecciona un tipo de servicio</option>
                    <?php foreach ($serviceTypes as $serviceType): ?>
                        <option value="<?php echo $serviceType['id']; ?>"><?php echo htmlspecialchars($serviceType['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="id_servicestatus" class="form-label">Estado de Servicio</label>
                <select class="form-control" id="id_servicestatus" name="id_servicestatus" required>
                    <option value="" disabled selected>Selecciona un estado de servicio</option>
                    <?php foreach ($serviceStatuses as $serviceStatus): ?>
                        <option value="<?php echo $serviceStatus['id']; ?>"><?php echo htmlspecialchars($serviceStatus['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="id_intaketype" class="form-label">Tipo de Toma</label>
                <select class="form-control" id="id_intaketype" name="id_intaketype" required>
                    <option value="" disabled selected>Selecciona un tipo de toma</option>
                    <?php foreach ($intakeTypes as $intakeType): ?>
                        <option value="<?php echo $intakeType['id']; ?>"><?php echo htmlspecialchars($intakeType['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="id_consumtype" class="form-label">Tipo de Consumo</label>
                <select class="form-control" id="id_consumtype" name="id_consumtype" required>
                    <option value="" disabled selected>Selecciona un tipo de consumo</option>
                    <?php foreach ($consumeTypes as $consumeType): ?>
                        <option value="<?php echo $consumeType['id']; ?>"><?php echo htmlspecialchars($consumeType['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="btn-submit">Crear Usuario</button>
        </form>
    </div>

</main>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>