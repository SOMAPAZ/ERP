<?php require_once __DIR__ . '/../layout/header.php'; ?>

<?php if ($user): ?>
    <div class="form-container">
        <h2>Editar Usuario</h2>
        <form method="POST" action="/update-user/<?php echo htmlspecialchars($user->id); ?>">
            <div class="form-group">
                <label for="id_typeperson">Tipo de Persona:</label>
                <select name="id_typeperson" id="id_typeperson">
                    <option value="0" <?php echo $user->id_typeperson == 0 ? 'selected' : ''; ?>>Persona Fisica</option>
                    <option value="1" <?php echo $user->id_typeperson == 1 ? 'selected' : ''; ?>>Persona Moral</option>
                </select>
            </div>
            <div class="form-group">
                <label for="user">Nombre (S)</label>
                <input type="text" name="user" value="<?php echo htmlspecialchars($user->user); ?>" id="user" placeholder="Nombre de usuario">
            </div>
            <div class="form-group">
                <label for="lastname">Apellido (S)</label>
                <input type="text" id="lastname" name="lastname" placeholder="Apellidos" value="<?php echo htmlspecialchars($user->lastname); ?>">
            </div>
            <div class="form-group">
                <label for="phone">Teléfono</label>
                <input type="text" id="phone" name="phone" placeholder="Número de teléfono" value="<?php echo htmlspecialchars($user->phone); ?>">
            </div>
            <div class="form-group">
                <label for="address">Calle</label>
                <input type="text" id="address" name="address" placeholder="Dirección" value="<?php echo htmlspecialchars($user->address); ?>">
            </div>
            <div class="form-group">
                <label for="reference">Referencia</label>
                <input type="text" id="reference" name="reference" placeholder="Referencia" value="<?php echo htmlspecialchars($user->reference); ?>">
            </div>
            <div class="form-group">
                <label for="id_colony">Colonia:</label>
                <select name="id_colony" id="id_colony" class="form-control">
                    <option value=""><?= htmlspecialchars($user->name_colony ?? 'Seleccionar colonia'); ?></option>
                    <?php foreach ($colonies as $colony): ?>
                        <option value="<?= $colony['id'] ?>" <?= ($user->id_colony == $colony['id']) ? 'selected' : ''; ?>>
                            <?= htmlspecialchars($colony['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="id_locality">Localidad:</label>
                <select name="id_locality" id="id_locality">
                    <option value=""><?= htmlspecialchars($user->name_colony ?? 'Seleccionar Localidad'); ?></option>
                    <?php foreach ($localities as $locality): ?>
                        <option value="<?= $locality['id'] ?>"
                            <?php echo (isset($user) && $user->id_locality == $locality['id']) ? 'selected' : ''; ?>>
                            <?= htmlspecialchars($locality['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="id_zone">Zona:</label>
                <select name="id_zone" id="id_zone">
                    <option value=""><?= htmlspecialchars($user->name_zone ?? 'Seleccionar Zona'); ?></option>
                    <?php foreach ($zones as $zone): ?>
                        <option value="<?= $zone['id'] ?>" <?php echo (isset($user) && $user->id_zone == $zone['id']) ? 'selected' : ''; ?>>
                            <?= htmlspecialchars($zone['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="block">Cuadra:</label>
                <input type="text" name="block" id="block" placeholder="Cuadra" value="<?php echo htmlspecialchars($user->block); ?>">
            </div>
            <div class="form-group">
                <label for="int_num"># Int:</label>
                <input type="text" name="int_num" id="int_num" placeholder="Número de Int" value="<?php echo htmlspecialchars($user->int_num); ?>">
            </div>
            <div class="form-group">
                <label for="ext_num"># Ext:</label>
                <input type="text" name="ext_num" id="ext_num" placeholder="Número de Ext" value="<?php echo htmlspecialchars($user->ext_num); ?>">
            </div>
            <div class="form-group">
                <label for="mail">Correo:</label>
                <input type="email" name="mail" id="mail" placeholder="Correo" value="<?php echo htmlspecialchars($user->mail); ?>">
            </div>
            <div class="form-group">
                <label for="rfc">RFC:</label>
                <input type="text" name="rfc" id="rfc" placeholder="RFC" value="<?php echo htmlspecialchars($user->rfc); ?>">
            </div>
            <div class="form-group">
                <label for="clave_elector">Clave de Elector:</label>
                <input type="text" name="clave_elector" id="clave_elector" placeholder="Clave Elector" value="<?php echo htmlspecialchars($user->clave_elector); ?>">
            </div>
            <div class="form-group" style="display: flex; align-items: center; gap: 10px; margin-bottom: 15px;">
                <label for="drenaje" style="font-weight: bold; margin: 0;">Drenaje:</label>
                <div style="display: flex; align-items: center; gap: 10px;">
                    <input type="hidden" name="drenaje" value="0">
                    <input
                        type="checkbox" name="drenaje" id="drenaje" value="1" style="width: 20px; height: 20px;"
                        <?php echo ($user->drenaje == 1) ? 'checked' : ''; ?>
                        onchange="updateDrenajeLabel()">
                    <span id="drenaje-label" style="font-size: 16px;">
                        <?php echo ($user->drenaje == 1) ? 'Sí' : 'No'; ?>
                    </span>
                </div>
            </div>

            <div class="form-group">
                <label for="id_usertype">Tipo de Usuario:</label>
                <select name="id_usertype" id="id_usertype">
                    <option value=""><?= htmlspecialchars($user->name_user_type ?? 'Seleccione el Tipo de Usuario'); ?></option>
                    <?php foreach ($userTypes as $userType): ?>
                        <option value="<?= $userType['id'] ?>" <?php echo (isset($user) && $user->id_usertype == $userType['id']) ? 'selected' : ''; ?>>
                            <?= htmlspecialchars($userType['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="id_servicetype">Tipo de Servicio:</label>
                <select name="id_servicetype" id="id_servicetype">
                    <option value=""><?= htmlspecialchars($user->name_service_type ?? 'Seleccione el Tipo de Servicio'); ?></option>
                    <?php foreach ($serviceTypes as $serviceType): ?>
                        <option value="<?= $serviceType['id'] ?>" <?php echo (isset($user) && $user->id_servicetype == $serviceType['id']) ? 'selected' : ''; ?>>
                            <?= htmlspecialchars($serviceType['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="id_servicestatus">Estado de Servicio:</label>
                <select name="id_servicestatus" id="id_servicestatus">
                    <option value=""><?= htmlspecialchars($user->name_service_status ?? 'Seleccione el Estado de Servicio'); ?></option>
                    <?php foreach ($serviceStatus as $serviceStatus): ?>
                        <option value="<?= $serviceStatus['id'] ?>" <?php echo (isset($user) && $user->id_servicestatus == $serviceStatus['id']) ? 'selected' : ''; ?>>
                            <?= htmlspecialchars($serviceStatus['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="id_intaketype">Tipo de Toma:</label>
                <select name="id_intaketype" id="id_intaketype">
                    <option value=""><?= htmlspecialchars($user->name_intake_type ?? 'Seleccione el Tipo de Toma'); ?></option>
                    <?php foreach ($intakeType as $intakeType): ?>
                        <option value="<?= $intakeType['id'] ?>" <?php echo (isset($user) && $user->id_intaketype == $intakeType['id']) ? 'selected' : ''; ?>>
                            <?= htmlspecialchars($intakeType['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="id_consumtype">Tipo de Consumo:</label>
                <select name="id_consumtype" id="id_consumtype">
                    <option value=""><?= htmlspecialchars($user->name_consume_type ?? 'Seleccione el Tipo de Consumo'); ?></option>
                    <?php foreach ($consumeTypes as $consumeType): ?>
                        <option value="<?= $consumeType['id'] ?>" <?php echo (isset($user) && $user->id_consumtype == $consumeType['id']) ? 'selected' : ''; ?>>
                            <?= htmlspecialchars($consumeType['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="btn-submit">Actualizar Usuario</button>
        </form>
        <script src="/js/user_edit/combo.js"></script>
    </div>
<?php else: ?>
    <p>Usuario no encontrado.</p>
<?php endif; ?>
<?php require_once __DIR__ . '/../layout/footer.php'; ?>