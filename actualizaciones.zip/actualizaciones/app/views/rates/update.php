<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="form-container">
        <h2>Editar Tarifa</h2>
        <?php if (isset($rate)): ?>
            <form method="POST" action="/update-rate/<?php echo htmlspecialchars($rate->id); ?>">
                <div class="form-group">
                    <label for="year" class="form-label">Año</label>
                    <input type="text" class="form-control" id="year" name="year" value="<?php echo htmlspecialchars($rate->year); ?>" required>
                </div>
                <div class="form-group">
                    <label for="id_consum_intake" class="form-label">Consumo-Toma</label>
                    <select name="id_consum_intake" id="id_consum_intake" class="form-control" required>
                        <?php if (!empty($consume_intake) && is_array($consume_intake)): ?>
                            <?php foreach ($consume_intake as $item): ?>
                                <option value="<?= $item['id'] ?>" <?= $rate->id_consum_intake == $item['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($item['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <option value="">No consumo-intake disponibles</option>
                        <?php endif; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="amount" class="form-label">Monto</label>
                    <input type="text" class="form-control" id="amount" name="amount" value="<?php echo htmlspecialchars(number_format($rate->amount, 2, '.', ',')); ?>" required>
                </div>
                <div class="form-group">
                    <label for="iva" class="form-label">IVA</label>
                    <select name="iva" id="iva">
                        <option value="0" <?php echo $rate->iva == 0 ? 'selected' : ''; ?>>No</option>
                        <option value="1" <?php echo $rate->iva == 1 ? 'selected' : ''; ?>>Sí</option>
                    </select>
                </div>
                <button type="submit" class="btn-submit">Actualizar</button>
            </form>
        <?php else: ?>
            <p>Error: La tarifa no está definida.</p>
        <?php endif; ?>
    </div>
</main>
<?php require_once __DIR__ . '/../layout/footer.php'; ?>