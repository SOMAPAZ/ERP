<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="container mt-5">
        <h2>Lista de Tarifas de Servicios Fijo</h2>
        <a href="/create-rate" class="btn btn-primary mb-3">Crear Tarifa</a>
        <table class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th scope="col">Id</th>
                    <th scope="col">Año</th>
                    <th scope="col">Tipo de Intake</th>
                    <th scope="col">Tipo de Consumo</th>
                    <th scope="col">Monto</th>
                    <th scope="col">IVA</th>
                    <th scope="col">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($rates as $rate): ?>
                    <tr>
                        <td><?php echo $rate['id']; ?></td>
                        <td><?php echo $rate['year']; ?></td>
                        <td><?php echo $rate['nombre_intake_type']; ?></td>
                        <td><?php echo $rate['nombre_consume_type']; ?></td>
                        <td>$<?php echo number_format($rate['amount'], 2, '.', ','); ?></td>
                        <td><?php echo $rate['iva'] === 1 ? 'Si' : 'No' ?></td>
                        <td>
                            <a href="/update-rate/<?php echo $rate['id']; ?>" class="btn btn-warning">Editar</a>
                            <a href="/delete-rate/<?php echo $rate['id']; ?>" class="btn btn-danger" onclick="return confirm('¿Estás seguro de que deseas eliminar esta tarifa?');">Eliminar</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</main>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>