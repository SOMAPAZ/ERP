<?php require_once __DIR__ . '/../layout/header.php'; ?>

<main>
    <div class="container mt-5">
        <h2>Lista de Tipos de Consumo</h2>
        <a href="/create-consumeType" class="btn btn-primary mb-3">Crear Tipo de Consumo</a>
        <?php if (!empty($consumeTypes)): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($consumeTypes as $consumeType): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($consumeType['id']); ?></td>
                            <td><?php echo htmlspecialchars($consumeType['name']); ?></td>
                            <td>
                                <a href="/update-consumeType/<?php echo $consumeType['id']; ?>" class="btn btn-warning">Editar</a>
                                <a href="/delete-consumeType/<?php echo $consumeType['id']; ?>" class="btn btn-danger" onclick="return confirm('¿Estás seguro de que deseas eliminar este tipo de consumo?');">Eliminar</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No hay tipos de consumo disponibles.</p>
        <?php endif; ?>
    </div>
</main>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>