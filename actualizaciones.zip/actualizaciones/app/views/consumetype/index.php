<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main class="bg-white dark:bg-gray-800 m-0">
    <div class="w-full max-w-5xl mx-auto py-4 px-4">
        <div class="text-center">
            <h2 class="dark:text-gray-100 text-gray-800 text-4xl mb-2 uppercase font-bold tracking-wide">
                Tipos de Consumo
            </h2>
            <hr class="border-t-2 border-gray-300 dark:border-gray-700 w-24 mx-auto my-4">
        </div>
        <div class="flex justify-center">
            <button id="crear-consumetype" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mb-3">Crear Tipo de Consumo</button>
        </div>
        <table class="w-full text-sm text-left rtl:text-right text-gray-600 dark:text-gray-300 bg-white shadow-lg rounded-lg overflow-hidden uppercase ">
            <thead class="text-xs text-gray-700 uppercase bg-blue-100 dark:bg-gray-600 dark:text-gray-300 border-b border-gray-300 dark:border-gray-600">
                <tr>
                    <th>Id</th>
                    <th scope="col" class="px-6 py-3">
                        Nombre</th>
                    <th scope="col" class="px-6 py-3">
                        Acciones</th>
                </tr>
            </thead>
            <tbody id="consumetypes-tabla">
                <tr id="nodatos" class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                    <td colspan="7" style="text-align: center;">Sin datos disponibles</td>
                </tr>
            </tbody>
        </table>

    </div>

</main>
<script src="/js/consumetype.js"></script>
<?php require_once __DIR__ . '/../layout/footer.php'; ?>