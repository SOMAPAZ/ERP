<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="container mt-5">
        <h2>Tipo de Consumo</h2>
        <a href="/create-consumeType" class="btn btn-primary mb-3">Crear Tipo de Consumo</a>
        <div id="consumetype-tabla"></div>
    </div>
    <script src="/js/consumetype.js"></script>
</main>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>