<?php require_once __DIR__ . '/../layout/header.php'; ?>

<main>
    <div class="form-container">
        <h2>Editar Tipo de Consumo</h2>
        <?php if (isset($consumeType)): ?>
            <form method="POST" action="/update-consumeType/<?php echo htmlspecialchars($consumeType['id']); ?>">
                <div class="form-group">
                    <label for="name" class="form-label">Nombre de la Tipo de Consumo</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($consumeType['name']); ?>" required>
                </div>
                <button type="submit" class="btn-submit">Actualizar</button>
            </form>
        <?php else: ?>
            <p>Error: El tipo de consumo no está definido.</p>
        <?php endif; ?>

    </div>
</main>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>