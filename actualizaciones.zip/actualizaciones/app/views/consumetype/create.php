<?php require_once __DIR__ . '/../layout/header.php'; ?>

<div class="form-container">
    <h2>Crear Nuevo Tipo de Consumo</h2>
    <form method="POST" action="/create-consumeType">
        <div class="form-group">
            <label for="name" class="form-label">Nombre del Tipo de Consumo</label>
            <input type="text" class="form-control" id="name" name="name" required>
        </div>
        <button type="submit" class="btn-submit">Crear</button>
    </form>
</div>