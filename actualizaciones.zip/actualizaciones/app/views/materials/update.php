<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="form-container">
        <h2>Editar Material</h2>
        <?php if (isset($materials)): ?>
            <form method="POST" action="/update-materials/<?php echo htmlspecialchars($materials['id']); ?>">
                <div class="form-group">
                    <label for="name" class="form-label">Nombre de la Material</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($materials['name']); ?>" required>
                </div>
                <button type="submit" class="btn-submit">Actualizar</button>
            </form>
        <?php else: ?>
            <p>Material no encontrado.</p>
        <?php endif; ?>
    </div>
</main>
<?php require_once __DIR__ . '/../layout/footer.php'; ?>