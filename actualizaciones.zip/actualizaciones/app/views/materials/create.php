<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="form-container">
        <h2>Crear Nuevo Material</h2>
        <form method="POST" action="/create-materials">
            <div class="form-group">
                <label for="name" class="form-label">Nombre del Material</label>
                <input type="text" class="form-control" id="name" name="name" required>
            </div>
            <button type="submit" class="btn-submit">Crear</button>
        </form>
    </div>
</main>
<?php require_once __DIR__ . '/../layout/footer.php'; ?>