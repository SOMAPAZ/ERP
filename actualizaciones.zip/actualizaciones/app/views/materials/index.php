<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="container mt-5">
        <h2>Lista de Materiales</h2>
        <a href="/create-materials" class="btn btn-primary mb-3">Crear Material</a>
        <?php if (!empty($materials)): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($materials as $material): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($material['id']); ?></td>
                            <td><?php echo htmlspecialchars($material['name']); ?></td>
                            <td>
                                <a href="/update-materials/<?php echo $material['id']; ?>" class="btn btn-warning">Editar</a>
                                <a href="/delete-materials/<?php echo $material['id']; ?>" class="btn btn-danger" onclick="return confirm('¿Estás seguro de que deseas eliminar este material?');">Eliminar</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No hay materiales disponibles.</p>
        <?php endif; ?>
    </div>
</main>
<?php require_once __DIR__ . '/../layout/footer.php'; ?>