<?php require_once __DIR__ . '/../layout/header.php'; ?>
<main>
    <div class="container mt-5">
        <h2>Materiales</h2>
        <a href="/create-materials" class="btn btn-primary mb-3">Crear Material</a>
        <div id="material-tabla"></div>
    </div>
    <script src="/js/materials.js"></script>
</main>
<?php require_once __DIR__ . '/../layout/footer.php'; ?>