<?php

namespace app\controllers;

use App\Config\DatabaseConfig;
use App\Core\Controller;
use App\Core\Router;
use App\Models\Category;
use App\Models\QueryBuilder;


class DeleteController extends Controller
{
    public function delete(Router $router, $modelName, $redirectUrl, $id)
    {
        try {
            $modelClass = "App\\Models\\" . ucfirst($modelName);
            $model = new $modelClass(DatabaseConfig::getConnection());

            $success = $model->delete($id);

            if (!$success) {
                throw new \Exception("No se pudo eliminar el registro");
            }

            header("Location: /$redirectUrl");
            exit;
        } catch (\Exception $e) {
            $message = ['type' => 'danger', 'text' => $e->getMessage()];
            $router->render(strtolower($modelName) . '/index', ['message' => $message]);
        }
    }
    public function categoryDelete(Router $router, $id)
    {
        $this->delete($router, 'category', 'categoryIndex', $id);
    }
    public function colonyDelete(Router $router, $id)
    {
        $this->delete($router, 'colony', 'colonyIndex', $id);
    }
    public function consumeTypeDelete(Router $router, $id)
    {
        $this->delete($router, 'consumeType', 'consumeTypeIndex', $id);
    }
    public function intakeTypeDelete(Router $router, $id)
    {
        $this->delete($router, 'intakeType', 'intakeTypeIndex', $id);
    }
    public function localityDelete(Router $router, $id)
    {
        $this->delete($router, 'locality', 'localityIndex', $id);
    }
    public function materialsDelete(Router $router, $id)
    {
        $this->delete($router, 'materials', 'materialsIndex', $id);
    }
    public function priorityDelete(Router $router, $id)
    {
        $this->delete($router, 'priority', 'priorityIndex', $id);
    }
    public function rolesDelete(Router $router, $id)
    {
        $this->delete($router, 'roles', 'rolesIndex', $id);
    }
    public function unitiesDelete(Router $router, $id)
    {
        $this->delete($router, 'unities', 'unitiesIndex', $id);
    }
    public function userStorageDelete(Router $router, $id)
    {
        $this->delete($router, 'userStorage', 'userStorageIndex', $id);
    }
    public function zoneDelete(Router $router, $id)
    {
        $this->delete($router, 'zone', 'zoneIndex', $id);
    }
    public function incidenceDelete(Router $router, $id)
    {
        $this->delete($router, 'incidence', 'incidenceIndex', $id);
    }
    public function employmentDelete(Router $router, $id)
    {
        $this->delete($router, 'employment', 'employmentIndex', $id);
    }
    public function userDelete(Router $router, $id)
    {
        $this->delete($router, 'user', 'userIndex', $id);
    }
    public function notificationDelete(Router $router, $id)
    {
        $this->delete($router, 'notification', 'notificationIndex', $id);
    }
    public function formatDelete(Router $router, $id)
    {
        $this->delete($router, 'format', 'formatIndex', $id);
    }
    public function serviceRightsDelete(Router $router, $id)
    {
        $this->delete($router, 'serviceRights', 'serviceRightsIndex', $id);
    }
    public function measuredDelete(Router $router, $id)
    {
        $this->delete($router, 'measured', 'measuredIndex', $id);
    }
    public function rateDelete(Router $router, $id)
    {
        $this->delete($router, 'rate', 'rateIndex', $id);
    }
}
