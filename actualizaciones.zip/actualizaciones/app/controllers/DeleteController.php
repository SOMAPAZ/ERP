<?php

namespace app\controllers;

use App\Config\DatabaseConfig;
use App\Core\Controller;
use App\Core\Router;



class DeleteController
{

    // Constructor para iniciar sesión y generar token CSRF
    public function __construct()
    {
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
        $this->generateCsrfToken();
    }

    //metodo para generar el tokem CSRF y almacenarlo en la sesion
    private function generateCsrfToken()
    {
        if (!isset($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
            error_log("Token CSRF generado: " . $_SESSION['csrf_token']);
        }
    }

    public function showCsrfToken()
    {
        if (
            session_status() == PHP_SESSION_NONE
        ) {
            session_start();
        }
        if (isset($_SESSION['csrf_token'])) {
            echo "CSRF Token: " . $_SESSION['csrf_token'];
        } else {
            echo "CSRF Token no está definido.";
        }
    }

    //metodo para validar el token CSRF
    private function validateCsrfToken()
    {
        if (
            session_status() == PHP_SESSION_NONE
        ) {
            session_start(); // Asegúrate de que la sesión está iniciada
        }

        if (
            empty($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']
        ) {
            error_log("Token CSRF no válido. Recibido: ");
            die("Token CSRF inválido."); // Detener ejecución si el token es inválido
        }
    }



    public function delete(Router $router, $modelName, $redirectUrl, $id)
    {
        $this->validateCsrfToken();
        try {
            $modelClass = "App\\Models\\" . ucfirst($modelName);
            $model = new $modelClass(DatabaseConfig::getConnection());
            $resultado = $model->delete($id);
            if (!$resultado) {
                echo json_encode(["resultado" => "Error al eliminar el registro"]);
            }
            $respuesta = array(
                "resultado" => "Exito",
                "id" => $id,
            );
            echo json_encode($respuesta);
        } catch (\Exception $e) {
            $message = ['type' => 'danger', 'text' => $e->getMessage()];
            $router->render(strtolower($modelName) . '/index', ['message' => $message]);
        }
    }
    public function categoryDelete(Router $router, $id)
    {
        $this->delete($router, 'category', 'categoryIndex', $id);
    }
    public function colonyDelete(Router $router, $id)
    {
        $this->delete($router, 'colony', 'colonyIndex', $id);
    }
    public function consumeTypeDelete(Router $router, $id)
    {
        $this->delete($router, 'consumeType', 'consumeTypeIndex', $id);
    }
    public function intakeTypeDelete(Router $router, $id)
    {
        $this->delete($router, 'intakeType', 'intakeTypeIndex', $id);
    }
    public function localityDelete(Router $router, $id)
    {
        $this->delete($router, 'locality', 'localityIndex', $id);
    }
    public function materialsDelete(Router $router, $id)
    {
        $this->delete($router, 'materials', 'materialsIndex', $id);
    }
    public function priorityDelete(Router $router, $id)
    {
        $this->delete($router, 'priority', 'priorityIndex', $id);
    }
    public function rolesDelete(Router $router, $id)
    {
        $this->delete($router, 'roles', 'rolesIndex', $id);
    }
    public function unitiesDelete(Router $router, $id)
    {
        $this->delete($router, 'unities', 'unitiesIndex', $id);
    }
    public function userStorageDelete(Router $router, $id)
    {
        $this->delete($router, 'userStorage', 'userStorageIndex', $id);
    }
    public function zoneDelete(Router $router, $id)
    {
        $this->delete($router, 'zone', 'zoneIndex', $id);
    }
    public function incidenceDelete(Router $router, $id)
    {
        $this->delete($router, 'incidence', 'incidenceIndex', $id);
    }
    public function employmentDelete(Router $router, $id)
    {
        $this->delete($router, 'employment', 'employmentIndex', $id);
    }
    public function userDelete(Router $router, $id)
    {
        $this->delete($router, 'user', 'userIndex', $id);
    }
    public function notificationDelete(Router $router, $id)
    {
        $this->delete($router, 'notification', 'notificationIndex', $id);
    }
    public function formatDelete(Router $router, $id)
    {
        $this->delete($router, 'format', 'formatIndex', $id);
    }
    public function serviceRightsDelete(Router $router, $id)
    {
        $this->delete($router, 'serviceRights', 'serviceRightsIndex', $id);
    }
    public function measuredDelete(Router $router, $id)
    {
        $this->delete($router, 'measured', 'measuredIndex', $id);
    }
    public function rateDelete(Router $router, $id)
    {
        $this->delete($router, 'rate', 'rateIndex', $id);
    }
}
