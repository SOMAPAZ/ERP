<?php

namespace App\Controllers;

use App\Config\DatabaseConfig;
use App\Core\Controller;
use App\Core\Router;



class CreateController extends Controller
{
    public function store(Router $router, $modelName, $redirectUrl)
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = $_POST;
            try {
                $modelClass = "App\\Models\\" . ucfirst($modelName);
                $model = new $modelClass(DatabaseConfig::getConnection());
                $resultado = $model->create($data);
                if (!$resultado) {
                    echo json_encode(["resultado" => "Error al crear el registro es el if"]);
                }
                if (method_exists($model, 'getCreateResponse')) {
                    $resultado = $model->getCreateResponse($data);
                    echo json_encode($resultado);
                    return;
                }
            } catch (\Exception $e) {
                echo json_encode([
                    "resultado" => "Error al crear el registro es el try",
                    "mensaje" => $e->getMessage()
                ]);
            }
        }
    }
    public function categoryStore(Router $router)
    {
        $this->store($router, 'Category', 'categoryIndex');
    }
    public function colonyStore(Router $router)
    {
        $this->store($router, 'Colony', 'colonyIndex');
    }
    public function consumeTypeStore(Router $router)
    {
        $this->store($router, 'consumeType', 'consumeTypeIndex');
    }
    public function intakeTypeStore(Router $router)
    {
        $this->store($router, 'intakeType', 'intakeTypeIndex');
    }
    public function localityStore(Router $router)
    {
        $this->store($router, 'locality', 'localityIndex');
    }
    public function materialsStore(Router $router)
    {
        $this->store($router, 'materials', 'materialsIndex');
    }
    public function priorityStore(Router $router)
    {
        $this->store($router, 'priority', 'priorityIndex');
    }
    public function rolesStore(Router $router)
    {
        $this->store($router, 'roles', 'rolesIndex');
    }
    public function unitiesStore(Router $router)
    {
        $this->store($router, 'unities', 'unitiesIndex');
    }
    public function userStorageStore(Router $router)
    {
        $this->store($router, 'userStorage', 'userStorageIndex');
    }
    public function zoneStore(Router $router)
    {
        $this->store($router, 'zone', 'zoneIndex');
    }
    public function incidenceCreate(Router $router)
    {
        $router->render('incidence/create');
    }
    public function incidenceStore(Router $router)
    {
        $this->store($router, 'incidence', 'incidenceIndex');
    }
    public function employmentCreate(Router $router)
    {
        $router->render('employments/create');
    }
    public function employmentStore(Router $router)
    {
        $this->store($router, 'employment', 'employmentIndex');
    }
    public function userCreate(Router $router)
    {
        $router->render('user/create');
    }
    public function userStore(Router $router)
    {
        $this->store($router, 'User', 'userIndex');
    }
    public function notificationCreate(Router $router)
    {
        $router->render('notification/create');
    }
    public function notificationStore(Router $router)
    {
        $this->store($router, 'notification', 'notificationIndex');
    }
    public function formatCreate(Router $router)
    {
        $router->render('format/create');
    }
    public function formatStore(Router $router)
    {
        $this->store($router, 'format', 'formatIndex');
    }
    public function serviceRightsCreate(Router $router)
    {
        $router->render('servicerights/create');
    }
    public function serviceRightsStore(Router $router)
    {
        $this->store($router, 'servicerights', 'serviceRightsIndex');
    }
    public function measuredCreate(Router $router)
    {
        $router->render('measured/create');
    }
    public function measuredStore(Router $router)
    {
        $this->store($router, 'measured', 'measuredIndex');
    }
    public function rateCreate(Router $router)
    {
        $router->render('rates/create');
    }
    public function rateStore(Router $router)
    {
        $this->store($router, 'rate', 'rateIndex');
    }
}
