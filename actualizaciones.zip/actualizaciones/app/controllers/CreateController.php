<?php

namespace App\Controllers;

use App\Models\Category;
use App\Config\DatabaseConfig;
use App\Core\Controller;
use App\Core\Router;
use App\Models\Colony;
use App\Models\Employment;
use App\Models\Roles;
use App\Models\User;
use App\Models\Locality;
use App\Models\Zone;
use App\Models\IntakeType;
use App\Models\ConsumeType;
use App\Models\QueryBuilder;
use App\Models\Measured;


class CreateController extends Controller
{
    public function createForm(Router $router, $modelName)
    {
        $router->render(strtolower($modelName) . '/create');
    }

    public function store(Router $router, $modelName, $redirectUrl)
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = $_POST;
            try {
                $modelClass = "App\\Models\\" . ucfirst($modelName);
                $model = new $modelClass(DatabaseConfig::getConnection());
                // Obtener el próximo ID
                $lastId = $model->getNextId();
                // Asignar el siguiente ID al dato, si es necesario
                $resultado = $model->create($data);
                if (!$resultado) {
                    echo json_encode(["resultado" => "Error al crear el registro es el if"]);
                }
                if (method_exists($model, 'getCreateResponse')) {
                    $resultado = $model->getCreateResponse($data);
                    echo json_encode($resultado);
                    return;
                }
            } catch (\Exception $e) {
                echo json_encode([
                    "resultado" => "Error al crear el registro es el try",
                    "mensaje" => $e->getMessage()
                ]);
            }
        }
    }


    public function categoryCreate(Router $router)
    {
        $this->createForm($router, 'Category');
    }

    public function categoryStore(Router $router)
    {
        $this->store($router, 'Category', 'categoryIndex');
    }

    public function colonyCreate(Router $router)
    {
        $this->createForm($router, 'Colony');
    }

    public function colonyStore(Router $router)
    {
        $this->store($router, 'Colony', 'colonyIndex');
    }

    public function consumeTypeCreate(Router $router)
    {
        $this->createForm($router, 'consumeType');
    }
    public function consumeTypeStore(Router $router)
    {
        $this->store($router, 'consumeType', 'consumeTypeIndex');
    }

    public function intakeTypeCreate(Router $router)
    {
        $this->createForm($router, 'intakeType');
    }
    public function intakeTypeStore(Router $router)
    {
        $this->store($router, 'intakeType', 'intakeTypeIndex');
    }

    public function localityCreate(Router $router)
    {
        $this->createForm($router, 'locality');
    }
    public function localityStore(Router $router)
    {
        $this->store($router, 'locality', 'localityIndex');
    }

    public function materialsCreate(Router $router)
    {
        $this->createForm($router, 'materials');
    }
    public function materialsStore(Router $router)
    {
        $this->store($router, 'materials', 'materialsIndex');
    }

    public function priorityCreate(Router $router)
    {
        $this->createForm($router, 'priority');
    }
    public function priorityStore(Router $router)
    {
        $this->store($router, 'priority', 'priorityIndex');
    }

    public function rolesCreate(Router $router)
    {
        $this->createForm($router, 'roles');
    }
    public function rolesStore(Router $router)
    {
        $this->store($router, 'roles', 'rolesIndex');
    }
    public function unitiesCreate(Router $router)
    {
        $this->createForm($router, 'unities');
    }
    public function unitiesStore(Router $router)
    {
        $this->store($router, 'unities', 'unitiesIndex');
    }

    public function userStorageCreate(Router $router)
    {
        $this->createForm($router, 'userStorage');
    }
    public function userStorageStore(Router $router)
    {
        $this->store($router, 'userStorage', 'userStorageIndex');
    }

    public function zoneCreate(Router $router)
    {
        $this->createForm($router, 'zone');
    }
    public function zoneStore(Router $router)
    {
        $this->store($router, 'zone', 'zoneIndex');
    }

    public function incidenceCreate(Router $router)
    {
        $categoryModel = new Category(DatabaseConfig::getConnection());
        $categories = $categoryModel->consultar();

        $router->render('incidence/create', ['categories' => $categories]);
    }



    public function incidenceStore(Router $router)
    {
        $this->store($router, 'incidence', 'incidenceIndex');
    }

    public function employmentCreate(Router $router)
    {

        $router->render('employments/create');
    }


    public function employmentStore(Router $router)
    {
        $this->store($router, 'employment', 'employmentIndex');
    }

    public function userCreate(Router $router)
    {

        $router->render('user/create');
    }

    public function userStore(Router $router)
    {
        $this->store($router, 'User', 'userIndex');
    }
    public function notificationCreate(Router $router)
    {
        $db = DatabaseConfig::getConnection();
        $queryBuilder = new QueryBuilder($db);

        $account = $queryBuilder->table('account')
            ->select(['id', 'name'])
            ->executeSelect();

        $router->render('notification/create', [
            'account' => $account
        ]);
    }
    public function notificationStore(Router $router)
    {
        $this->store($router, 'notification', 'notificationIndex');
    }

    public function formatCreate(Router $router)
    {
        $db = DatabaseConfig::getConnection();
        $queryBuilder = new QueryBuilder($db);

        $account = $queryBuilder->table('account')
            ->select(['id', 'name'])
            ->executeSelect();
        $router->render('format/create', [
            'account' => $account
        ]);
    }
    public function formatStore(Router $router)
    {
        $this->store($router, 'format', 'formatIndex');
    }

    public function serviceRightsCreate(Router $router)
    {
        $db = DatabaseConfig::getConnection();
        $queryBuilder = new QueryBuilder($db);

        $service = $queryBuilder->table('services')
            ->select(['id', 'name'])
            ->executeSelect();
        $intakeType = $queryBuilder->table('intake_type')
            ->select(['id', 'name'])
            ->executeSelect();

        $router->render('servicerights/create', [
            'service' => $service,
            'intakeType' => $intakeType
        ]);
    }
    public function serviceRightsStore(Router $router)
    {
        $this->store($router, 'servicerights', 'serviceRightsIndex');
    }
    public function measuredCreate(Router $router)
    {
        $db = DatabaseConfig::getConnection();
        $queryBuilder = new QueryBuilder($db);

        $measuredModel = new Measured(DatabaseConfig::getConnection());
        $measured = $measuredModel->consultar();

        $intaketype = $queryBuilder->table('intake_type')
            ->select(['id', 'name'])
            ->executeSelect();
        $consumetype = $queryBuilder->table('consume_type')
            ->select(['id', 'name'])
            ->executeSelect();

        $router->render('measured/create', [
            'measured' => $measured,
            'intakeType' => $intaketype,
            'consumeType' => $consumetype
        ]);
    }
    public function measuredStore(Router $router)
    {
        $this->store($router, 'measured', 'measuredIndex');
    }
    public function rateCreate(Router $router)
    {
        $db = DatabaseConfig::getConnection();
        $queryBuilder = new QueryBuilder($db);

        $consumeIntake = $queryBuilder->table('consume_intake ci')
            ->select([
                'ci.id',
                'it.name AS nombre_intake_type',
                'ct.name AS nombre_consume_type'
            ])
            ->join('intake_type it', 'ci.id_intaketype = it.id')
            ->join('consume_type ct', 'ci.id_consumtype = ct.id')
            ->executeSelect();

        $options = [];
        foreach ($consumeIntake as $row) {
            $options[] = [
                'id' => $row['id'],
                'name' => $row['nombre_intake_type'] . ' - ' . $row['nombre_consume_type']
            ];
        }

        $options = array_unique($options, SORT_REGULAR);

        $router->render('rates/create', [
            'options' => $options
        ]);
    }

    public function rateStore(Router $router)
    {
        $this->store($router, 'rate', 'rateIndex');
    }
}
