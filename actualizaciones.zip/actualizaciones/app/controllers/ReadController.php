<?php

namespace App\Controllers;

require_once __DIR__ . '/../../vendor/autoload.php';

use App\Core\Response;
use App\Core\Router;
use App\Config\DatabaseConfig;
use App\Models\{
    Colony,
    Category,
    User,
    Employment,
    Rate,
    ConsumeType,
    IntakeType,
    Locality,
    Materials,
    Priority,
    Roles,
    Unities,
    UserStorage,
    Zone,
    Incidence,
    ServiceRights,
    Format,
    Measured,
    Notification
};
use App\Core\Controller;

class ReadController extends Controller
{
    private function index(Router $router, $model, $view, $modelName)
    {
        try {
            $data = (new $model(DatabaseConfig::getConnection()))->consultar();
            $router->render($view, [$modelName => $data]);
        } catch (\Exception $e) {
            Response::error("Error al obtener los datos de $modelName: " . $e->getMessage());
        }
    }

    public function colonyIndex(Router $router)
    {

        $this->index($router, Colony::class, 'colony/index', 'colonies');
    }

    public function categoryIndex(Router $router)
    {

        $this->index($router, Category::class, 'category/index', 'categories');
    }

    public function userIndex(Router $router)
    {
        $this->index($router, User::class, 'user/index', 'users');
    }

    public function employmentIndex(Router $router)
    {
        $this->index($router, Employment::class, 'employments/index', 'employments');
    }

    public function rateIndex(Router $router)
    {
        $this->index($router, Rate::class, 'rates/index', 'rates');
    }

    public function consumeTypeIndex(Router $router)
    {
        $this->index($router, ConsumeType::class, 'consumetype/index', 'consumeTypes');
    }

    public function intakeTypeIndex(Router $router)
    {
        $this->index($router, IntakeType::class, 'intaketype/index', 'intakeTypes');
    }

    public function localityIndex(Router $router)
    {
        $this->index($router, Locality::class, 'locality/index', 'localities');
    }

    public function materialsIndex(Router $router)
    {
        $this->index($router, Materials::class, 'materials/index', 'materials');
    }

    public function priorityIndex(Router $router)
    {
        $this->index($router, Priority::class, 'priority/index', 'priorities');
    }

    public function rolesIndex(Router $router)
    {
        $this->index($router, Roles::class, 'roles/index', 'roles');
    }

    public function unitiesIndex(Router $router)
    {
        $this->index($router, Unities::class, 'unities/index', 'unities');
    }

    public function userStorageIndex(Router $router)
    {
        $this->index($router, UserStorage::class, 'userstorage/index', 'userStorages');
    }

    public function zoneIndex(Router $router)
    {
        $this->index($router, Zone::class, 'zone/index', 'zones');
    }

    public function incidenceIndex(Router $router)
    {
        $this->index($router, Incidence::class, 'incidence/index', 'incidences');
    }

    public function serviceRightsIndex(Router $router)
    {
        $this->index($router, ServiceRights::class, 'servicerights/index', 'serviceRights');
    }

    public function formatIndex(Router $router)
    {
        $this->index($router, Format::class, 'format/index', 'formats');
    }

    public function measuredIndex(Router $router)
    {
        $this->index($router, Measured::class, 'measured/index', 'measured');
    }

    public function notificationIndex(Router $router)
    {
        $this->index($router, Notification::class, 'notification/index', 'notifications');
    }
}
