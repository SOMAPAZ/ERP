<?php

namespace App\Controllers;

use App\Config\DatabaseConfig;

class APIController
{
    public static function handleRequest($modelName)
    {
        $modelClass = "App\\Models\\" . ucfirst($modelName);
        $errorMessage = "Error al obtener los datos de $modelName";
        try {
            $dbConfig = new DatabaseConfig();
            $conn = $dbConfig->getConnection();

            $model = new $modelClass($conn);
            $resultado = $model->consultar();

            echo json_encode($resultado);
        } catch (\Exception $e) {
            echo json_encode(['error' => "$errorMessage: " . $e->getMessage()]);
        }
    }
    public static function consumeIntake()
    {
        self::handleRequest('consumeIntake');
    }
    public static function services()
    {
        self::handleRequest('services');
    }
    public static function account()
    {
        self::handleRequest('account');
    }
    public static function colonies()
    {
        self::handleRequest('colony');
    }
    public static function usertype()
    {
        self::handleRequest('usertype');
    }
    public static function servicetype()
    {
        self::handleRequest('servicetype');
    }
    public static function servicestatus()
    {
        self::handleRequest('servicestatus');
    }
    public static function categories()
    {
        self::handleRequest('category');
    }

    public static function consumetypes()
    {
        self::handleRequest('consumeType');
    }

    public static function employments()
    {
        self::handleRequest('employment');
    }

    public static function format()
    {
        self::handleRequest('format');
    }
    public static function incidence()
    {
        self::handleRequest('incidence');
    }
    public static function intake_type()
    {
        self::handleRequest('intakeType');
    }
    public static function locality()
    {
        self::handleRequest('locality');
    }
    public static function materials()
    {
        self::handleRequest('materials');
    }
    public static function measured()
    {
        self::handleRequest('measured');
    }
    public static function notification()
    {
        self::handleRequest('notification');
    }
    public static function priority()
    {
        self::handleRequest('priority');
    }
    public static function rate()
    {
        self::handleRequest('rate');
    }
    public static function roles()
    {
        self::handleRequest('roles');
    }
    public static function serviceRights()
    {
        self::handleRequest('serviceRights');
    }
    public static function unities()
    {
        self::handleRequest('unities');
    }
    public static function user()
    {
        self::handleRequest('user');
    }
    public static function userStorage()
    {
        self::handleRequest('userStorage');
    }
    public static function zone()
    {
        self::handleRequest('zone');
    }
}
