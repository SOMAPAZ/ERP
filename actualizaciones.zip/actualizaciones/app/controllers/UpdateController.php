<?php

namespace App\Controllers;

use App\Config\DatabaseConfig;
use App\Core\Controller;
use App\Models\Category;
use App\Models\Roles;
use App\Core\Router;
use App\Models\Employment;
use App\Models\QueryBuilder;
use App\Models\Incidence;
use App\Models\User;
use App\Models\Colony;
use App\Models\Locality;
use App\Models\Zone;
use App\Models\IntakeType;
use App\Models\ConsumeType;
use App\Models\Notification;
use App\Models\ServiceRights;
use App\Models\Format;
use App\Models\Measured;
use App\Models\Rate;

class UpdateController extends Controller
{
    public function editForm(Router $router, $modelName, $id)
    {
        try {
            $modelClass = "App\Models\\" . ucfirst($modelName);
            $model = new $modelClass(DatabaseConfig::getConnection());
            $record = $model->findById($id);

            if (!$record) {
                throw new \Exception("Registro no encontrado");
            }
            $record = (array) $record;

            $router->render(strtolower($modelName) . '/update', [$modelName => $record]);
        } catch (\Exception $e) {
            $message = ["type" => 'danger', 'text' => $e->getMessage()];
            $router->render(strtolower($modelName) . '/index', ['message' => $message]);
        }
    }

    public function update(Router $router, $modelName, $redirectUrl, $id)
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = $_POST;
            try {
                $modelClass = "App\Models\\" . ucfirst($modelName);
                $model = new $modelClass(DatabaseConfig::getConnection());
                $model->update($id, $data);
                header("Location: /$redirectUrl");
                exit;
            } catch (\Exception $e) {
                $message = ['type' => 'danger', 'text' => "Error al actualizar $modelName: " . $e->getMessage()];
                $router->render(strtolower($modelName) . '/update', ['message' => $message, 'record' => $data]);
            }
        }
    }
    public function CategoryEdit(Router $router, $id)
    {
        $this->editForm($router, 'category', $id);
    }
    public function CategoryUpdate(Router $router, $id)
    {
        $this->update($router, 'category', 'categoryIndex', $id);
    }

    public function ColonyUpdate(Router $router, $id)
    {
        $this->update($router, 'colony', 'colonyIndex', $id);
    }
    public function ColonyEdit(Router $router, $id)
    {
        $this->editForm($router, 'colony', $id);
    }

    public function consumeTypeUpdate(Router $router, $id)
    {
        $this->update($router, 'consumeType', 'consumeTypeIndex', $id);
    }
    public function consumeTypeEdit(Router $router, $id)
    {
        $this->editForm($router, 'consumeType', $id);
    }

    public function intakeTypeUpdate(Router $router, $id)
    {
        $this->update($router, 'intakeType', 'intakeTypeIndex', $id);
    }
    public function intakeTypeEdit(Router $router, $id)
    {
        $this->editForm($router, 'intakeType', $id);
    }

    public function localityUpdate(Router $router, $id)
    {
        $this->update($router, 'locality', 'localityIndex', $id);
    }
    public function localityEdit(Router $router, $id)
    {
        $this->editForm($router, 'locality', $id);
    }
    public function materialsUpdate(Router $router, $id)
    {
        $this->update($router, 'materials', 'materialsIndex', $id);
    }
    public function materialsEdit(Router $router, $id)
    {
        $this->editForm($router, 'materials', $id);
    }
    public function priorityUpdate(Router $router, $id)
    {
        $this->update($router, 'priority', 'priorityIndex', $id);
    }
    public function priorityEdit(Router $router, $id)
    {
        $this->editForm($router, 'priority', $id);
    }
    public function rolesUpdate(Router $router, $id)
    {
        $this->update($router, 'roles', 'rolesIndex', $id);
    }
    public function rolesEdit(Router $router, $id)
    {
        $this->editForm($router, 'roles', $id);
    }

    public function unitiesEdit(Router $router, $id)
    {
        $this->editForm($router, 'unities', $id);
    }

    public function unitiesUpdate(Router $router, $id)
    {
        $this->update($router, 'unities', 'unitiesIndex', $id);
    }

    public function userStorageEdit(Router $router, $id)
    {
        $this->editForm($router, 'userStorage', $id);
    }
    public function userStorageUpdate(Router $router, $id)
    {
        $this->update($router, 'userStorage', 'userStorageIndex', $id);
    }
    public function zoneEdit(Router $router, $id)
    {
        $this->editForm($router, 'zone', $id);
    }
    public function zoneUpdate(Router $router, $id)
    {
        $this->update($router, 'zone', 'zoneIndex', $id);
    }

    public function incidenceEdit(Router $router, $id)
    {
        try {
            $incidenceModel = new Incidence(DatabaseConfig::getConnection());
            $incidence = $incidenceModel->findById($id);

            if (!$incidence) {
                throw new \Exception("Incidencia no encontrada");
            }

            $categoryModel = new Category(DatabaseConfig::getConnection());
            $categories = $categoryModel->consultar();

            $router->render('incidence/update', [
                'incidence' => $incidence,
                'categories' => $categories
            ]);
        } catch (\Exception $e) {
            $router->render('incidence/index', [
                'message' => [
                    'type' => 'danger',
                    'text' => $e->getMessage()
                ]
            ]);
        }
    }


    public function incidenceUpdate(Router $router, $id)
    {
        $this->update($router, 'incidence', 'incidenceIndex', $id);
    }

    public function employmentEdit(Router $router, $id)
    {
        try {
            $employmentModel = new Employment(DatabaseConfig::getConnection());
            $employment = $employmentModel->findById($id);
            if (!$employment) {
                throw new \Exception("Empleado no encontrado");
            }

            $rolesModel = new Roles(DatabaseConfig::getConnection());
            $roles  = $rolesModel->consultar();

            $router->render('employments/update', [
                'employment' => $employment,
                'roles' => $roles
            ]);
        } catch (\Exception $e) {
            $router->render('employments/index', [
                'message' => [
                    'type' => 'danger',
                    'text' => $e->getMessage()
                ]
            ]);
        }
    }
    public function employmentUpdate(Router $router, $id)
    {
        $this->update($router, 'employment', 'employmentIndex', $id);
    }


    public function userEdit(Router $router, $id)
    {
        $db = DatabaseConfig::getConnection();
        $queryBuilder = new QueryBuilder($db);

        try {
            $userModel = new User(DatabaseConfig::getConnection());
            $user = $userModel->findById($id);
            if (!$user) {
                throw new \Exception("Usuario no encontrado");
            }

            $coloniesModel = new Colony(DatabaseConfig::getConnection());
            $colonies = $coloniesModel->consultar();
            $localitiesModel = new Locality(DatabaseConfig::getConnection());
            $localities = $localitiesModel->consultar();
            $zonesModel = new Zone(DatabaseConfig::getConnection());
            $zones = $zonesModel->consultar();

            $usertype = $queryBuilder->table('user_type')->select(['id', 'name'])->executeSelect();
            $intakeTypesModel = new IntakeType(DatabaseConfig::getConnection());
            $intakeType = $intakeTypesModel->consultar();
            $consumeTypeModel = new ConsumeType(DatabaseConfig::getConnection());
            $consumeTypes = $consumeTypeModel->consultar();
            $serviceType = $queryBuilder->table('service_type')->select(['id', 'name'])->executeSelect();
            $serviceStatus = $queryBuilder->table('service_status')->select(['id', 'name'])->executeSelect();

            $router->render('user/update', [
                'user' => $user,
                'colonies' => $colonies,
                'localities' => $localities,
                'zones' => $zones,
                'intakeType' => $intakeType,
                'userTypes' => $usertype,
                'serviceTypes' => $serviceType,
                'consumeTypes' => $consumeTypes,
                'serviceStatus' => $serviceStatus
            ]);
        } catch (\Throwable $th) {
            error_log($th->getMessage());
            $message = ['type' => 'danger', 'text' => 'Error al cargar el formulario de usuario'];
            $router->render('user/update', ['message' => $message]);
        }
    }


    public function userUpdate(Router $router, $id)
    {
        $this->update($router, 'user', 'userIndex', $id);
    }

    public function notificationEdit(Router $router, $id)
    {
        $db = DatabaseConfig::getConnection();
        $queryBuilder =  new QueryBuilder($db);
        try {
            $notificationModel =  new Notification(DatabaseConfig::getConnection());
            $notification = $notificationModel->findById($id);

            $cuentas = $queryBuilder->table('account a')
                ->select(['a.id', 'a.name'])
                ->executeSelect();

            if (!$notification) {
                throw new \Exception("Notificación no encontrada");
            }

            $router->render('notification/update', [
                'notification' => $notification,
                'cuentas' => $cuentas
            ]);
        } catch (\Exception $e) {
            throw new \Exception("Error al cargar la notificación: " . $e->getMessage());
        }
    }
    public function notificationUpdate(Router $router, $id)
    {
        $this->update($router, 'notification', 'notificationIndex', $id);
    }

    public function formatEdit(Router $router, $id)
    {
        $db = DatabaseConfig::getConnection();
        $queryBuilder = new QueryBuilder($db);


        try {
            $formatModel  = new Format(DatabaseConfig::getConnection());
            $format = $formatModel->findById($id);

            $cuentas = $queryBuilder->table('account a')
                ->select(['a.id', 'a.name'])
                ->executeSelect();

            if (!$format) {
                throw new \Exception("Formato no encontrado");
            }
            $router->render('format/update', [
                'format' => $format,
                'cuentas' => $cuentas
            ]);
        } catch (\Exception $e) {
            throw new \Exception("Error al cargar el formulario de formato: " . $e->getMessage());
        }
    }
    public function formatUpdate(Router $router, $id)
    {
        $this->update($router, 'format', 'formatIndex', $id);
    }

    public function serviceRightsEdit(Router $router, $id)
    {
        $db = DatabaseConfig::getConnection();
        $queryBuilder = new QueryBuilder($db);

        $serviceRightsModel = new ServiceRights(DatabaseConfig::getConnection());
        $serviceRights = $serviceRightsModel->findById($id);
        $service = $queryBuilder->table('services')
            ->select(['id', 'name'])
            ->executeSelect();

        $intakeType = $queryBuilder->table('intake_type')
            ->select(['id', 'name'])
            ->executeSelect();

        $router->render('serviceRights/update', [
            'service_rights' => $serviceRights,
            'service' => $service,
            'intake_type' => $intakeType,

        ]);
    }
    public function serviceRightsUpdate(Router $router, $id)
    {
        $this->update($router, 'serviceRights', 'serviceRightsIndex', $id);
    }

    public function measuredEdit(Router $router, $id)
    {
        $db = DatabaseConfig::getConnection();
        $queryBuilder = new QueryBuilder($db);

        $measuredModel = new Measured(DatabaseConfig::getConnection());
        $measured = $measuredModel->findById($id);

        $intakeType = $queryBuilder->table('intake_type')
            ->select(['id', 'name'])
            ->executeSelect();
        $consumeType = $queryBuilder->table('consume_type')
            ->select(['id', 'name'])
            ->executeSelect();

        $router->render('measured/update', [
            'measured' => $measured,
            'intake_type' => $intakeType,
            'consume_type' => $consumeType
        ]);
    }
    public function measuredUpdate(Router $router, $id)
    {
        $this->update($router, 'measured', 'measuredIndex', $id);
    }
    public function rateEdit(Router $router, $id)
    {
        $db = DatabaseConfig::getConnection();
        $rateModel = new Rate($db);
        $rate = $rateModel->findById($id);

        $queryBuilder = new QueryBuilder($db);
        $consumeIntake = $queryBuilder->table('consume_intake ci')
            ->select([
                'ci.id',
                'CONCAT(it.name, " - ", ct.name) AS name'
            ])
            ->join('intake_type it', 'ci.id_intaketype = it.id')
            ->join('consume_type ct', 'ci.id_consumtype = ct.id')
            ->executeSelect();

        $router->render('rates/update', [
            'rate' => $rate,
            'consume_intake' => $consumeIntake,
        ]);
    }

    public function rateUpdate(Router $router, $id)
    {
        $this->update($router, 'rate', 'rateIndex', $id);
    }
}
