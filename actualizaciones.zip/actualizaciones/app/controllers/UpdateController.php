<?php

namespace App\Controllers;

session_start(); // Debe ir al inicio de tu archivo PHP

use App\Config\DatabaseConfig;
use App\Core\Controller;
use App\Core\Router;

class UpdateController extends Controller
{
    private function validateCsrfToken()
    {
        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
            echo json_encode([
                "resultado" => "Error",
                "mensaje" => "Token CSRF inválido"
            ]);
            exit; // Detener la ejecución si el token no es válido
        }
    }


    public function update(Router $router, $modelName, $redirectUrl, $id)
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->validateCsrfToken();

            $data = $_POST;
            try {
                $modelClass = "App\Models\\" . ucfirst($modelName);
                $model = new $modelClass(DatabaseConfig::getConnection());
                $resultado  = $model->update($id, $data);
                if ($resultado === 0) {
                    echo json_encode(["resultado" => "Error en la actualización"]);
                }
                if (method_exists($model, 'getUpdateResponse')) {
                    $resultado = $model->getUpdateResponse($id, $data);
                    echo json_encode($resultado);
                    return;
                }
            } catch (\Exception $e) {
                echo json_encode([
                    "resultado" => "Error al actualizar el registro es el try",
                    "mensaje" => $e->getMessage()
                ]);
            }
        }
    }
    public function CategoryUpdate(Router $router, $id)
    {
        $this->update($router, 'category', 'categoryIndex', $id);
    }
    public function ColonyUpdate(Router $router, $id)
    {
        $this->update($router, 'colony', 'colonyIndex', $id);
    }
    public function consumeTypeUpdate(Router $router, $id)
    {
        $this->update($router, 'consumeType', 'consumeTypeIndex', $id);
    }
    public function intakeTypeUpdate(Router $router, $id)
    {
        $this->update($router, 'intakeType', 'intakeTypeIndex', $id);
    }
    public function localityUpdate(Router $router, $id)
    {
        $this->update($router, 'locality', 'localityIndex', $id);
    }
    public function materialsUpdate(Router $router, $id)
    {
        $this->update($router, 'materials', 'materialsIndex', $id);
    }
    public function priorityUpdate(Router $router, $id)
    {
        $this->update($router, 'priority', 'priorityIndex', $id);
    }
    public function rolesUpdate(Router $router, $id)
    {
        $this->update($router, 'roles', 'rolesIndex', $id);
    }
    public function unitiesUpdate(Router $router, $id)
    {
        $this->update($router, 'unities', 'unitiesIndex', $id);
    }
    public function userStorageUpdate(Router $router, $id)
    {
        $this->update($router, 'userStorage', 'userStorageIndex', $id);
    }
    public function zoneUpdate(Router $router, $id)
    {
        $this->update($router, 'zone', 'zoneIndex', $id);
    }
    public function incidenceUpdate(Router $router, $id)
    {
        $this->update($router, 'incidence', 'incidenceIndex', $id);
    }
    public function employmentUpdate(Router $router, $id)
    {
        $this->update($router, 'employment', 'employmentIndex', $id);
    }
    public function userUpdate(Router $router, $id)
    {
        $this->update($router, 'user', 'userIndex', $id);
    }
    public function notificationUpdate(Router $router, $id)
    {
        $this->update($router, 'notification', 'notificationIndex', $id);
    }
    public function formatUpdate(Router $router, $id)
    {
        $this->update($router, 'format', 'formatIndex', $id);
    }
    public function serviceRightsUpdate(Router $router, $id)
    {
        $this->update($router, 'serviceRights', 'serviceRightsIndex', $id);
    }
    public function measuredUpdate(Router $router, $id)
    {
        $this->update($router, 'measured', 'measuredIndex', $id);
    }
    public function rateUpdate(Router $router, $id)
    {
        $this->update($router, 'rate', 'rateIndex', $id);
    }
}
