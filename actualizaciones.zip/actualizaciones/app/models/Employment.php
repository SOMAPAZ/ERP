<?php

namespace App\Models;


use App\Models\QueryBuilder;

class Employment
{
    protected static $table = "employments";
    protected static $columns =
    [
        'id',
        'name',
        'lastaname',
        'mail',
        'password',
        'id_rol'
    ];
    private $db;
    public $id;
    public $name;
    public $lastaname;
    public $mail;
    public $password;
    public $id_rol;
    public $nombre_rol;

    private $queryBuilder;

    public function __construct($db, $data = [])
    {
        $this->db = $db;
        $this->queryBuilder = new QueryBuilder($db);
        $this->id = $data['id'] ?? null;
        $this->name = $data['name'] ?? null;
        $this->lastaname = $data['lastaname'] ?? null;
        $this->mail = $data['mail'] ?? null;
        $this->password = $data['password'] ?? null;
        $this->id_rol = $data['id_rol'] ?? null;
        $this->nombre_rol = $data['nombre_rol'] ?? null;
    }


    public function consultar()
    {
        try {
            $queryBuilder = new QueryBuilder($this->db);

            return $queryBuilder->table('employments e')
                ->select([
                    'e.id',
                    'e.name',
                    'e.lastaname',
                    'e.mail',
                    'e.password',
                    'r.name as nombre_rol'
                ])
                ->join('roles r', 'e.id_rol = r.id', 'LEFT')
                ->executeSelect();
        } catch (\Exception $e) {
            throw new \Exception("Error al consultar datos: " . $e->getMessage());
        }
    }
    public function create($data)
    {
        try {
            $queryBuilder = new QueryBuilder($this->db);
            return $queryBuilder->table('employments')
                ->insert([
                    'name' => htmlspecialchars(strip_tags($data['name'])),
                    'lastaname' => htmlspecialchars(strip_tags($data['lastaname'])),
                    'mail' => htmlspecialchars(strip_tags($data['mail'])),
                    'password' => htmlspecialchars(strip_tags($data['password'])),
                    'id_rol' => (int) $data['id_rol']
                ])
                ->executeInsert();
        } catch (\Exception $e) {
            throw new \Exception("Error al crear empleado: " . $e->getMessage());
        }
    }
    public function findById($id)
    {
        $queryBuilder = new QueryBuilder($this->db);
        $result = $queryBuilder->table('employments e')
            ->select(self::$columns)
            ->where('e.id', '=', $id)
            ->executeSelect();
        return $result ? (object)$result[0] : null;
    }
    public function update($id, $data)
    {
        try {
            if (empty($data['name'])) {
                throw new \Exception("El campo 'name' es obligatorio.");
            }
            $queryBuilder = new QueryBuilder($this->db);
            $query = $queryBuilder->table('employments')
                ->update([
                    'name' => htmlspecialchars(strip_tags($data['name'])),
                    'lastaname' => htmlspecialchars(strip_tags($data['lastaname'])),
                    'mail' => htmlspecialchars(strip_tags($data['mail'])),
                    'password' => htmlspecialchars(strip_tags($data['password'])),
                    'id_rol' => (int) $data['id_rol']
                ])
                ->where('id', '=', $id);
            $result = $query->executeUpdate();
            if ($result === 0) {
                throw new \Exception("No se encontró empleado con el id: $id");
            }
            return $result;
        } catch (\Exception $e) {
            throw new \Exception("Error al actualizar empleado: " . $e->getMessage());
        }
    }
    public function delete($id)
    {
        try {
            $queryBuilder =  new QueryBuilder($this->db);
            $query = $queryBuilder->table(self::$table)
                ->where('id', '=', $id);
            $result = $query->executeDelete();
            if ($result === 0) {
                throw new \Exception("No se eliminó ninguna categoría.");
            }
            return $result;
        } catch (\Exception $e) {
            throw new \Exception("Error al eliminar la categoría: " . $e->getMessage());
        }
    }
}
