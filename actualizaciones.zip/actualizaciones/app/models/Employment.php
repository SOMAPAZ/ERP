<?php

namespace App\Models;


use App\Models\QueryBuilder;

class Employment
{
    protected static $table = "employments";
    protected static $columns =
    [
        'id',
        'nombre',
        'apellido',
        'mail',
        'password',
        'id_rol'
    ];
    private $db;
    public $id;
    public $nombre;
    public $apellido;
    public $mail;
    public $password;
    public $id_rol;
    public $nombre_rol;

    private $queryBuilder;

    public function __construct($db, $data = [])
    {
        $this->db = $db;
        $this->queryBuilder = new QueryBuilder($db);
        $this->id = $data['id'] ?? null;
        $this->nombre = $data['nombre'] ?? null;
        $this->apellido = $data['apellido'] ?? null;
        $this->mail = $data['mail'] ?? null;
        $this->password = $data['password'] ?? null;
        $this->id_rol = $data['id_rol'] ?? null;
        $this->nombre_rol = $data['nombre_rol'] ?? null;
    }
    public function consultar()
    {
        try {
            $queryBuilder = new QueryBuilder($this->db);

            return $queryBuilder->table('employments e')
                ->select([
                    'e.id',
                    'e.nombre',
                    'e.apellido',
                    'e.mail',
                    'e.id_rol',
                    'r.name as nombre_rol'
                ])
                ->join('roles r', 'e.id_rol = r.id', 'LEFT')
                ->executeSelect();
        } catch (\Exception $e) {
            throw new \Exception("Error al consultar datos: " . $e->getMessage());
        }
    }
    public function create($data)
    {
        try {
            $queryBuilder = new QueryBuilder($this->db);
            // Insertar nuevo registro
            $result = $queryBuilder->table('employments')
                ->insert([
                    'nombre' => htmlspecialchars(strip_tags($data['nombre'])),
                    'apellido' => htmlspecialchars(strip_tags($data['apellido'])),
                    'mail' => htmlspecialchars(strip_tags($data['mail'])),
                    'password' => htmlspecialchars(strip_tags($data['password'])),
                    'id_rol' => (int) $data['id_rol']
                ])
                ->executeInsert();
            // Obtener el último ID insertado
            $lastId = $queryBuilder->getLastId();

            return $lastId;
        } catch (\Exception $e) {
            throw new \Exception("Error al crear empleado: " . $e->getMessage());
        }
    }
    public function findById($id)
    {
        $queryBuilder = new QueryBuilder($this->db);
        $result = $queryBuilder->table('employments e')
            ->select(self::$columns)
            ->where('e.id', '=', $id)
            ->executeSelect();
        return $result ? (object)$result[0] : null;
    }

    public function update($id, $data)
    {
        try {

            $queryBuilder = new QueryBuilder($this->db);
            $query = $queryBuilder->table('employments')
                ->update([
                    'id' => (int) $id,
                    'nombre' => htmlspecialchars(strip_tags($data['nombre'])),
                    'apellido' => htmlspecialchars(strip_tags($data['apellido'])),
                    'mail' => htmlspecialchars(strip_tags($data['mail'])),
                    'id_rol' => (int) $data['id_rol']
                ])
                ->where('id', '=', $id);
            $result = $query->executeUpdate();

            return $result;
        } catch (\Exception $e) {
            throw new \Exception("Error al actualizar empleado: " . $e->getMessage());
        }
    }
    public function delete($id)
    {
        try {
            $queryBuilder =  new QueryBuilder($this->db);
            $query = $queryBuilder->table(self::$table)
                ->where('id', '=', $id);
            $result = $query->executeDelete();

            return $result;
        } catch (\Exception $e) {
            throw new \Exception("Error al eliminar la categoría: " . $e->getMessage());
        }
    }

    // Dentro de Employment.php
    public function getNextId()
    {
        $queryBuilder = new QueryBuilder($this->db);
        $lastId = $queryBuilder->table('employments')
            ->select('MAX(id) AS last_id')
            ->executeSelect();
        return isset($lastId[0]['last_id']) ? $lastId[0]['last_id'] + 1 : 1; // Si no hay registros, devolver 1
    }

    public function getCreateResponse($data)
    {
        return [
            "resultado" => "Exito",
            "id" => $this->getNextId(),
            "nombre" => $data['nombre'],
            "apellido" => $data['apellido'],
            "mail" => $data['mail'],
            "id_rol" => $data['id_rol']
        ];
    }
    public function getUpdateResponse($id, $data)
    {
        return  [
            "resultado" => "Exito",
            "id" => $id,
            "nombre" => $data['nombre'],
            "apellido" => $data['apellido'],
            "mail" => $data['mail'],
            "id_rol" => $data['id_rol']
        ];
    }
}
