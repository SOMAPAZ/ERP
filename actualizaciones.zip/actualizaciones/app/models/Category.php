<?php

namespace App\Models;

use App\Models\QueryBuilder;

class Category
{
    protected static $table = "category";
    protected static $columns = ['id', 'name'];

    private $db;
    private $id;
    private $name;

    public function __construct($db, $data = [])
    {
        $this->db = $db;
        $this->id = $data['id'] ?? null;
        $this->name = $data['name'] ?? null;
    }

    public function consultar()
    {
        try {
            $queryBuilder = new QueryBuilder($this->db);
            return $queryBuilder->table(self::$table)
                ->select(self::$columns)
                ->orderBy('id', 'ASC')
                ->executeSelect();
        } catch (\Exception $e) {
            throw new \Exception("Error al consultar categorías: " . $e->getMessage());
        }
    }

    public function create($data)
    {
        try {
            if (empty($data['name'])) {
                throw new \Exception("El campo 'name' es obligatorio.");
            }

            $queryBuilder = new QueryBuilder($this->db);
            $result = $queryBuilder->table(self::$table)
                ->insert(['name' => htmlspecialchars(strip_tags($data['name']))])
                ->executeInsert();

            return $result;
        } catch (\Exception $e) {
            throw new \Exception("Error al crear la categoría: " . $e->getMessage());
        }
    }


    public function findById($id)
    {
        $queryBuilder = new QueryBuilder($this->db);
        $result = $queryBuilder->table(self::$table)
            ->select(self::$columns)
            ->where('id', '=', $id)
            ->executeSelect();

        return $result ? (object)$result[0] : null;
    }


    public function update($id, $data)
    {
        try {
            if (empty($data['name'])) {
                throw new \Exception("El campo 'name' es obligatorio.");
            }
            $queryBuilder = new QueryBuilder($this->db);
            $query = $queryBuilder->table(self::$table)
                ->update([
                    'name' => htmlspecialchars(strip_tags($data['name'])),
                ])
                ->where('id', '=', $id);
            $result = $query->executeUpdate();
            if ($result === 0) {
                throw new \Exception("No se actualizó ninguna categoría.");
            }
            return $result;
        } catch (\Exception $e) {
            throw new \Exception("Error al actualizar la categoría: " . $e->getMessage());
        }
    }
    public function delete($id)
    {
        try {
            $queryBuilder =  new QueryBuilder($this->db);
            $query = $queryBuilder->table(self::$table)
                ->where('id', '=', $id);
            $result = $query->executeDelete();
            if ($result === 0) {
                throw new \Exception("No se eliminó ninguna categoría.");
            }
            return $result;
        } catch (\Exception $e) {
            throw new \Exception("Error al eliminar la categoría: " . $e->getMessage());
        }
    }
}
