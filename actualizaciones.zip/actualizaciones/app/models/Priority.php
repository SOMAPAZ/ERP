<?php

namespace App\Models;

use App\Models\QueryBuilder;

class Priority
{
    protected static $table = "priority";
    protected static $columns = ['id', 'name'];
    private $db;


    public $id;
    public $name;

    public function __construct($db, $data = [])
    {
        $this->id = $data['id'] ?? null;
        $this->name = $arg['name'] ?? null;
        $this->db = $db;
    }

    public function consultar()
    {
        try {
            $queryBuilder = new QueryBuilder($this->db);
            return $queryBuilder->table(self::$table)
                ->select([
                    'id',
                    'name'
                ])
                ->executeSelect();
        } catch (\Throwable $th) {
            throw new \Exception("Error al consultar prioridades: " . $th->getMessage());
        }
    }
    public function create($data)
    {
        try {
            $queryBuilder = new QueryBuilder($this->db);
            $result = $queryBuilder->table(self::$table)
                ->insert([
                    'name' => htmlspecialchars(strip_tags($data['name']))
                ])
                ->executeInsert();
            return $result;
        } catch (\Throwable $th) {
            throw new \Exception("Error al crear prioridades: " . $th->getMessage());
        }
    }
    public function findById($id)
    {
        $queryBuilder = new QueryBuilder($this->db);
        $result = $queryBuilder->table(self::$table)
            ->select(self::$columns)
            ->where('id', '=', $id)
            ->executeSelect();
        return $result[0] ?? null;
    }
    public function update($id, $data)
    {
        try {
            if (empty($data['name'])) {
                throw new \Exception("El campo 'name' es obligatorio.");
            }
            $queryBuilder = new QueryBuilder($this->db);
            $queryBuilder->table(self::$table)
                ->update([
                    'name' => htmlspecialchars(strip_tags($data['name']))
                ])
                ->where('id', '=', $id);
            $result = $queryBuilder->executeUpdate();
            if ($result === 0) {
                throw new \Exception("No se encontró prioridades con el id: $id");
            }
            return $result;
        } catch (\Throwable $th) {
            throw new \Exception("Error al actualizar prioridades: " . $th->getMessage());
        }
    }
    public function delete($id)
    {
        try {
            $queryBuilder =  new QueryBuilder($this->db);
            $query = $queryBuilder->table(self::$table)
                ->where('id', '=', $id);
            $result = $query->executeDelete();
            if ($result === 0) {
                throw new \Exception("No se eliminó ninguna categoría.");
            }
            return $result;
        } catch (\Throwable $th) {
            throw new \Exception("Error al eliminar la categoría: " . $th->getMessage());
        }
    }
}
