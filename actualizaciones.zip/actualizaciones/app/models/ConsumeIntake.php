<?php

namespace App\Models;


use App\Models\QueryBuilder;

class ConsumeIntake
{
    protected static $table = "consume_intake";
    protected static $columns = ['id', 'id_intaketype', 'id_consumtype'];
    private $db;
    public $id;
    public $id_intaketype;
    public $id_consumtype;
    private $queryBuilder;

    public function __construct($db, $data = [])
    {
        $this->db = $db;
        $this->queryBuilder = new QueryBuilder($db);
        $this->id = $data['id'] ?? null;
        $this->id_intaketype = $data['id_intaketype'] ?? null;
        $this->id_consumtype = $data['id_consumtype'] ?? null;
    }

    public function consultar()
    {
        try {
            $queryBuilder = new QueryBuilder($this->db);
            return $queryBuilder->table('consume_intake ci')
                ->select([
                    'ci.id',
                    'ci.id_intaketype',
                    'ci.id_consumtype',
                    'it.name AS nombre_intake_type',
                    'ct.name AS nombre_consume_type'
                ])
                ->join('intake_type it', 'ci.id_intaketype = it.id')
                ->join('consume_type ct', 'ci.id_consumtype = ct.id')
                ->executeSelect();
        } catch (\Exception $e) {
            throw new \Exception("Error al consultar consume_intake: " . $e->getMessage());
        }
    }
}
