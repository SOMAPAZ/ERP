<?php

namespace App\Models;

use PDO;

class QueryBuilder
{
    private $db;
    private $limit;
    private $offset;
    private $table;
    private $columns;
    private $values;
    private $setColumns;
    private $whereConditions;
    private $joinTables;
    private $joinConditions;
    private $params;
    private $orderBy;

    public function __construct($db)
    {
        $this->db = $db;
        $this->limit = null;
        $this->offset = null;
        $this->columns = [];
        $this->values = [];
        $this->setColumns = [];
        $this->whereConditions = [];
        $this->joinTables = [];
        $this->joinConditions = [];
        $this->params = [];
        $this->orderBy = null;
    }

    // Agregar parámetros para la consulta
    public function bindParams($params)
    {
        $this->params = array_merge($this->params, $params);
        return $this;
    }

    // Establecer la tabla
    public function table($table)
    {
        $this->table = $table;
        return $this;
    }

    // Definir las columnas a seleccionar
    public function select($columns = '*')
    {
        $this->columns = is_array($columns) ? $columns : explode(',', $columns);
        return $this;
    }

    public function selectRaw($rawQuery)
    {
        $this->columns[] = $rawQuery;
        return $this;
    }

    // Método para agregar la cláusula ORDER BY
    public function orderBy($column, $direction = 'ASC')
    {
        if (!isset($this->orderBy)) {
            $this->orderBy = "ORDER BY {$column} {$direction}";
        } else {
            $this->orderBy .= ", {$column} {$direction}";
        }
        return $this;
    }

    // Definir las columnas y valores para insertar
    public function insert($data)
    {
        $this->values = $data;
        return $this;
    }

    public function limit($limit)
    {
        $this->limit = $limit;
        return $this;
    }

    public function offset($offset)
    {
        $this->offset = $offset;
        return $this;
    }

    // Definir las columnas y valores para actualizar
    public function update($data)
    {
        $this->setColumns = $data;
        return $this;
    }

    // Agregar condiciones WHERE
    public function where($column, $operator, $value)
    {
        $this->whereConditions[] = "{$column} {$operator} ?";
        $this->params[] = $value;
        return $this;
    }

    // Agregar un JOIN
    public function join($table, $condition, $type = 'LEFT')
    {
        $this->joinTables[] = $table;
        $this->joinConditions[] = "{$type} JOIN {$table} ON {$condition}";
        return $this;
    }

    public function getLastId()
    {
        $query = "SELECT MAX(id) AS last_id FROM {$this->table}";

        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result ? $result['last_id'] : null;
    }
    // Generar la consulta SELECT
    public function buildSelect()
    {
        $columns = implode(', ', $this->columns);
        $query = "SELECT {$columns} FROM {$this->table}";

        // Agregar los JOINs
        if (!empty($this->joinTables)) {
            $query .= ' ' . implode(' ', $this->joinConditions);
        }

        // Agregar las condiciones WHERE
        if (!empty($this->whereConditions)) {
            $query .= ' WHERE ' . implode(' AND ', $this->whereConditions);
        }

        // Agregar la cláusula ORDER BY si está definida
        if (isset($this->orderBy)) {
            $query .= ' ' . $this->orderBy;
        }

        // Agregar el límite si está establecido
        if (isset($this->limit)) {
            $query .= ' LIMIT ' . $this->limit;
        }

        return $query;
    }

    // Generar la consulta INSERT
    public function buildInsert()
    {
        $columns = implode(', ', array_keys($this->values));
        $placeholders = implode(', ', array_fill(0, count($this->values), '?'));
        $query = "INSERT INTO {$this->table} ({$columns}) VALUES ({$placeholders})";
        return $query;
    }

    // Generar la consulta UPDATE
    public function buildUpdate()
    {
        $set = [];
        foreach ($this->setColumns as $column => $value) {
            $set[] = "{$column} = ?";
        }
        $setString = implode(', ', $set);
        $query = "UPDATE {$this->table} SET {$setString}";

        // Agregar las condiciones WHERE
        if (!empty($this->whereConditions)) {
            $query .= ' WHERE ' . implode(' AND ', $this->whereConditions);
        }

        return $query;
    }

    // Generar la consulta DELETE
    public function buildDelete()
    {
        $query = "DELETE FROM {$this->table}";

        if (!empty($this->whereConditions)) {
            $query .= ' WHERE ' . implode(' AND ', $this->whereConditions);
        }

        return $query;
    }

    // Ejecutar la consulta SELECT
    public function executeSelect()
    {
        $query = $this->buildSelect();
        $stmt = $this->db->prepare($query);

        // Enlazar los parámetros con seguridad
        foreach ($this->params as $key => $value) {
            $stmt->bindValue($key + 1, $value);
        }

        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Ejecutar la consulta INSERT
    public function executeInsert()
    {
        $query = $this->buildInsert();
        $stmt = $this->db->prepare($query);

        // Inicializamos el contador $i en 1
        $i = 1;

        // Enlazamos los parámetros de los valores
        foreach ($this->values as $value) {
            $stmt->bindValue($i, $value);
            $i++; // Incrementamos el índice después de cada vínculo

        }
        $result = $stmt->execute();
        return $result;
    }


    // Ejecutar la consulta UPDATE
    public function executeUpdate()
    {
        $query = $this->buildUpdate();
        $stmt = $this->db->prepare($query);

        // Enlazar los valores de las columnas SET
        $i = 1;
        foreach ($this->setColumns as $value) {
            $stmt->bindValue($i++, $value);
        }

        // Enlazar las condiciones WHERE con los parámetros correspondientes
        foreach ($this->params as $key => $value) {
            $stmt->bindValue($i++, $value);
        }

        return $stmt->execute();
    }

    // Ejecutar la consulta DELETE
    public function executeDelete()
    {
        $query = $this->buildDelete();
        $stmt = $this->db->prepare($query);

        // Enlazar los parámetros con seguridad
        foreach ($this->params as $key => $value) {
            $stmt->bindValue($key + 1, $value);
        }

        return $stmt->execute();
    }
}
