<?php

namespace App\Models;


use App\Models\QueryBuilder;

class Roles
{
    protected static $table = "roles";
    protected static $columns = ['id', 'name'];
    private $db;

    public $id;
    public $name;

    public function __construct($db, $data = [])
    {

        $this->db = $db;
        $this->id = $data['id'] ?? null;
        $this->name = $data['name'] ?? null;
    }
    public function consultar()
    {
        try {
            $queryBuilder = new QueryBuilder($this->db);
            return $queryBuilder->table(self::$table)
                ->select([
                    'id',
                    'name'
                ])
                ->executeSelect();
            return array_map(function ($row) {
                return (object) $row;
            }, $result);
        } catch (\Throwable $th) {
            throw new \Exception("Error al consultar roles: " . $th->getMessage());
        }
    }
    public function create($data)
    {
        try {
            $queryBuilder = new QueryBuilder($this->db);
            $result = $queryBuilder->table(self::$table)
                ->insert([
                    'name' => htmlspecialchars(strip_tags($data['name']))
                ])
                ->executeInsert();
            return $result;
        } catch (\Throwable $th) {
            throw new \Exception("Error al crear roles: " . $th->getMessage());
        }
    }
    public function findById($id)
    {
        $queryBuilder = new QueryBuilder($this->db);
        $result = $queryBuilder->table(self::$table)
            ->select(self::$columns)
            ->where('id', '=', $id)
            ->executeSelect();
        return $result  ? (object)$result[0] : null;
    }

    public function update($id, $data)
    {
        try {
            if (empty($data['name'])) {
                throw new \Exception("El campo 'name' es obligatorio.");
            }
            $queryBuilder = new QueryBuilder($this->db);
            $query = $queryBuilder->table(self::$table)
                ->update([
                    'name' => htmlspecialchars(strip_tags($data['name'])),
                ])
                ->where('id', '=', $id);
            $result = $query->executeUpdate();
            if ($result === 0) {
                throw new \Exception("No se actualizó ningun rol.");
            }
            return $result;
        } catch (\Exception $e) {
            throw new \Exception("Error al actualizar El Rol: " . $e->getMessage());
        }
    }
    public function delete($id)
    {
        try {
            $queryBuilder =  new QueryBuilder($this->db);
            $query = $queryBuilder->table(self::$table)
                ->where('id', '=', $id);
            $result = $query->executeDelete();
            if ($result === 0) {
                throw new \Exception("No se eliminó ninguna categoría.");
            }
            return $result;
        } catch (\Exception $e) {
            throw new \Exception("Error al eliminar la categoría: " . $e->getMessage());
        }
    }
    public function getNextId()
    {
        $queryBuilder = new QueryBuilder($this->db);
        $lastId = $queryBuilder->table(self::$table)
            ->select('MAX(id) as last_id')
            ->executeSelect();
        return isset($lastId[0]['last_id']) ? $lastId[0]['last_id'] : 0;
    }
    public function getCreateResponse($data)
    {
        return [
            "resultado" => "Exito",
            'id' => $this->getNextId(),
            'name' => $data['name'],
        ];
    }
    public function getUpdateResponse($id, $data)
    {
        return [
            "resultado" => "Exito",
            'id' => $id,
            'name' => $data['name'],
        ];
    }
}
