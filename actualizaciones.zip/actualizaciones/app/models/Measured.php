<?php

namespace App\Models;

use App\Models\QueryBuilder;

class Measured
{
    protected static $table = "measured";
    protected static $columns =
    [
        'id',
        'id_intaketype',
        'id_consumtype',
        'year',
        'amount',
        'iva',
        'liminf',
        'limsup',
        'excm3',
        'iva_exc'
    ];
    private $db;
    public $id;
    public $id_intaketype;
    public $id_consumtype;
    public $tipo_toma;
    public $tipo_consumo;
    public $year;
    public $amount;
    public $iva;
    public $limtif;
    public $limitsup;
    public $excm3;
    public $iva_exc;


    private $queryBuilder;

    public function __construct($db, $data = [])
    {
        $this->db = $db;
        $this->id = $data['id'] ?? null;
        $this->id_intaketype = $data['id_intaketype'] ?? null;
        $this->id_consumtype = $data['id_consumtype'] ?? null;
        $this->tipo_toma = $data['tipo_toma'] ?? null;
        $this->tipo_consumo = $data['tipo_consumo'] ?? null;
        $this->year = $data['year'] ?? null;
        $this->amount = $data['amount'] ?? null;
        $this->iva = $data['iva'] ?? null;
        $this->limtif = $data['limtif'] ?? null;
        $this->limitsup = $data['limitsup'] ?? null;
        $this->excm3 = $data['excm3'] ?? null;
        $this->iva_exc = $data['iva_exc'] ?? null;
    }
    public function consultar()
    {
        try {
            $queryBuilder = new QueryBuilder($this->db);
            return $queryBuilder->table('measured m')
                ->select([
                    'm.id',
                    'm.id_intaketype',
                    'm.id_consumtype',
                    'inta.name AS tipo_toma',
                    'con.name AS tipo_consumo',
                    'm.year',
                    'm.amount',
                    'm.iva',
                    'm.liminf',
                    'm.limsup',
                    'm.excm3',
                    'm.iva_exc'
                ])
                ->join('intake_type inta', 'm.id_intaketype = inta.id')
                ->join('consume_type con', 'm.id_consumtype = con.id')
                ->executeSelect();
        } catch (\Exception $e) {
            throw new \Exception("Error al consultar measured: " . $e->getMessage());
        }
    }
    public function create($data)
    {
        try {
            $queryBuilder = new QueryBuilder($this->db);
            return $queryBuilder->table('measured')
                ->insert([
                    'year' => htmlspecialchars(strip_tags($data['year'])),
                    'id_intaketype' => (int) $data['id_intaketype'],
                    'id_consumtype' => (int) $data['id_consumtype'],
                    'amount' => htmlspecialchars(strip_tags($data['amount'])),
                    'iva' => (int) $data['iva'],
                    'liminf' => htmlspecialchars(strip_tags($data['liminf'])),
                    'limsup' => htmlspecialchars(strip_tags($data['limsup'])),
                    'excm3' => htmlspecialchars(strip_tags($data['excm3'])),
                    'iva_exc' => htmlspecialchars(strip_tags($data['iva_exc']))
                ])
                ->executeInsert();
        } catch (\Exception $e) {
            throw new \Exception("Error al crear measured: " . $e->getMessage());
        }
    }
    public function findById($id)
    {
        $queryBuilder = new QueryBuilder($this->db);
        $result = $queryBuilder->table('measured m')
            ->select([
                'm.id',
                'm.year',
                'm.id_intaketype',
                'm.id_consumtype',
                'm.amount',
                'm.iva',
                'm.liminf',
                'm.limsup',
                'm.excm3',
                'm.iva_exc'
            ])
            ->where('m.id', '=', $id)
            ->executeSelect();
        return $result ? (object)$result[0] : null;
    }
    public function update($id, $data)
    {
        try {
            if (empty($data['year'])) {
                throw new \Exception("El campo 'year' es obligatorio.");
            }
            $queryBuilder = new QueryBuilder($this->db);
            $query = $queryBuilder->table('measured')
                ->update([
                    'year' => htmlspecialchars(strip_tags($data['year'])),
                    'id_intaketype' => (int) $data['id_intaketype'],
                    'id_consumtype' => (int) $data['id_consumtype'],
                    'amount' => htmlspecialchars(strip_tags($data['amount'])),
                    'iva' => (int) $data['iva'],
                    'liminf' => htmlspecialchars(strip_tags($data['liminf'])),
                    'limsup' => htmlspecialchars(strip_tags($data['limsup'])),
                    'excm3' => htmlspecialchars(strip_tags($data['excm3'])),
                    'iva_exc' => htmlspecialchars(strip_tags($data['iva_exc']))
                ])
                ->where('id', '=', $id);
            $result = $query->executeUpdate();
            if ($result === 0) {
                throw new \Exception("No se encontró measured con el id: $id");
            }
            return $result;
        } catch (\Exception $e) {
            throw new \Exception("Error al actualizar measured: " . $e->getMessage());
        }
    }
    public function delete($id)
    {
        try {
            $queryBuilder =  new QueryBuilder($this->db);
            $query = $queryBuilder->table(self::$table)
                ->where('id', '=', $id);
            $result = $query->executeDelete();
            if ($result === 0) {
                throw new \Exception("No se eliminó ninguna categoría.");
            }
            return $result;
        } catch (\Exception $e) {
            throw new \Exception("Error al eliminar la categoría: " . $e->getMessage());
        }
    }
    public function getNextId()
    {
        $queryBuilder = new QueryBuilder($this->db);
        $lastId = $queryBuilder->table(self::$table)
            ->select('MAX(id) as last_id')
            ->executeSelect();
        return isset($lastId[0]['last_id']) ? $lastId[0]['last_id'] : 0;
    }

    public function getCreateResponse($data)
    {
        return [
            "resultado" => "Exito",
            "id" => $this->getNextId(),
            "year" => $data['year'],
            "id_intaketype" => $data['id_intaketype'],
            "id_consumtype" => $data['id_consumtype'],
            "amount" => $data['amount'],
            "iva" => $data['iva'],
            "liminf" => $data['liminf'],
            "limsup" => $data['limsup'],
            "excm3" => $data['excm3'],
            "iva_exc" => $data['iva_exc']
        ];
    }
    public function getUpdateResponse($id, $data)
    {
        return [
            "resultado" => "Exito",
            "id" => $id,
            "year" => $data['year'],
            "id_intaketype" => $data['id_intaketype'],
            "id_consumtype" => $data['id_consumtype'],
            "amount" => $data['amount'],
            "iva" => $data['iva'],
            "liminf" => $data['liminf'],
            "limsup" => $data['limsup'],
            "excm3" => $data['excm3'],
            "iva_exc" => $data['iva_exc']
        ];
    }
}
