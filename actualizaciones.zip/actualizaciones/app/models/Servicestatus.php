<?php

namespace App\Models;

use App\Models\QueryBuilder;

class Servicestatus
{
    protected static $table = "service_status";
    protected static $columns = ['id', 'name'];

    private $db;
    private $id;
    private $name;

    public function __construct($db, $data = [])
    {
        $this->db = $db;
        $this->id = $data['id'] ?? null;
        $this->name = $data['name'] ?? null;
    }

    public function consultar()
    {
        try {
            $queryBuilder = new QueryBuilder($this->db);
            return $queryBuilder->table(self::$table)
                ->select(self::$columns)
                ->orderBy('id', 'ASC')
                ->executeSelect();
        } catch (\Exception $e) {
            throw new \Exception("Error al consultar estados de servicio: " . $e->getMessage());
        }
    }
}
