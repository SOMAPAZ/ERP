<?php

namespace App\Models;



use App\Models\QueryBuilder;

class Notification
{
    protected static $table = "notification";
    protected static $columns = ['id', 'id_account', 'year', 'amount', 'iva', 'edit'];
    private $db;
    public $id;
    public $year;
    public $id_account;
    public $amount;
    public $iva;
    public $edit;
    public $nombre;

    private $queryBuilder;

    public function __construct($db, $data = [])
    {
        $this->db = $db;
        $this->queryBuilder = new QueryBuilder($db);
        $this->id = $data['id'] ?? null;
        $this->year = $data['year'] ?? null;
        $this->id_account = $data['id_account'] ?? null;
        $this->amount = $data['amount'] ?? null;
        $this->iva = $data['iva'] ?? null;
        $this->edit = $data['edit'] ?? null;
        $this->nombre = $data['nombre'] ?? null;
    }
    public function consultar()
    {
        try {
            $queryBuilder = new QueryBuilder($this->db);
            return $queryBuilder->table('notification n')
                ->select([
                    'n.id',
                    'n.id_account',
                    'acc.name as nombre',
                    'n.year',
                    'n.amount',
                    'n.edit',
                    'n.iva',

                ])
                ->join('account acc', 'n.id_account = acc.id')
                ->executeSelect();
        } catch (\Exception $e) {
            throw new \Exception("Error al consultar notification: " . $e->getMessage());
        }
    }
    public function create($data)
    {
        try {
            $queryBuilder = new QueryBuilder($this->db);
            $result = $queryBuilder->table('notification')
                ->insert([
                    'id_account' => htmlspecialchars(strip_tags($data['id_account'])),
                    'year' => htmlspecialchars(strip_tags($data['year'])),
                    'amount' => htmlspecialchars(strip_tags($data['amount'])),
                    'iva' => (int) $data['iva'],
                    'edit' => (int) $data['edit']

                ])
                ->executeInsert();
            $lastId = $queryBuilder->getLastId();
            return $lastId;
        } catch (\Exception $e) {
            throw new \Exception("Error al crear notification: " . $e->getMessage());
        }
    }
    public function findById($id)
    {
        try {
            $queryBuilder = new QueryBuilder($this->db);
            $result  = $queryBuilder->table('notification AS n')
                ->select([
                    'n.id',
                    'n.id_account',
                    'n.year',
                    'n.amount',
                    'n.iva',
                    'n.edit'
                ])
                ->where('n.id', '=', $id)
                ->executeSelect();
            return $result[0] ?? null;
        } catch (\Exception $e) {
            throw new \Exception("Error al buscar notificacion por ID: " . $e->getMessage());
        }
    }
    public function update($id, $data)
    {
        try {
            if (empty($data['year'])) {
                throw new \Exception("El campo 'year' es obligatorio.");
            }
            $queryBuilder = new QueryBuilder($this->db);
            $query = $queryBuilder->table('notification')
                ->update([
                    'id_account' => htmlspecialchars(strip_tags($data['id_account'])),
                    'year' => htmlspecialchars(strip_tags($data['year'])),
                    'amount' => htmlspecialchars(strip_tags($data['amount'])),
                    'iva' => (int) $data['iva'],
                    'edit' => (int) $data['edit']

                ])
                ->where('id', '=', $id);
            $result = $query->executeUpdate();
            if ($result === 0) {
                throw new \Exception("No se encontró notificación con el id: $id");
            }
            return $result;
        } catch (\Exception $e) {
            throw new \Exception("Error al actualizar notificación: " . $e->getMessage());
        }
    }
    public function delete($id)
    {
        try {
            $queryBuilder =  new QueryBuilder($this->db);
            $query = $queryBuilder->table(self::$table)
                ->where('id', '=', $id);
            $result = $query->executeDelete();
            if ($result === 0) {
                throw new \Exception("No se eliminó ninguna categoría.");
            }
            return $result;
        } catch (\Exception $e) {
            throw new \Exception("Error al eliminar la categoría: " . $e->getMessage());
        }
    }
    public function getNextId()
    {
        $queryBuilder = new QueryBuilder($this->db);
        $lastId = $queryBuilder->table(self::$table)
            ->select('MAX(id) as last_id')
            ->executeSelect();
        return isset($lastId[0]['last_id']) ? $lastId[0]['last_id'] : 0;
    }

    public function getCreateResponse($data)
    {
        return [
            "resultado" => "Exito",
            "id" => $this->getNextId(),
            "year" => $data['year'],
            "id_account" => $data['id_account'],
            "amount" => $data['amount'],
            "iva" => $data['iva'],
            "edit" => $data['edit']
        ];
    }
    public function getUpdateResponse($id, $data)
    {
        return [
            "resultado" => "Exito",
            "id" => $id,
            "year" => $data['year'],
            "id_account" => $data['id_account'],
            "amount" => $data['amount'],
            "iva" => $data['iva'],
            "edit" => $data['edit']
        ];
    }
}
