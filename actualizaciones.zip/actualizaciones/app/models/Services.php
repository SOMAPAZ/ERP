<?php

namespace App\Models;


use App\Models\QueryBuilder;

class Services
{
    protected static $table = "services";
    protected static $columns = ['id', 'name',];
    private $db;
    public $id;
    public $name;
    private $queryBuilder;
    public function __construct($db, $data = [])
    {
        $this->db = $db;
        $this->queryBuilder = new QueryBuilder($db);
        $this->id = $data['id'] ?? null;
        $this->name = $data['name'] ?? null;
        $this->queryBuilder = new QueryBuilder($db);
    }
    public function consultar()
    {
        try {
            $queryBuilder = new QueryBuilder($this->db);
            return $queryBuilder->table(self::$table)
                ->select([
                    'id',
                    'name'
                ])
                ->executeSelect();
        } catch (\Exception $e) {
            throw new \Exception("Error al consultar servicios: " . $e->getMessage());
        }
    }
}
