<?php

namespace App\Models;

use App\Models\QueryBuilder;

class User
{
    protected static $table = "users";
    protected static $columns = [
        'id',
        'user',
        'lastname',
        'phone',
        'address',
        'reference',
        'block',
        'int_num',
        'ext_num',
        'mail',
        'rfc',
        'clave_elector',
        'drenaje',
        'id_userStorage',
        'storage_heighy',
        'inhabitants',
        'stored_water',
        'id_colony',
        'id_locality',
        'id_zone',
        'id_usertype',
        'id_intaketype',
        'id_servicetype',
        'id_servicestatus',
        'id_consumtype',
        'id_typeperson',


    ];


    private $db;
    private $queryBuilder;

    public $id;
    public $user;
    public $lastname;
    public $phone;
    public $address;
    public $reference;
    public $block;
    public $int_num;
    public $ext_num;
    public $mail;
    public $rfc;
    public $clave_elector;
    public $drenaje;
    public $id_colony;
    public $id_locality;
    public $id_zone;
    public $id_usertype;
    public $id_intaketype;
    public $id_servicetype;
    public $id_servicestatus;
    public $id_consumtype;
    public $id_typeperson;
    public $id_userStorage;
    public $storage_height;
    public $inhabitants;
    public $stored_water;
    public $name_colony;
    public $name_locality;
    public $name_zone;
    public $name_user_type;
    public $name_intake_type;
    public $name_service_type;
    public $name_service_status;
    public $name_consume_type;
    public $name_userStorage;

    public function __construct($db, $data = [])
    {
        $this->db = $db;
        $this->queryBuilder = new QueryBuilder($db);

        $this->id = $data['id'] ?? null;
        $this->user = $data['user'] ?? null;
        $this->lastname = $data['lastname'] ?? null;
        $this->phone = $data['phone'] ?? null;
        $this->address = $data['address'] ?? null;
        $this->block = $data['block'] ?? null;
        $this->int_num = $data['int_num'] ?? null;
        $this->ext_num = $data['ext_num'] ?? null;
        $this->mail = $data['mail'] ?? null;
        $this->rfc = $data['rfc'] ?? null;
        $this->clave_elector = $data['clave_elector'] ?? null;
        $this->drenaje = $data['drenaje'] ?? null;
        $this->reference = $data['reference'] ?? null;
        $this->id_colony = $data['id_colony'] ?? null;
        $this->id_locality = $data['id_locality'] ?? null;
        $this->id_zone = $data['id_zone'] ?? null;
        $this->id_usertype = $data['id_usertype'] ?? null;
        $this->id_intaketype = $data['id_intaketype'] ?? null;
        $this->id_servicetype = $data['id_servicetype'] ?? null;
        $this->id_servicestatus = $data['id_servicestatus'] ?? null;
        $this->id_consumtype = $data['id_consumtype'] ?? null;
        $this->id_typeperson = $data['id_typeperson'] ?? null;
        $this->name_colony = $data['name_colony'] ?? null;
        $this->name_locality = $data['name_locality'] ?? null;
        $this->name_zone = $data['name_zone'] ?? null;
        $this->name_user_type = $data['name_user_type'] ?? null;
        $this->name_intake_type = $data['name_intake_type'] ?? null;
        $this->name_service_type = $data['name_service_type'] ?? null;
        $this->name_service_status = $data['name_service_status'] ?? null;
        $this->name_consume_type = $data['name_consume_type'] ?? null;
        $this->name_userStorage = $data['name_userStorage'] ?? null;
        $this->id_userStorage = $data['id_userStorage'] ?? null;
        $this->storage_height = $data['storage_height'] ?? null;
        $this->inhabitants = $data['inhabitants'] ?? null;
        $this->stored_water = $data['stored_water'] ?? null;
    }


    public function consultar()
    {
        try {
            $queryBuilder = new QueryBuilder($this->db);

            return $queryBuilder->table('users u')
                ->select([
                    'u.id',
                    'u.user',
                    'u.lastname',
                    'u.phone',
                    'u.address',
                    'u.reference',
                    'u.id_colony',
                    'u.id_locality',
                    'u.id_zone',
                    'u.block',
                    'u.int_num',
                    'u.ext_num',
                    'u.mail',
                    'u.rfc',
                    'u.clave_elector',
                    'u.drenaje',
                    'u.id_usertype',
                    'u.id_intaketype',
                    'u.id_servicetype',
                    'u.id_servicestatus',
                    'u.id_consumtype',
                    'u.id_userStorage',
                    'u.storage_height',
                    'u.inhabitants',
                    'u.stored_water',
                    'u.id_typeperson',
                    'c.name as name_colony',
                    'l.name as name_locality',
                    'z.name as name_zone',
                    'ut.name as name_user_type',
                    'it.name as name_intake_type',
                    'st.name as name_service_type',
                    'ss.name as name_service_status',
                    'ct.name as name_consume_type',
                    'us.name as name_userStorage',
                ])
                ->join('colony c', 'u.id_colony = c.id', 'LEFT')
                ->join('locality l', 'u.id_locality = l.id', 'LEFT')
                ->join('zone z', 'u.id_zone = z.id', 'LEFT')
                ->join('user_type ut', 'u.id_usertype = ut.id', 'LEFT')
                ->join('intake_type it', 'u.id_intaketype = it.id', 'LEFT')
                ->join('service_type st', 'u.id_servicetype = st.id', 'LEFT')
                ->join('service_status ss', 'u.id_servicestatus = ss.id', 'LEFT')
                ->join('consume_type ct', 'u.id_consumtype = ct.id', 'LEFT')
                ->join('user_storage us', 'u.id_userStorage  = us.id', 'LEFT')
                ->executeSelect();
        } catch (\Exception $e) {
            throw new \Exception("Error al consultar usuarios: " . $e->getMessage());
        }
    }
    public function create($data)
    {
        try {
            $queryBuilder = new QueryBuilder($this->db);
            $result = $queryBuilder->table('users')
                ->insert([
                    'user' => htmlspecialchars(strip_tags($data['user'])),
                    'lastname' => htmlspecialchars(strip_tags($data['lastname'])),
                    'phone' => htmlspecialchars(strip_tags($data['phone'])),
                    'address' => htmlspecialchars(strip_tags($data['address'])),
                    'reference' => htmlspecialchars(strip_tags($data['reference'])),
                    'id_colony' => (int)$data['id_colony'],
                    'id_locality' => (int)$data['id_locality'],
                    'id_zone' => (int)$data['id_zone'],
                    'block' => htmlspecialchars(strip_tags($data['block'])),
                    'int_num' => htmlspecialchars(strip_tags($data['int_num'])),
                    'ext_num' => htmlspecialchars(strip_tags($data['ext_num'])),
                    'mail' => htmlspecialchars(strip_tags($data['mail'])),
                    'rfc' => htmlspecialchars(strip_tags($data['rfc'])),
                    'clave_elector' => htmlspecialchars(strip_tags($data['clave_elector'])),
                    'drenaje' => isset($data['drenaje']) ? $data['drenaje'] : 0,
                    'id_usertype' => (int)$data['id_usertype'],
                    'id_intaketype' => (int)$data['id_intaketype'],
                    'id_servicetype' => (int)$data['id_servicetype'],
                    'id_servicestatus' => (int)$data['id_servicestatus'],
                    'id_consumtype' => (int)$data['id_consumtype'],
                    'id_typeperson' => (int)$data['id_typeperson'],
                    'id_userStorage' => (int)$data['id_userStorage'],
                    'storage_height' => (int)$data['storage_height'],
                    'inhabitants' => (int) $data['inhabitants'],
                    'stored_water' => htmlspecialchars($data['stored_water']),
                ])
                ->executeInsert();

            $lastId = $this->db->lastInsertId();
            return $lastId;
        } catch (\Exception $e) {
            throw new \Exception("Error al crear usuario: " . $e->getMessage());
        }
    }
    public function findById($id)
    {
        $queryBuilder = new QueryBuilder($this->db);
        $result = $queryBuilder->table('users u')
            ->select(self::$columns)
            ->where('u.id', '=', $id)
            ->executeSelect();
        return $result ? (object)$result[0] : null;
    }
    public function update($id, $data)
    {
        try {

            $queryBuilder = new QueryBuilder($this->db);
            $query = $queryBuilder->table('users')
                ->update([
                    'id' => (int)$id,
                    'user' => htmlspecialchars(strip_tags($data['user'])),
                    'lastname' => htmlspecialchars(strip_tags($data['lastname'])),
                    'phone' => htmlspecialchars(strip_tags($data['phone'])),
                    'address' => htmlspecialchars(strip_tags($data['address'])),
                    'reference' => htmlspecialchars(strip_tags($data['reference'])),
                    'id_colony' => (int)$data['id_colony'],
                    'id_locality' => (int)$data['id_locality'],
                    'id_zone' => (int)$data['id_zone'],
                    'block' => htmlspecialchars(strip_tags($data['block'])),
                    'int_num' => htmlspecialchars(strip_tags($data['int_num'])),
                    'ext_num' => htmlspecialchars(strip_tags($data['ext_num'])),
                    'mail' => htmlspecialchars(strip_tags($data['mail'])),
                    'rfc' => htmlspecialchars(strip_tags($data['rfc'])),
                    'clave_elector' => htmlspecialchars(strip_tags($data['clave_elector'])),
                    'drenaje' => isset($data['drenaje']) ? $data['drenaje'] : 0,
                    'id_usertype' => (int)$data['id_usertype'],
                    'id_intaketype' => (int)$data['id_intaketype'],
                    'id_servicetype' => (int)$data['id_servicetype'],
                    'id_servicestatus' => (int)$data['id_servicestatus'],
                    'id_consumtype' => (int)$data['id_consumtype'],
                    'id_typeperson' => (int)$data['id_typeperson'],
                    'id_userStorage' => (int)$data['id_userStorage'],
                    'storage_height' => (int)$data['storage_height'],
                    'inhabitants' => (int) $data['inhabitants'],
                    'stored_water' => htmlspecialchars($data['stored_water']),
                ])
                ->where('id', '=', $id);
            $result = $query->executeUpdate();
            if ($result === 0) {
                return false;
            }
            return true;
        } catch (\Exception $e) {
            throw new \Exception("Error al actualizar el usuario: " . $e->getMessage());
        }
    }
    public function delete($id)
    {
        try {
            $queryBuilder =  new QueryBuilder($this->db);
            $query = $queryBuilder->table(self::$table)
                ->where('id', '=', $id);
            $result = $query->executeDelete();

            return $result;
        } catch (\Exception $e) {
            throw new \Exception("Error al eliminar el usuario: " . $e->getMessage());
        }
    }
    public function getNextId()
    {
        $queryBuilder = new QueryBuilder($this->db);
        $lastId = $queryBuilder->table(self::$table)
            ->select('MAX(id) as last_id')
            ->executeSelect();
        return isset($lastId[0]['last_id']) ? $lastId[0]['last_id'] : 0;
    }
    public function getCreateResponse($data)
    {
        return [
            "resultado" => "Exito",
            "id" => $this->getNextId(),
            "user" => $data['user'],
            "lastname" => $data['lastname'],
            "phone" => $data['phone'],
            "address" => $data['address'],
            "reference" => $data['reference'],
            "id_colony" => $data['id_colony'],
            "id_locality" => $data['id_locality'],
            "id_zone" => $data['id_zone'],
            "block" => $data['block'],
            "int_num" => $data['int_num'],
            "ext_num" => $data['ext_num'],
            "mail" => $data['mail'],
            "rfc" => $data['rfc'],
            "clave_elector" => $data['clave_elector'],
            "drenaje" => $data['drenaje'],
            "id_usertype" => $data['id_usertype'],
            "id_intaketype" => $data['id_intaketype'],
            "id_servicetype" => $data['id_servicetype'],
            "id_servicestatus" => $data['id_servicestatus'],
            "id_consumtype" => $data['id_consumtype'],
            "id_userStorage" => $data['id_userStorage'],
            "storage_height" => $data['storage_height'],
            "inhabitants" => $data['inhabitants'],
            "stored_water" => $data['stored_water'],
            "id_typeperson" => $data['id_typeperson']

        ];
    }
    function getUpdateResponse($id, $data)
    {
        return  [
            "resultado" => "Exito",
            "id" => $id,
            "user" => $data['user'],
            "lastname" => $data['lastname'],
            "phone" => $data['phone'],
            "address" => $data['address'],
            "reference" => $data['reference'],
            "id_colony" => $data['id_colony'],
            "id_locality" => $data['id_locality'],
            "id_zone" => $data['id_zone'],
            "block" => $data['block'],
            "int_num" => $data['int_num'],
            "ext_num" => $data['ext_num'],
            "mail" => $data['mail'],
            "rfc" => $data['rfc'],
            "clave_elector" => $data['clave_elector'],
            "drenaje" => $data['drenaje'],
            "id_usertype" => $data['id_usertype'],
            "id_intaketype" => $data['id_intaketype'],
            "id_servicetype" => $data['id_servicetype'],
            "id_servicestatus" => $data['id_servicestatus'],
            "id_consumtype" => $data['id_consumtype'],
            "id_userStorage" => $data['id_userStorage'],
            "storage_height" => $data['storage_height'],
            "inhabitants" => $data['inhabitants'],
            "stored_water" => $data['stored_water'],
            "id_typeperson" => $data['id_typeperson']

        ];
    }
}
