<?php

namespace App\Models;


use App\Models\QueryBuilder;

class Format
{

    protected static $table = "formats";
    protected static $columns =
    [
        'id',
        'year',
        'nombre',
        'amount',
        'iva',
        'edit'
    ];
    private $db;
    public $id;
    public $year;
    public $nombre;
    public $amount;
    public $iva;
    public $edit;

    private $queryBuilder;

    public function __construct($db, $data = [])
    {
        $this->db = $db;
        $this->id = $data['id'] ?? null;
        $this->year = $data['year'] ?? null;
        $this->nombre = $data['nombre'] ?? null;
        $this->amount = $data['amount'] ?? null;
        $this->iva = $data['iva'] ?? null;
        $this->edit = $data['edit'] ?? null;
        $this->queryBuilder = new QueryBuilder($db);
    }

    public function consultar()
    {
        try {
            $queryBuilder = new QueryBuilder($this->db);
            return $queryBuilder->table('formats f')
                ->select([
                    'f.id',
                    'f.year',
                    'acc.name AS nombre',
                    'f.amount',
                    'f.iva',
                    'f.edit'
                ])
                ->join('account acc', 'f.id_account = acc.id')
                ->executeSelect();
        } catch (\Exception $e) {
            throw new \Exception("Error al consultar formatos: " . $e->getMessage());
        }
    }
    public function create($data)
    {
        $queryBuilder = new QueryBuilder($this->db);
        return $queryBuilder->table('formats')
            ->insert([
                'year' => htmlspecialchars(strip_tags($data['year'])),
                'id_account' => htmlspecialchars(strip_tags($data['id_account'])),
                'amount' => htmlspecialchars(strip_tags($data['amount'])),
                'iva' => htmlspecialchars(strip_tags($data['iva'])),
                'edit' => htmlspecialchars(strip_tags($data['edit']))
            ])
            ->executeInsert();
    }

    public function findById($id)
    {
        try {
            $queryBuilder = new QueryBuilder($this->db);
            $result  = $queryBuilder->table('formats AS n')
                ->select([
                    'n.id',
                    'n.id_account',
                    'n.year',
                    'n.amount',
                    'n.iva',
                    'n.edit'
                ])
                ->where('n.id', '=', $id)
                ->executeSelect();
            return $result[0] ?? null;
        } catch (\Exception $e) {
            throw new \Exception("Error al buscar notificacion por ID: " . $e->getMessage());
        }
    }
    public function update($id, $data)
    {
        try {
            if (empty($data['year'])) {
                throw new \Exception("El campo 'year' es obligatorio.");
            }
            $queryBuilder = new QueryBuilder($this->db);
            $query = $queryBuilder->table('formats')
                ->update([
                    'year' => htmlspecialchars(strip_tags($data['year'])),
                    'id_account' => htmlspecialchars(strip_tags($data['id_account'])),
                    'amount' => htmlspecialchars(strip_tags($data['amount'])),
                    'iva' => htmlspecialchars(strip_tags($data['iva'])),
                    'edit' => htmlspecialchars(strip_tags($data['edit']))
                ])
                ->where('id', '=', $id);
            $result = $query->executeUpdate();
            if ($result === 0) {
                throw new \Exception("No se encontró notificación con el id: $id");
            }
            return $result;
        } catch (\Exception $e) {
            throw new \Exception("Error al actualizar notificación: " . $e->getMessage());
        }
    }
    public function delete($id)
    {
        try {
            $queryBuilder =  new QueryBuilder($this->db);
            $query = $queryBuilder->table(self::$table)
                ->where('id', '=', $id);
            $result = $query->executeDelete();
            if ($result === 0) {
                throw new \Exception("No se eliminó ninguna categoría.");
            }
            return $result;
        } catch (\Exception $e) {
            throw new \Exception("Error al eliminar la categoría: " . $e->getMessage());
        }
    }
}
