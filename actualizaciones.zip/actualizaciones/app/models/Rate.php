<?php

namespace App\Models;


use App\Models\QueryBuilder;

class Rate
{
    protected static $table = "rates";
    protected static $columns =
    [
        'id',
        'id_consum_intake',
        'year',
        'amount',
        'iva',
    ];
    private $db;
    public $id;
    public $year;
    public $amount;
    public $iva;
    public $id_consum_intake;
    public $nombre_intake_type;
    public $nombre_consume_type;
    private $queryBuilder;

    public function __construct($db, $data = [])
    {
        $this->db = $db;
        $this->id = $data['id'] ?? null;
        $this->id_consum_intake = $data['id_consum_intake'] ?? null;
        $this->year = $data['year'] ?? null;
        $this->amount = $data['amount'] ?? null;
        $this->iva = $data['iva'] ?? null;
        $this->nombre_intake_type = $data['nombre_intake_type'] ?? null;
        $this->nombre_consume_type = $data['nombre_consume_type'] ?? null;
        $this->queryBuilder = new QueryBuilder($db);
    }
    public function consultar()
    {
        try {
            $queryBuilder = new QueryBuilder($this->db);
            return $queryBuilder->table('rates r')
                ->select([
                    'r.id',
                    'r.year',
                    'r.id_consum_intake',
                    'r.amount',
                    'r.iva',
                    'it.name AS nombre_intake_type',
                    'ct.name AS nombre_consume_type'
                ])
                ->join('consume_intake ci', 'r.id_consum_intake = ci.id')
                ->join('intake_type it', 'ci.id_intaketype = it.id')
                ->join('consume_type ct', 'ci.id_consumtype = ct.id')
                ->executeSelect();
        } catch (\Exception $e) {
            throw new \Exception("Error al consultar tarifas: " . $e->getMessage());
        }
    }
    public function create($data)
    {
        try {
            $queryBuilder = new QueryBuilder($this->db);
            $cleanedData = [
                'id_consum_intake' => htmlspecialchars(strip_tags($data['id_consum_intake'])),
                'year' => (int) $data['year'],
                'amount' => htmlspecialchars(strip_tags($data['amount'])),
                'iva' => (int) $data['iva'],
            ];
            return $queryBuilder->table('rates')
                ->insert($cleanedData)
                ->executeInsert();
        } catch (\Exception $e) {
            throw new \Exception("Error al crear una tarifa: " . $e->getMessage());
        }
    }
    public function findById($id)
    {
        $queryBuilder = new QueryBuilder($this->db);
        $result = $queryBuilder->table('rates r')
            ->select([
                'r.id',
                'r.id_consum_intake',
                'r.year',
                'r.amount',
                'r.iva'
            ])
            ->where('r.id', '=', $id)
            ->executeSelect();
        return $result ? (object)$result[0] : null;
    }
    public function update($id, $data)
    {
        try {
            if (empty($data['year'])) {
                throw new \Exception("El campo 'year' es obligatorio.");
            }
            $queryBuilder = new QueryBuilder($this->db);
            $query = $queryBuilder->table('rates')
                ->update([
                    'year' => htmlspecialchars(strip_tags($data['year'])),
                    'id_consum_intake' => htmlspecialchars(strip_tags($data['id_consum_intake'])),
                    'amount' => htmlspecialchars(strip_tags($data['amount'])),
                    'iva' => htmlspecialchars(strip_tags($data['iva']))
                ])
                ->where('id', '=', $id);
            $result = $query->executeUpdate();
            if ($result === 0) {
                throw new \Exception("No se encontró tarifa con el id: $id");
            }
            return $result;
        } catch (\Exception $e) {
            throw new \Exception("Error al actualizar tarifa: " . $e->getMessage());
        }
    }
    public function delete($id)
    {
        try {
            $queryBuilder =  new QueryBuilder($this->db);
            $query = $queryBuilder->table(self::$table)
                ->where('id', '=', $id);
            $result = $query->executeDelete();
            if ($result === 0) {
                throw new \Exception("No se eliminó ninguna categoría.");
            }
            return $result;
        } catch (\Exception $e) {
            throw new \Exception("Error al eliminar la categoría: " . $e->getMessage());
        }
    }
    public function getNextId()
    {
        $queryBuilder = new QueryBuilder($this->db);
        $lastId = $queryBuilder->table(self::$table)
            ->select('MAX(id) as last_id')
            ->executeSelect();
        return isset($lastId[0]['last_id']) ? $lastId[0]['last_id'] : 0;
    }
    public function getCreateResponse($data)
    {
        return [
            "resultado" => "Exito",
            "id" => $this->getNextId(),
            "year" => $data['year'],
            "id_consum_intake" => $data['id_consum_intake'],
            "amount" => $data['amount'],
            "iva" => $data['iva']
        ];
    }
    public function getUpdateResponse($id, $data)
    {
        return [
            "resultado" => "Exito",
            "id" => $id,
            "year" => $data['year'],
            "id_consum_intake" => $data['id_consum_intake'],
            "amount" => $data['amount'],
            "iva" => $data['iva']
        ];
    }
}
