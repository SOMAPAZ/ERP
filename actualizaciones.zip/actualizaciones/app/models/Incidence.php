<?php

namespace App\Models;


use App\Models\QueryBuilder;

class Incidence
{
    protected static $table = "incidence";
    protected static $columns = ['id', 'name', 'name_category'];
    private $db;
    public $id;
    public $name;
    public $name_category;
    private $queryBuilder;



    public function __construct($db, $data = [])
    {

        $this->db = $db;
        $this->queryBuilder = new QueryBuilder($db);
        $this->id = $data['id'] ?? null;
        $this->name = $data['name'] ?? null;
        $this->name_category = $data['name_category'] ?? null;
    }

    public function consultar()
    {
        try {
            $queryBuilder = new QueryBuilder($this->db);
            return $queryBuilder->table('incidence AS i')
                ->select([
                    'i.id',
                    'i.name',
                    'c.name AS name_category'
                ])
                ->join('category c', 'i.id_category = c.id')
                ->executeSelect();
        } catch (\Exception $e) {
            throw new \Exception("Error al consultar incidencias: " . $e->getMessage());
        }
    }
    public function create($data)
    {
        try {
            $queryBuilder = new QueryBuilder($this->db);
            return $queryBuilder->table('incidence')
                ->insert([
                    'name' => htmlspecialchars(strip_tags($data['name'])),
                    'id_category' => (int) $data['id_category']
                ])
                ->executeInsert();
        } catch (\Exception $e) {
            throw new \Exception("Error al crear incidencia: " . $e->getMessage());
        }
    }
    public function findById($id)
    {
        try {
            $queryBuilder = new QueryBuilder($this->db);
            $result = $queryBuilder->table('incidence AS i')
                ->select([
                    'i.id',
                    'i.name',
                    'c.name AS name_category',
                    'c.id AS id_category'
                ])
                ->join('category c', 'i.id_category = c.id')
                ->where('i.id', '=', (int) $id)
                ->executeSelect();

            return $result[0] ?? null;
        } catch (\Exception $e) {
            throw new \Exception("Error al buscar incidencia por ID: " . $e->getMessage());
        }
    }


    public function update($id, $data)
    {
        try {
            $queryBuilder = new QueryBuilder($this->db);
            return $queryBuilder->table('incidence')
                ->update([
                    'name' => htmlspecialchars(strip_tags($data['name'])),
                    'id_category' => (int) $data['id_category']
                ])
                ->where('id', '=', (int) $id)
                ->executeUpdate();
        } catch (\Exception $e) {
            throw new \Exception("Error al actualizar incidencia: " . $e->getMessage());
        }
    }
    public function delete($id)
    {
        try {
            $queryBuilder =  new QueryBuilder($this->db);
            $query = $queryBuilder->table(self::$table)
                ->where('id', '=', $id);
            $result = $query->executeDelete();
            if ($result === 0) {
                throw new \Exception("No se eliminó ninguna categoría.");
            }
            return $result;
        } catch (\Exception $e) {
            throw new \Exception("Error al eliminar la categoría: " . $e->getMessage());
        }
    }
}
