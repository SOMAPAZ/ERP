<?php

namespace App\Models;


use App\Models\QueryBuilder;

class ServiceRights
{
    protected static $table = "service_rights";
    protected static $columns = ['id', 'id_service', 'id_intaketype', 'year', 'iva', 'amount'];
    private $db;
    public $id;
    public $year;
    public $iva;
    public $amount;
    public $id_service;
    public $id_intaketype;
    public $servicio;
    public $tipo_toma;
    private $queryBuilder;

    public function __construct($db, $data = [])
    {
        $this->db = $db;
        $this->id = $data['id'] ?? null;
        $this->year = $data['year'] ?? null;
        $this->id_service = $data['id_service'] ?? null;
        $this->id_intaketype = $data['id_intaketype'] ?? null;
        $this->iva = $data['iva'] ?? null;
        $this->amount = $data['amount'] ?? null;
        $this->servicio = $data['servicio'] ?? null;
        $this->tipo_toma = $data['tipo_toma'] ?? null;
        $this->queryBuilder = new QueryBuilder($db);
    }
    public function consultar()
    {
        try {
            $queryBuilder = new QueryBuilder($this->db);
            return $queryBuilder->table('service_rights sr')
                ->select([
                    'sr.id',
                    'sr.id_service',
                    'sr.id_intaketype',
                    's.name AS servicio',
                    'i.name AS tipo_toma',
                    'sr.year',
                    'sr.iva',
                    'sr.amount'
                ])
                ->join('services s', 'sr.id_service = s.id')
                ->join('intake_type i', 'sr.id_intaketype = i.id')
                ->executeSelect();
        } catch (\Exception $e) {
            throw new \Exception("Error al consultar servicios: " . $e->getMessage());
        }
    }
    public function create($data)
    {
        try {
            $queryBuilder = new QueryBuilder($this->db);
            $result = $queryBuilder->table('service_rights')
                ->insert([
                    'id_service' => (int) $data['id_service'],
                    'id_intaketype' => (int) $data['id_intaketype'],
                    'year' => htmlspecialchars(strip_tags($data['year'])),
                    'iva' => (int) $data['iva'],
                    'amount' => htmlspecialchars(strip_tags($data['amount']))
                ])
                ->executeInsert();
            $lastId = $queryBuilder->getLastId();
            return $lastId;
        } catch (\Exception $e) {
            throw new \Exception("Error al crear servicios: " . $e->getMessage());
        }
    }
    public function findById($id)
    {
        $queryBuilder = new QueryBuilder($this->db);
        $result = $queryBuilder->table('service_rights  sr')
            ->select([
                'sr.id',
                'sr.id_service',
                'sr.id_intaketype',
                'sr.year',
                'sr.iva',
                'sr.amount'
            ])
            ->where('sr.id', '=', $id)
            ->executeSelect();
        return $result ? (object)$result[0] : null;
    }
    public function update($id, $data)
    {
        try {
            if (empty($data['year'])) {
                throw new \Exception("El campo 'year' es obligatorio.");
            }
            $queryBuilder = new QueryBuilder($this->db);
            $query = $queryBuilder->table('service_rights')
                ->update([
                    'id_service' => htmlspecialchars(strip_tags($data['id_service'])),
                    'id_intaketype' => htmlspecialchars(strip_tags($data['id_intaketype'])),
                    'year' => htmlspecialchars(strip_tags($data['year'])),
                    'iva' => (htmlspecialchars(strip_tags($data['iva']))),
                    'amount' => htmlspecialchars(strip_tags($data['amount']))
                ])
                ->where('id', '=', $id);
            $result =  $query->executeUpdate();
            if ($result === 0) {
                throw new \Exception("No se encontró servicio con el id: $id");
            }
            return $result;
        } catch (\Exception $e) {
            throw new \Exception("Error al actualizar servicio: " . $e->getMessage());
        }
    }
    public function delete($id)
    {
        try {
            $queryBuilder =  new QueryBuilder($this->db);
            $query = $queryBuilder->table(self::$table)
                ->where('id', '=', $id);
            $result = $query->executeDelete();
            if ($result === 0) {
                throw new \Exception("No se eliminó ninguna categoría.");
            }
            return $result;
        } catch (\Exception $e) {
            throw new \Exception("Error al eliminar la categoría: " . $e->getMessage());
        }
    }
    public function getNextId()
    {
        $queryBuilder = new QueryBuilder($this->db);
        $lastId = $queryBuilder->table(self::$table)
            ->select('MAX(id) as last_id')
            ->executeSelect();
        return isset($lastId[0]['last_id']) ? $lastId[0]['last_id'] : 0;
    }
    public function getCreateResponse($data)
    {
        return [
            "resultado" => "Exito",
            "id" => $this->getNextId(),
            "year" => $data['year'],
            "id_service" => $data['id_service'],
            "id_intaketype" => $data['id_intaketype'],
            "iva" => $data['iva'],
            "amount" => $data['amount']
        ];
    }
    public function getUpdateResponse($id, $data)
    {
        return [
            "resultado" => "Exito",
            "id" => $id,
            "year" => $data['year'],
            "id_service" => $data['id_service'],
            "id_intaketype" => $data['id_intaketype'],
            "iva" => $data['iva'],
            "amount" => $data['amount']
        ];
    }
}
