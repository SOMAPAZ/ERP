<?php

namespace App\Models;


use App\Models\QueryBuilder;

class ServiceRights
{
    protected static $table = "service_rights";
    protected static $columns = ['id', 'year', 'iva', 'amount', 'servicio', 'tipo_toma'];
    private $db;
    public $id;
    public $year;
    public $iva;
    public $amount;
    public $servicio;
    public $tipo_toma;
    private $queryBuilder;

    public function __construct($db, $data = [])
    {
        $this->db = $db;
        $this->id = $data['id'] ?? null;
        $this->year = $data['year'] ?? null;
        $this->iva = $data['iva'] ?? null;
        $this->amount = $data['amount'] ?? null;
        $this->servicio = $data['servicio'] ?? null;
        $this->tipo_toma = $data['tipo_toma'] ?? null;
        $this->queryBuilder = new QueryBuilder($db);
    }
    public function consultar()
    {
        try {
            $queryBuilder = new QueryBuilder($this->db);
            return $queryBuilder->table('service_rights sr')
                ->select([
                    'sr.id AS id',
                    's.name AS servicio',
                    'i.name AS tipo_toma',
                    'sr.year',
                    'sr.iva',
                    'sr.amount'
                ])
                ->join('services s', 'sr.id_service = s.id')
                ->join('intake_type i', 'sr.id_intaketype = i.id')
                ->executeSelect();
        } catch (\Exception $e) {
            throw new \Exception("Error al consultar servicios: " . $e->getMessage());
        }
    }
    public function create($data)
    {
        try {
            $queryBuilder = new QueryBuilder($this->db);
            return $queryBuilder->table('service_rights')
                ->insert([
                    'year' => htmlspecialchars(strip_tags($data['year'])),
                    'id_service' => htmlspecialchars(strip_tags($data['id_service'])),
                    'id_intaketype' => htmlspecialchars(strip_tags($data['id_intaketype'])),
                    'iva' => htmlspecialchars(strip_tags($data['iva'])),
                    'amount' => htmlspecialchars(strip_tags($data['amount']))
                ])
                ->executeInsert();
        } catch (\Exception $e) {
            throw new \Exception("Error al crear servicios: " . $e->getMessage());
        }
    }
    public function findById($id)
    {
        $queryBuilder = new QueryBuilder($this->db);
        $result = $queryBuilder->table('service_rights  sr')
            ->select([
                'sr.id',
                'sr.id_service',
                'sr.id_intaketype',
                'sr.year',
                'sr.iva',
                'sr.amount'
            ])
            ->where('sr.id', '=', $id)
            ->executeSelect();
        return $result ? (object)$result[0] : null;
    }
    public function update($id, $data)
    {
        try {
            if (empty($data['year'])) {
                throw new \Exception("El campo 'year' es obligatorio.");
            }
            $queryBuilder = new QueryBuilder($this->db);
            $query = $queryBuilder->table('service_rights')
                ->update([
                    'id_service' => htmlspecialchars(strip_tags($data['id_service'])),
                    'id_intaketype' => htmlspecialchars(strip_tags($data['id_intaketype'])),
                    'year' => htmlspecialchars(strip_tags($data['year'])),
                    'iva' => htmlspecialchars(strip_tags($data['iva'])),
                    'amount' => htmlspecialchars(strip_tags($data['amount']))
                ])
                ->where('id', '=', $id);
            $result =  $query->executeUpdate();
            if ($result === 0) {
                throw new \Exception("No se encontró servicio con el id: $id");
            }
            return $result;
        } catch (\Exception $e) {
            throw new \Exception("Error al actualizar servicio: " . $e->getMessage());
        }
    }
    public function delete($id)
    {
        try {
            $queryBuilder =  new QueryBuilder($this->db);
            $query = $queryBuilder->table(self::$table)
                ->where('id', '=', $id);
            $result = $query->executeDelete();
            if ($result === 0) {
                throw new \Exception("No se eliminó ninguna categoría.");
            }
            return $result;
        } catch (\Exception $e) {
            throw new \Exception("Error al eliminar la categoría: " . $e->getMessage());
        }
    }
}
