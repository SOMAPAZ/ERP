<?php

namespace App\Core;

class Router
{
    private $routes = [];

    public function get($url, $controllerAction)
    {
        $this->routes['GET'][$url] = $controllerAction;
    }
    public function post($url, $controllerAction)
    {
        $this->routes['POST'][$url] = $controllerAction;
    }


    private function callControllerAction($controllerAction)
    {
        if (is_array($controllerAction) && count($controllerAction) === 2) {
            list($controller, $action) = $controllerAction;

            if (class_exists($controller) && method_exists($controller, $action)) {
                $controllerInstance = new $controller();
                $controllerInstance->$action($this);
            } else {
                echo "No se encontró la acción: $action en el controlador: $controller";
            }
        } else {
            echo "Formato inválido de controlador y acción.";
        }
    }

    public function resolve()
    {
        $url = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        $method = $_SERVER['REQUEST_METHOD'];

        if (isset($this->routes[$method][$url])) {
            $controllerAction = $this->routes[$method][$url];
            $this->callControllerAction($controllerAction);
            return;
        }

        foreach ($this->routes[$method] as $route => $controllerAction) {
            $routeRegex = preg_replace('/\{([a-zA-Z0-9_]+)\}/', '(?P<\1>[a-zA-Z0-9_-]+)', $route);
            $routeRegex = '@^' . $routeRegex . '$@';

            if (preg_match($routeRegex, $url, $matches)) {
                $params = array_filter($matches, 'is_string', ARRAY_FILTER_USE_KEY);

                $this->callControllerActionWithParams($controllerAction, $params);
                return;
            }
        }

        echo "<h1>No se encontró la ruta: $url</h1>";
    }
    private function callControllerActionWithParams($controllerAction, $params)
    {
        if (is_array($controllerAction) && count($controllerAction) === 2) {
            list($controller, $action) = $controllerAction;

            if (class_exists($controller) && method_exists($controller, $action)) {
                $controllerInstance = new $controller();
                $controllerInstance->$action($this, ...array_values($params));
            } else {
                echo "No se encontró la acción: $action en el controlador: $controller";
            }
        } else {
            echo "Formato inválido de controlador y acción.";
        }
    }




    public function render($view, $data = [])
    {
        extract($data);
        echo "Renderizando vista: " . $view . "<br>";
        require_once __DIR__ . '/../views/' . $view . '.php';
    }
}
