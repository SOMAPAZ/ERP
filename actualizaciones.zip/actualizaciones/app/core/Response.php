<?php

namespace App\Core;

class Response
{
    public static function json($data, $statusCode = 200)
    {
        header('Content-Type: application/json');
        http_response_code($statusCode);
        echo json_encode($data);
    }
    public static function html($html, $statusCode = 200)
    {
        header('Content-Type: text/html');
        http_response_code($statusCode);
        echo $html;
        exit;
    }

    public static function error($message, $statusCode = 500)
    {
        self::json(['error' => $message], $statusCode);
    }
    public static function success($message, $statusCode = 200)
    {
        self::json(['message' => $message], $statusCode);
    }
}
