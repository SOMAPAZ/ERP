<?php

namespace App\Core;

class RequestHandler
{
    public static function getBody()
    {
        $input = file_get_contents('php://input');
        return json_decode($input, true) ?: [];
    }
    public static function getQueryParams()
    {
        return $_GET;
    }

    public static function getHeader($headerName)
    {
        $headers = getallheaders();
        return isset($headers[$headerName]) ? $headers[$headerName] : null;
    }

    public static function isMethod($method)
    {
        return strtoupper($_SERVER['REQUEST_METHOD']) === strtoupper($method);
    }
}
