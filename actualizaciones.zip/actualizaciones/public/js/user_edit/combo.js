function updateDrenajeLabel() {
  const checkbox = document.getElementById("drenaje");
  const label = document.getElementById("drenaje-label");

  label.textContent = checkbox.checked ? " Sí" : " No";
}
