obtenerEmployments();
obtenerRoles();
const tablaEmpleados = document.querySelector("#empleados-tabla");
const empleadoObj = {
  id: "",
  nombre: "",
  apellido: "",
  mail: "",
  id_rol: "",
};

const trVacio = document.querySelector("#nodatos");
const crearEmpleado = document.querySelector("#crear-empleado");

let empleados = [];
let roles = [];
let rolesFilter = [];

crearEmpleado.addEventListener("click", () => {
  mostrarFormulario({});
});

async function obtenerEmployments() {
  try {
    const URL = "http://localhost:8000/api/employments";
    const respuesta = await fetch(URL);
    const resultado = await respuesta.json();
    empleados = resultado;
    mostrarEmpleados();
  } catch (error) {
    console.log(error);
  }
}

async function obtenerRoles() {
  try {
    const URL = "http://localhost:8000/api/roles";
    const respuesta = await fetch(URL);
    const resultado = await respuesta.json();
    roles = resultado;
  } catch (error) {
    console.log(error);
  }
}

function mostrarEmpleados() {
  limpiarHtml();
  trVacio.remove();
  empleados.forEach((empleado) => {
    const { id, nombre, apellido, mail, id_rol, nombre_rol } = empleado;
    const fila = document.createElement("TR");
    fila.className = "bg-white border-b dark:bg-gray-800 dark:border-gray-700";

    const celdaId = document.createElement("TD");
    celdaId.className =
      "px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaId.textContent = id;
    const celdaNombre = document.createElement("TD");
    celdaNombre.className =
      "px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaNombre.textContent = `${nombre} ${apellido}`;

    const celdaEmail = document.createElement("TD");
    celdaEmail.className = "px-6 py-3";
    celdaEmail.textContent = mail;

    const celdaRol = document.createElement("TD");
    celdaRol.className = "px-6 py-3";
    celdaRol.textContent = nombre_rol;

    const celdaAcciones = document.createElement("TD");
    celdaAcciones.className =
      "flex justify-between px-6 py-3 whitespace-nowrap gap-3";

    const btnEditar = document.createElement("BUTTON");
    btnEditar.className =
      "bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded";
    btnEditar.textContent = "Editar";
    btnEditar.onclick = () => {
      mostrarFormulario(empleado, true);
    };

    const btnEliminar = document.createElement("BUTTON");
    btnEliminar.className =
      "bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded";
    btnEliminar.textContent = "Eliminar";
    btnEliminar.onclick = () => {
      confimarDelete(empleado);
    };

    celdaAcciones.appendChild(btnEditar);
    celdaAcciones.appendChild(btnEliminar);

    fila.appendChild(celdaId);
    fila.appendChild(celdaNombre);
    fila.appendChild(celdaEmail);
    fila.appendChild(celdaRol);
    fila.appendChild(celdaAcciones);
    tablaEmpleados.appendChild(fila);
  });
}

function mostrarFormulario(empleado, editar = false) {
  const main = document.querySelector("main");
  const divBgModal = document.createElement("DIV"); //contenedor modal
  divBgModal.id = "divBgModal";

  const divModal = document.createElement("DIV"); //modal
  divModal.className =
    "overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 bottom-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%)] max-h-full dark:bg-gray-900 bg-gray-300";

  const divContent = document.createElement("DIV");
  divContent.className =
    "relative p-4 w-full max-w-2xl max-h-full mx-auto mt-5";

  const formulario = document.createElement("FORM");
  formulario.className =
    "relative bg-white rounded-lg p-4 shadow dark:bg-gray-700";
  let nombreInputs = ["nombre", "apellido", "mail"];
  if (!editar) nombreInputs.push("password");

  crearInput(nombreInputs, formulario, empleado);

  const divRol = document.createElement("DIV");
  divRol.className = "mb-5";
  const labelRol = document.createElement("LABEL");
  labelRol.for = "id_rol";
  labelRol.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelRol.textContent = "ROL";
  const selectorRol = document.createElement("SELECT");

  selectorRol.name = "id_rol";
  selectorRol.id = "id_rol";
  selectorRol.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white ";

  roles.forEach((rol) => {
    const option = document.createElement("OPTION");
    option.value = rol.id;
    option.textContent = rol.name;
    if (editar) {
      rol.id == empleado.id_rol ? (option.selected = true) : null;
    }

    selectorRol.appendChild(option);
  });

  divRol.appendChild(labelRol);
  divRol.appendChild(selectorRol);

  const btnGuardar = document.createElement("INPUT");
  btnGuardar.className =
    "w-full mb-2 text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800";
  btnGuardar.value = "Guardar";
  btnGuardar.type = "submit";
  btnGuardar.onclick = (e) => {
    e.preventDefault();
    if (editar) {
      enviarFormulario({ ...empleado });
    } else {
      guardarEmpleado();
    }
  };

  formulario.appendChild(divRol);
  formulario.appendChild(btnGuardar);

  const botonesDiv = document.createElement("DIV");
  botonesDiv.className =
    "flex justify-end p-4 md:p-5 border-t border-gray-200 rounded-b dark:border-gray-600";

  const btnCancelar = document.createElement("BUTTON");
  btnCancelar.className =
    "py-2.5 px-5  text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700";
  btnCancelar.textContent = "Cancelar";
  btnCancelar.onclick = () => {
    divBgModal.remove();
  };
  botonesDiv.appendChild(btnCancelar);
  formulario.appendChild(botonesDiv);

  divContent.appendChild(formulario);
  divModal.appendChild(divContent);
  divBgModal.appendChild(divModal);
  main.appendChild(divBgModal);
}

// Validar el formato del correo
function crearInput(array, formulario, valores) {
  array.forEach((element) => {
    const div = document.createElement("DIV");
    div.className = "mb-5";

    const label = document.createElement("LABEL");
    label.for = element;
    label.className =
      "block mb-2 text-sm font-medium text-gray-900 text-sm uppercase dark:text-white";
    label.textContent = `${element}`;

    const input = document.createElement("INPUT");
    input.type = "text";
    input.id = element;
    input.name = element;
    input.className =
      "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white";
    input.placeholder = `Ingrese el ${element}`;
    input.value = valores[element] || "";
    input.required = true;

    // Validación específica para el campo "email"
    if (element.toLowerCase() === "mail") {
      input.type = "mail"; // Cambia el tipo para que el navegador realice validaciones básicas
      input.addEventListener("input", () => {
        const errorSpan = document.querySelector(`#${element}-error`);
        if (!esEmailValido(input.value)) {
          if (!errorSpan) {
            const span = document.createElement("SPAN");
            span.id = `${element}-error`;
            span.className = "text-red-500 text-sm";
            span.textContent = "El correo electrónico no es válido.";
            div.appendChild(span);
          }
        } else if (errorSpan) {
          errorSpan.remove();
        }
      });
    }
    if (element.toLowerCase() === "nombre") {
      input.addEventListener("input", () => {
        input.value = input.value.replace(/[^a-zA-Z\s]/g, "");
        if (input.value.length > 20) {
          input.value = input.value.slice(0, 20);
        }
      });
    }
    if (element.toLowerCase() === "apellido") {
      input.addEventListener("input", () => {
        input.value = input.value.replace(/[^a-zA-Z\s]/g, "");
        if (input.value.length > 20) {
          input.value = input.value.slice(0, 20);
        }
      });
    }
    if (element.toLowerCase() === "mail") {
      input.type = "email";

      input.addEventListener("input", () => {
        const errorSpan = document.querySelector(`#${element}-error`);

        if (input.value && !esEmailValido(input.value)) {
          if (!errorSpan) {
            const span = document.createElement("SPAN");
            span.id = `${element}-error`;
            span.className = "text-red-500 text-sm";
            span.textContent = "El correo electrónico no es válido.";
            div.appendChild(span);
          }
        } else if (errorSpan) {
          errorSpan.remove();
        }
      });
    }

    div.appendChild(label);
    div.appendChild(input);
    formulario.appendChild(div);
  });
}

function esEmailValido(email) {
  const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return regex.test(email);
}

function limpiarHtml() {
  while (tablaEmpleados.firstChild) {
    tablaEmpleados.removeChild(tablaEmpleados.firstChild);
  }
}

function getCsrfToken() {
  return document
    .querySelector('meta[name="csrf-token"]')
    .getAttribute("content");

  return token;
}
document.addEventListener("DOMContentLoaded", () => {
  const csrfToken = getCsrfToken();
});
async function enviarFormulario(empleado) {
  const csrfToken = getCsrfToken();
  const id = empleado.id;
  if (!id) {
    console.error("El ID del empleado no está definido.");
    return;
  }

  const nombre = document.querySelector("#nombre").value.trim();
  const apellido = document.querySelector("#apellido").value.trim();
  const mail = document.querySelector("#mail").value.trim();
  const id_rol = document.querySelector("#id_rol").value.trim();

  const empleadoObj = {
    id: id,
    nombre: nombre,
    apellido: apellido,
    mail: mail,
    id_rol: id_rol,
  };

  // Verificar campos vacíos
  if (Object.values(empleadoObj).some((v) => v === "")) {
    Swal.fire({
      icon: "error",
      title: "Campo vacío",
      text: "El campo no puede estar vacío.",
    });
    return;
  }

  // Validar formato del correo
  if (mail && !esEmailValido(mail)) {
    Swal.fire({
      icon: "error",
      title: "Correo inválido",
      text: "Por favor, ingresa un correo electrónico válido.",
    });
    return;
  }

  const data = new FormData();
  data.append("id", id);
  data.append("nombre", nombre);
  data.append("apellido", apellido);
  data.append("mail", mail);
  data.append("id_rol", id_rol);
  data.append("csrf_token", csrfToken);

  try {
    const URL = `http://localhost:8000/update-employment/${id}`;
    const respuesta = await fetch(URL, {
      method: "POST",
      body: data,
    });
    const resultado = await respuesta.json();

    if (resultado.resultado === "Exito") {
      Swal.fire({
        icon: "success",
        title: resultado.resultado,
        text: "Actualización exitosa",
      });
      document.querySelector("#divBgModal").remove();

      rolesFilter = roles.filter((rol) => rol.id == resultado.id_rol);
      empleados = empleados.map((empleadoMem) => {
        if (empleadoMem.id === id) {
          empleadoMem.nombre = resultado.nombre;
          empleadoMem.apellido = resultado.apellido;
          empleadoMem.mail = resultado.mail;
          empleadoMem.id_rol = resultado.id_rol;
          empleadoMem.nombre_rol = rolesFilter[0].name;
        }
        return empleadoMem;
      });
      mostrarEmpleados();
    }
  } catch (error) {
    console.log(error);
  }
}

function confimarDelete(empleado) {
  Swal.fire({
    title: "¿Estás seguro?",
    text: "Esta acción no se puede deshacer",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Sí, eliminar",
    cancelButtonText: "Cancelar",
  }).then((result) => {
    if (result.isConfirmed) {
      eliminarEmpleado(empleado);
    }
  });
}

async function eliminarEmpleado(empleado) {
  const csrfToken = getCsrfToken(); // Obtener el token CSRF
  const data = new FormData();
  data.append("id", empleado.id);
  data.append("csrf_token", csrfToken);
  try {
    const URL = `http://localhost:8000/delete-employment/${empleado.id}`;
    const respuesta = await fetch(URL, {
      method: "POST",
      body: data,
    });
    const resultado = await respuesta.json();
    if (resultado.resultado === "Exito") {
      Swal.fire({
        icon: "success",
        title: resultado.resultado,
        text: "Eliminación exitosa",
      });

      empleados = empleados.filter(
        (empleadoMem) => empleadoMem.id !== empleado.id
      );
      mostrarEmpleados();
    }
  } catch (error) {
    console.log(error);
  }
}

async function guardarEmpleado() {
  const nombre = document.querySelector("#nombre").value.trim();
  const apellido = document.querySelector("#apellido").value.trim();
  const mail = document.querySelector("#mail").value.trim();
  let password = document.querySelector("#password").value.trim();
  const id_rol = document.querySelector("#id_rol").value.trim();

  const empleadoObj = {
    nombre: nombre,
    apellido: apellido,
    mail: mail,
    id_rol: id_rol,
    password: password,
  };

  // Verificar campos vacíos
  if (Object.values(empleadoObj).some((v) => v === "")) {
    Swal.fire({
      icon: "error",
      title: "Campo vacío",
      text: "El campo no puede estar vacío.",
    });
    return;
  }

  // Validar formato del correo
  if (mail && !esEmailValido(mail)) {
    Swal.fire({
      icon: "error",
      title: "Correo inválido",
      text: "Por favor, ingresa un correo electrónico válido.",
    });
    return;
  }

  // Hashear la contraseña antes de enviarla

  const data = new FormData();
  data.append("nombre", nombre);
  data.append("apellido", apellido);
  data.append("mail", mail);
  data.append("password", password);
  data.append("id_rol", id_rol);
  data.append("csrf_token", getCsrfToken());

  try {
    const URL = `http://localhost:8000/create-employment`;
    const respuesta = await fetch(URL, {
      method: "POST",
      body: data,
    });

    const resultado = await respuesta.json();

    if (resultado.resultado === "Exito") {
      Swal.fire({
        icon: "success",
        title: resultado.resultado,
        text: "Creación exitosa",
      });

      document.querySelector("#divBgModal").remove();

      const rolesFilter = roles.filter((rol) => rol.id == resultado.id_rol);

      const nuevoEmpleado = {
        id: resultado.id,
        nombre: nombre,
        apellido: apellido,
        mail: mail,
        id_rol: id_rol,
        nombre_rol: rolesFilter[0].name,
      };

      empleados = [...empleados, nuevoEmpleado];

      mostrarEmpleados();
    }
  } catch (error) {
    console.log(error);
  }
}
