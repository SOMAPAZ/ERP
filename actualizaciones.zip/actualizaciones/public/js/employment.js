document.addEventListener("DOMContentLoaded", () => {
  obtenerEmployments();
});

async function obtenerEmployments() {
  try {
    const URL = "http://localhost:8000/api/employments";
    const response = await fetch(URL);
    const employments = await response.json();
    console.log(employments);
  } catch (error) {
    console.log(error);
  }
}
