async function obtenerUsuarios() {
  try {
    const URL = "http://localhost:8000/api/user";
    const response = await fetch(URL);
    if (!response.ok) {
      throw new Error("No se pudo obtener la información de los usuarios");
    }
    const user = await response.json();
    console.log(users);
  } catch (error) {
    console.log(error);
  }
}
