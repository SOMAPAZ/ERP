//llamados server
obtenerUsers();
obtenerColonias();
obtenerLocalidades();
obtenerZones();
obtenerTipoToma();
obtenerTipoConsumo();
obtenerTipoUsuario();
obtenerTipoServicio();
obtenerEstadosServicio();
obtenerTipoalmacenamiento();
//paginacion
let paginaActual = 1;
let usuariosPorPagina = 10;
const usuarioObj = {
  id: "",
  user: "",
  lastname: "",
  phone: "",
  address: "",
  reference: "",
  id_colony: "",
  id_locality: "",
  id_zone: "",
  block: "",
  int_num: "",
  ext_num: "",
  mail: "",
  rfc: "",
  clave_elector: "",
  drenaje: "",
  id_usertype: "",
  id_intaketype: "",
  id_servicetype: "",
  id_servicestatus: "",
  id_consumtype: "",
  id_typeperson: "",
  id_userStorage: "",
  storage_height: "",
  inhabitants: "",
  stored_water: "",
};
//tabla
const tablaUsuarios = document.querySelector("#usuario-tabla");
const controlesPaginacion = document.querySelector("#controles-paginacion");
const trVacio = document.querySelector("#userdatos");
const crearUsuario = document.querySelector("#crear-usuario");

let usuarios = [];
//colonias
let colonias = [];
let coloniasFilter = [];
//localidades
let localidades = [];
let localidadesFilter = [];
//ZONA
let zones = [];
let zonesFilter = [];
//tipo de toma
let tipoToma = [];
let tipoTomaFilter = [];
//tipo de consumo
let tipoConsumo = [];
let tipoConsumoFilter = [];
//tipo de usuario
let tipoUsuario = [];
let tipoUsuarioFilter = [];
//tipo de servicio
let tipoServicio = [];
let tipoServicioFilter = [];
//estado de servicio
let estadoServicio = [];
let estadoServicioFilter = [];
//tipo de almacenamiento
let tipoAlmacenamiento = [];
let tipoStorageFilter = [];
//drenaje
let drenaje;
//typeperson
let tipoPersona = [];
document.addEventListener("DOMContentLoaded", () => {
  inicializarPagina();
});
crearUsuario.addEventListener("click", () => {
  mostrarFormulario({});
});
//paginacion
function inicializarPagina() {
  const urlParams = new URLSearchParams(window.location.search);
  const pagina = parseInt(urlParams.get("pagina")) || 1;
  paginaActual = pagina;
  obtenerUsers();
}
function cambiarPagina(nuevaPagina) {
  paginaActual = nuevaPagina;

  const urlParams = new URLSearchParams(window.location.search);
  urlParams.set("pagina", nuevaPagina);
  window.history.pushState({}, "", `${window.location.pathname}?${urlParams}`);

  mostrarUsuarios();
  crearControlesPaginacion();
}
function crearControlesPaginacion() {
  controlesPaginacion.innerHTML = "";

  const totalPaginas = Math.ceil(usuarios.length / usuariosPorPagina);
  const rango = 2;

  if (totalPaginas < 1) return;

  controlesPaginacion.appendChild(crearBotonPagina(1));

  if (paginaActual - rango > 2) {
    const puntosInicio = document.createElement("SPAN");
    puntosInicio.textContent = "...";
    puntosInicio.className = "px-2 text-gray-500 justify-center";
    controlesPaginacion.appendChild(puntosInicio);
  }

  for (
    let i = Math.max(2, paginaActual - rango);
    i <= Math.min(totalPaginas - 1, paginaActual + rango);
    i++
  ) {
    controlesPaginacion.appendChild(crearBotonPagina(i));
  }

  if (paginaActual + rango < totalPaginas - 1) {
    const puntosFin = document.createElement("SPAN");
    puntosFin.textContent = "...";
    puntosFin.className = "px-2 text-gray-500";
    controlesPaginacion.appendChild(puntosFin);
  }

  if (totalPaginas > 1) {
    controlesPaginacion.appendChild(crearBotonPagina(totalPaginas));
  }
}
function crearBotonPagina(numeroPagina) {
  const botonPagina = document.createElement("BUTTON");
  botonPagina.textContent = numeroPagina;
  botonPagina.className = `px-4 py-2 ${
    numeroPagina === paginaActual
      ? "bg-blue-500 text-white"
      : "bg-gray-200 text-black"
  }`;
  botonPagina.onclick = () => cambiarPagina(numeroPagina);
  return botonPagina;
}
//limpiar html
function limpiarHtml() {
  while (tablaUsuarios.firstChild) {
    tablaUsuarios.removeChild(tablaUsuarios.firstChild);
  }
}
//creacion de inputs
function crearInput(array, formulario, valores) {
  const fieldTranslations = {
    user: "Nombre de Usuario",
    lastname: "Apellido (S)",
    phone: "Teléfono",
    address: "Dirección",
    reference: "Referencias",
    block: "Cuadra",
    int_num: "# Int",
    ext_num: "# Ext",
    mail: "Correo Electrónico",
    rfc: "RFC",
    clave_elector: "Clave de Elector",
    storage_height: "Peso de Almacenamiento",
    inhabitants: "Habitantes",
    stored_water: "Agua Almacenada",
  };

  array.forEach((element) => {
    const div = document.createElement("DIV");
    div.className = "mb-5";

    // Traducir el nombre del campo o usar el original si no hay traducción
    const labelName = fieldTranslations[element] || element;

    const label = document.createElement("LABEL");
    label.for = element;
    label.className =
      "block mb-2 text-sm font-medium text-gray-900 text-sm uppercase dark:text-white";
    label.textContent = labelName;

    const input = document.createElement("INPUT");
    input.type = "text";
    input.id = element;
    input.name = element;
    input.className =
      "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white";
    input.placeholder = `Ingrese el ${labelName.toLowerCase()}`;
    input.value = valores[element] || ""; // Prellenar con los valores si existen

    // Reglas para el campo 'user': Aceptar letras y números
    if (element.toLowerCase() === "user") {
      input.addEventListener("input", () => {
        input.value = input.value.replace(/[^a-zA-Z0-9 ]/g, ""); // Permitir letras, números y espacios
      });
    }
    // Reglas para el campo 'lastname': Aceptar solo letras
    if (element.toLowerCase() === "lastname") {
      input.addEventListener("input", () => {
        input.value = input.value.replace(/[^a-zA-Z\s]/g, ""); // Permitir solo letras y espacios
      });
    }
    // Validación de correo electrónico
    if (element.toLowerCase() === "mail") {
      input.type = "email";
      input.addEventListener("input", () => {
        const errorSpan = document.querySelector(`#${element}-error`);

        if (input.value && !esEmailValido(input.value)) {
          if (!errorSpan) {
            const span = document.createElement("SPAN");
            span.id = `${element}-error`;
            span.className = "text-red-500 text-sm";
            span.textContent = "El correo electrónico no es válido.";
            div.appendChild(span);
          }
        } else if (errorSpan) {
          errorSpan.remove();
        }
      });
    }
    if (element.toLowerCase() === "address") {
      input.addEventListener("input", () => {
        input.value = input.value.replace(/[^a-zA-Z0-9\s]/g, ""); // Permitir solo letras y números
        if (input.value.length > 50) {
          input.value = input.value.slice(0, 50); // Limitar la longitud a 20 caracteres
        }
      });
    }
    if (element.toLowerCase() === "reference") {
      input.addEventListener("input", () => {
        input.value = input.value.replace(/[^a-zA-Z0-9\s]/g, ""); // Permitir solo letras y números
        if (input.value.length > 100) {
          input.value = input.value.slice(0, 100); // Limitar la longitud a 20 caracteres
        }
      });
    }

    // Validación de RFC
    if (element.toLowerCase() === "rfc") {
      input.addEventListener("input", () => {
        input.value = input.value.replace(/[^a-zA-Z0-9]/g, ""); // Limitar a letras y números
        if (input.value.length > 13) {
          input.value = input.value.slice(0, 13); // Limitar la longitud a 13 caracteres
        }
      });
    }

    // Validación de clave de elector
    if (element.toLowerCase() === "clave_elector") {
      input.addEventListener("input", () => {
        input.value = input.value.replace(/[^a-zA-Z0-9]/g, ""); // Limitar a letras y números
        if (input.value.length > 18) {
          input.value = input.value.slice(0, 18); // Limitar la longitud a 18 caracteres
        }
      });
    }
    if (element.toLowerCase() === "phone") {
      input.addEventListener("input", () => {
        // Permitir solo números
        input.value = input.value.replace(/[^0-9]/g, "");
        // Limitar la longitud a 10 caracteres
        if (input.value.length > 10) {
          input.value = input.value.slice(0, 10);
        }
      });
    }

    if (element.toLowerCase() === "block") {
      input.addEventListener("input", () => {
        let value = input.value;

        // Filtrar solo caracteres permitidos (letras, números y espacios)
        let filteredValue = value.replace(/[^a-zA-Z0-9\s]/g, "");

        // Limitar a un máximo de 20 caracteres
        input.value = filteredValue.slice(0, 20);
      });
    }

    if (element.toLowerCase() === "int_num") {
      input.addEventListener("input", () => {
        input.value = input.value.replace(/[^0-9]/g, ""); // Permitir solo números
        if (input.value.length > 4) {
          input.value = input.value.slice(0, 4); // Limitar la longitud a 4 caracteres
        }
      });
    }
    if (element.toLowerCase() === "ext_num") {
      input.addEventListener("input", () => {
        input.value = input.value.replace(/[^0-9]/g, ""); // Permitir solo números
        if (input.value.length > 4) {
          input.value = input.value.slice(0, 4); // Limitar la longitud a 4 caracteres
        }
      });
    }
    if (element.toLowerCase() === "storage_height") {
      input.addEventListener("input", () => {
        input.value = input.value.replace(/[^0-9]/g, ""); // Permitir solo números
        if (input.value.length > 4) {
          input.value = input.value.slice(0, 4); // Limitar la longitud a 4 caracteres
        }
      });
    }
    if (element.toLowerCase() === "inhabitants") {
      input.addEventListener("input", () => {
        input.value = input.value.replace(/[^0-9]/g, ""); // Permitir solo números
        if (input.value.length > 4) {
          input.value = input.value.slice(0, 4); // Limitar la longitud a 4 caracteres
        }
      });
    }
    if (element.toLowerCase() === "stored_water") {
      input.addEventListener("input", () => {
        // Reemplazar caracteres no numéricos y permitir un solo punto decimal
        input.value = input.value.replace(/[^0-9.]/g, ""); // Permitir números y puntos
        // Asegurarse de que solo haya un punto decimal
        if ((input.value.match(/\./g) || []).length > 1) {
          input.value = input.value.slice(0, -1); // Eliminar el último punto
        }
        // Limitar la longitud a 4 caracteres, permitiendo un decimal
        if (input.value.length > 4) {
          input.value = input.value.slice(0, 4); // Limitar a 4 caracteres
        }
      });
    }

    div.appendChild(label);
    div.appendChild(input);
    formulario.appendChild(div);
  });
}

function esEmailValido(email) {
  const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return regex.test(email);
}

// Obtener usuarios
async function obtenerUsers() {
  try {
    const URL = "http://localhost:8000/api/user";
    const respuesta = await fetch(URL);
    const resultado = await respuesta.json();
    usuarios = resultado;
    mostrarUsuarios();
    crearControlesPaginacion();
  } catch (error) {
    console.log(error);
  }
}
//obtener colonias
async function obtenerColonias() {
  try {
    const URL = "http://localhost:8000/api/colonies";
    const respuesta = await fetch(URL);
    const resultado = await respuesta.json();
    colonias = resultado;
  } catch (error) {
    console.log(error);
  }
}
//obtener localidades
async function obtenerLocalidades() {
  try {
    const URL = "http://localhost:8000/api/locality";
    const respuesta = await fetch(URL);
    const resultado = await respuesta.json();
    localidades = resultado;
  } catch (error) {
    console.log(error);
  }
}
//obtener zonas
async function obtenerZones() {
  try {
    const URL = "http://localhost:8000/api/zone";
    const respuesta = await fetch(URL);
    const resultado = await respuesta.json();
    zones = resultado;
  } catch (error) {
    console.log(error);
  }
}
//tipo toma
async function obtenerTipoToma() {
  try {
    const URL = "http://localhost:8000/api/intake_type";
    const respuesta = await fetch(URL);
    const resultado = await respuesta.json();
    tipoToma = resultado;
  } catch (error) {
    console.log(error);
  }
}
//tipo de consumo
async function obtenerTipoConsumo() {
  try {
    const URL = "http://localhost:8000/api/consumetypes";
    const respuesta = await fetch(URL);
    const resultado = await respuesta.json();
    tipoConsumo = resultado;
  } catch (error) {
    console.log(error);
  }
}
//tipo de usuario
async function obtenerTipoUsuario() {
  try {
    const URL = "http://localhost:8000/api/usertype";
    const respuesta = await fetch(URL);
    const resultado = await respuesta.json();
    tipoUsuario = resultado;
  } catch (error) {
    console.log(error);
  }
}
//tipo de servicio
async function obtenerTipoServicio() {
  try {
    const URL = "http://localhost:8000/api/servicetype";
    const respuesta = await fetch(URL);
    const resultado = await respuesta.json();
    tipoServicio = resultado;
  } catch (error) {
    console.log(error);
  }
}
//estado de servicio
async function obtenerEstadosServicio() {
  try {
    const URL = "http://localhost:8000/api/servicestatus";
    const respuesta = await fetch(URL);
    const resultado = await respuesta.json();
    estadoServicio = resultado;
  } catch (error) {
    console.log(error);
  }
}
async function obtenerTipoalmacenamiento() {
  try {
    const URL = "http://localhost:8000/api/userstorage";
    const respuesta = await fetch(URL);
    const resultado = await respuesta.json();
    tipoAlmacenamiento = resultado;
  } catch (error) {
    console.log(error);
  }
}
//mostrar usuarios
async function mostrarUsuarios() {
  limpiarHtml();
  const inicio = (paginaActual - 1) * usuariosPorPagina;
  const fin = inicio + usuariosPorPagina;
  let usuariosPagina = usuarios.slice(inicio, fin);

  trVacio.remove();
  usuariosPagina.forEach((usuario) => {
    const {
      id,
      user,
      lastname,
      phone,
      address,
      reference,
      id_colony,
      id_locality,
      id_zone,
      name_colony,
      name_locality,
      name_zone,
      block,
      int_num,
      ext_num,
      mail,
      rfc,
      clave_elector,
      drenaje,
      id_usertype,
      id_intaketype,
      id_servicetype,
      id_servicestatus,
      id_consumtype,
      id_typeperson,
      name_user_type,
      name_intake_type,
      name_service_type,
      name_service_status,
      name_consume_type,
      name_userStorage,
      id_userStorage,
      storage_height,
      inhabitants,
      stored_water,
    } = usuario;
    const fila = document.createElement("TR");
    fila.className = "bg-white border-b dark:bg-gray-800 dark:border-gray-700";

    const celdaId = document.createElement("TD");
    celdaId.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaId.textContent = id;
    const celdaNombre = document.createElement("TD");
    celdaNombre.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaNombre.textContent = `${user} ${lastname}`;

    const celtaTipoPersona = document.createElement("TD");
    celtaTipoPersona.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celtaTipoPersona.textContent = id_typeperson == 1 ? "Moral" : "Fisica";

    const celdaTelefono = document.createElement("TD");
    celdaTelefono.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaTelefono.textContent = phone === 0 || phone > 0 ? phone : "N/A";

    const celdaDireccion = document.createElement("TD");
    celdaDireccion.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaDireccion.textContent =
      address === 0 || address > "" ? address : "N/A";
    const celdaReferencias = document.createElement("TD");
    celdaReferencias.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaReferencias.textContent =
      reference === 0 || reference > "" ? reference : "N/A";

    const celdaColonia = document.createElement("TD");
    celdaColonia.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaColonia.textContent =
      name_colony == "" || name_colony > "" ? name_colony : "N/A";

    const celdaLocalidad = document.createElement("TD");
    celdaLocalidad.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaLocalidad.textContent = name_locality;

    const celdaZona = document.createElement("TD");
    celdaZona.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaZona.textContent = name_zone;

    const celdaCuadra = document.createElement("TD");
    celdaCuadra.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaCuadra.textContent = block === 0 || block > 0 ? block : "N/A";

    const celdaInt = document.createElement("TD");
    celdaInt.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaInt.textContent = int_num === 0 || int_num > 0 ? int_num : "N/A";

    const celdaExt = document.createElement("TD");
    celdaExt.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaExt.textContent = ext_num === 0 || ext_num > 0 ? ext_num : "N/A";

    const celdaCorreo = document.createElement("TD");
    celdaCorreo.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaCorreo.textContent = mail === 0 || mail > "" ? mail : "N/A";

    const celdaRFC = document.createElement("TD");
    celdaRFC.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaRFC.textContent = rfc === 0 || rfc > "" ? rfc : "N/A";

    const celdaClaveElector = document.createElement("TD");
    celdaClaveElector.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaClaveElector.textContent =
      clave_elector === 0 || clave_elector > "" ? clave_elector : "N/A";

    const celdaDrenaje = document.createElement("TD");
    celdaDrenaje.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaDrenaje.textContent = drenaje == 1 ? "Sí" : "No";

    const celdaTipoUsuario = document.createElement("TD");
    celdaTipoUsuario.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaTipoUsuario.textContent = name_user_type;

    const celdaTipoToma = document.createElement("TD");
    celdaTipoToma.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaTipoToma.textContent = name_intake_type;

    const celdaTipoServicio = document.createElement("TD");
    celdaTipoServicio.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaTipoServicio.textContent = name_service_type;

    const celdaEstadoServicio = document.createElement("TD");
    celdaEstadoServicio.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaEstadoServicio.textContent = name_service_status;

    const celdaTipoConsumo = document.createElement("TD");
    celdaTipoConsumo.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaTipoConsumo.textContent = name_consume_type;

    const celdaTipoalmacenamiento = document.createElement("TD");
    celdaTipoalmacenamiento.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaTipoalmacenamiento.textContent =
      name_userStorage === 0 || name_userStorage > ""
        ? name_userStorage
        : "Sin Almacenamiento";
    const celdaPesoalmacenamiento = document.createElement("TD");
    celdaPesoalmacenamiento.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaPesoalmacenamiento.textContent =
      storage_height === 0 || storage_height > ""
        ? storage_height
        : "Sin Valor";

    const celdaHabitantes = document.createElement("TD");
    celdaHabitantes.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaHabitantes.textContent =
      inhabitants === 0 ? inhabitants : "Sin Habitantes";

    const celdaAguaalmacenamiento = document.createElement("TD");
    celdaAguaalmacenamiento.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaAguaalmacenamiento.textContent =
      stored_water === 0 ? stored_water : "0";

    const celdaAcciones = document.createElement("TD");
    celdaAcciones.className =
      "flex justify-between px-6 py-3 whitespace-nowrap gap-3";

    const btnEditar = document.createElement("BUTTON");
    btnEditar.className =
      "bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded";
    btnEditar.textContent = "Editar";
    btnEditar.onclick = () => {
      mostrarFormulario(usuario, true);
    };
    const btnEliminar = document.createElement("BUTTON");
    btnEliminar.className =
      "bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded";
    btnEliminar.textContent = "Eliminar";
    btnEliminar.onclick = () => {
      confirmaDelete(usuario);
    };

    celdaAcciones.appendChild(btnEditar);
    celdaAcciones.appendChild(btnEliminar);

    fila.appendChild(celdaAcciones);
    fila.appendChild(celdaId);
    fila.appendChild(celdaNombre);
    fila.appendChild(celtaTipoPersona);
    fila.appendChild(celdaTelefono);
    fila.appendChild(celdaDireccion);
    fila.appendChild(celdaReferencias);
    fila.appendChild(celdaColonia);
    fila.appendChild(celdaLocalidad);
    fila.appendChild(celdaZona);
    fila.appendChild(celdaCuadra);
    fila.appendChild(celdaInt);
    fila.appendChild(celdaExt);
    fila.appendChild(celdaCorreo);
    fila.appendChild(celdaRFC);
    fila.appendChild(celdaClaveElector);
    fila.appendChild(celdaDrenaje);
    fila.appendChild(celdaTipoUsuario);
    fila.appendChild(celdaTipoToma);
    fila.appendChild(celdaTipoServicio);
    fila.appendChild(celdaEstadoServicio);
    fila.appendChild(celdaTipoConsumo);
    fila.appendChild(celdaTipoalmacenamiento);
    fila.appendChild(celdaPesoalmacenamiento);
    fila.appendChild(celdaHabitantes);
    fila.appendChild(celdaAguaalmacenamiento);

    tablaUsuarios.appendChild(fila);
  });
}
//creacion de formulario
function mostrarFormulario(usuario, editar = false) {
  const fieldTraslations = {
    user: "Nombre de Usuario",
    lastname: "Apellido (s)",
    phone: "Telefono",
    address: "Direccion",
    reference: "Referencias",
    block: "Cuadra",
    int_num: "# Int",
    ext_num: "# Ext",
    mail: "Correo",
    rfc: "RFC",
    clave_elector: "Clave de Elector",
    storage_height: "Peso de Almacenamiento",
    inhabitants: "Habitantes",
    stored_water: "Agua Almacenada",
  };

  const main = document.querySelector("main");
  const divBgModal = document.createElement("DIV"); //contenedor modal
  divBgModal.id = "divBgModal";

  const divModal = document.createElement("DIV"); //modal
  divModal.className =
    "overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 bottom-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%)] max-h-full dark:bg-gray-900 bg-gray-300";

  const divContent = document.createElement("DIV");
  divContent.className =
    "relative p-4 w-full max-w-2xl max-h-full mx-auto mt-5";

  const formulario = document.createElement("FORM");
  formulario.className =
    "relative bg-white rounded-lg p-4 shadow dark:bg-gray-700";
  let nombreInputs = [
    "user",
    "lastname",
    "phone",
    "address",
    "reference",
    "block",
    "int_num",
    "ext_num",
    "mail",
    "rfc",
    "clave_elector",
    "storage_height",
    "inhabitants",
    "stored_water",
  ];

  //creacion del selector de colonias
  const divColony = document.createElement("DIV");
  divColony.className = "mb-5";
  const labelColony = document.createElement("LABEL");
  labelColony.for = "id_colony";
  labelColony.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelColony.textContent = "COLONIA";
  const selectorColony = document.createElement("SELECT");

  selectorColony.name = "id_colony";
  selectorColony.id = "id_colony";
  selectorColony.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white ";

  colonias.forEach((colony) => {
    const option = document.createElement("OPTION");
    option.value = colony.id;
    option.textContent = colony.name;

    if (colony.id == usuario.id_colony) {
      option.selected = true;
    }

    selectorColony.appendChild(option);
  });

  //creacion del selector de tipo de almacenamiento
  const divTipoAlmacenamiento = document.createElement("DIV");
  divTipoAlmacenamiento.className = "mb-5";
  const labelTipoAlmacenamiento = document.createElement("LABEL");
  labelTipoAlmacenamiento.for = "id_userStorage";
  labelTipoAlmacenamiento.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelTipoAlmacenamiento.textContent = "TIPO DE ALMACENAMIENTO";
  const selectorTipoAlmacenamiento = document.createElement("SELECT");
  selectorTipoAlmacenamiento.name = "id_userStorage";
  selectorTipoAlmacenamiento.id = "id_userStorage";
  selectorTipoAlmacenamiento.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white ";
  tipoAlmacenamiento.forEach((tAlmacenamiento) => {
    const option = document.createElement("OPTION");
    option.value = tAlmacenamiento.id;
    option.textContent = tAlmacenamiento.name;
    if (tAlmacenamiento.id == usuario.id_userStorage) {
      option.selected = true;
    }
    selectorTipoAlmacenamiento.appendChild(option);
  });
  //creacion del selector de localidades
  const divLocalidad = document.createElement("DIV");
  divLocalidad.className = "mb-5";
  const labelLocalidad = document.createElement("LABEL");
  labelLocalidad.for = "id_locality";
  labelLocalidad.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelLocalidad.textContent = "LOCALIDAD";
  const selectorLocalidad = document.createElement("SELECT");

  selectorLocalidad.name = "id_locality";
  selectorLocalidad.id = "id_locality";
  selectorLocalidad.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white ";

  localidades.forEach((locality) => {
    const option = document.createElement("OPTION");
    option.value = locality.id;
    option.textContent = locality.name;

    locality.id == usuario.id_locality ? (option.selected = true) : null;

    selectorLocalidad.appendChild(option);
  });

  //creacion del selector de zonas
  const divZona = document.createElement("DIV");
  divZona.className = "mb-5";
  const labelZona = document.createElement("LABEL");
  labelZona.for = "id_zone";
  labelZona.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelZona.textContent = "ZONA";
  const selectorZona = document.createElement("SELECT");

  selectorZona.name = "id_zone";
  selectorZona.id = "id_zone";
  selectorZona.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white ";

  zones.forEach((zone) => {
    const option = document.createElement("OPTION");
    option.value = zone.id;
    option.textContent = zone.name;

    zone.id == usuario.id_zone ? (option.selected = true) : null;

    selectorZona.appendChild(option);
  });
  //creacion del selector de tipo de toma
  const divTipoToma = document.createElement("DIV");
  divTipoToma.className = "mb-5";
  const labelTipoToma = document.createElement("LABEL");
  labelTipoToma.for = "id_intaketype";
  labelTipoToma.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelTipoToma.textContent = "TIPO DE TOMA";
  const selectorTipoToma = document.createElement("SELECT");
  selectorTipoToma.name = "id_intaketype";
  selectorTipoToma.id = "id_intaketype";
  selectorTipoToma.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white ";
  tipoToma.forEach((tToma) => {
    const option = document.createElement("OPTION");
    option.value = tToma.id;
    option.textContent = tToma.name;
    if (tToma.id == usuario.id_intaketype) {
      option.selected = true;
    }
    selectorTipoToma.appendChild(option);
  });
  //creacion del selector de tipo de consumo
  const divTipoConsumo = document.createElement("DIV");
  divTipoConsumo.className = "mb-5";
  const labelTipoConsumo = document.createElement("LABEL");
  labelTipoConsumo.for = "id_consumtype";
  labelTipoConsumo.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelTipoConsumo.textContent = "TIPO DE CONSUMO";
  const selectorTipoConsumo = document.createElement("SELECT");
  selectorTipoConsumo.name = "id_consumtype";
  selectorTipoConsumo.id = "id_consumtype";
  selectorTipoConsumo.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white ";
  tipoConsumo.forEach((tConsumo) => {
    const option = document.createElement("OPTION");
    option.value = tConsumo.id;
    option.textContent = tConsumo.name;
    if (tConsumo.id == usuario.id_consumtype) {
      option.selected = true;
    }
    selectorTipoConsumo.appendChild(option);
  });
  //tipo de usuario
  const divTipoUsuario = document.createElement("DIV");
  divTipoUsuario.className = "mb-5";
  const labelTipoUsuario = document.createElement("LABEL");
  labelTipoUsuario.for = "id_usertype";
  labelTipoUsuario.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelTipoUsuario.textContent = "TIPO DE USUARIO";
  const selectorTipoUsuario = document.createElement("SELECT");
  selectorTipoUsuario.name = "id_usertype";
  selectorTipoUsuario.id = "id_usertype";
  selectorTipoUsuario.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white";
  tipoUsuario.forEach((tUsuario) => {
    const option = document.createElement("OPTION");
    option.value = tUsuario.id;
    option.textContent = tUsuario.name;

    if (tUsuario.id == usuario.id_usertype) {
      option.selected = true;
    }

    selectorTipoUsuario.appendChild(option);
  });
  //creacion del selector de tipo de servicio
  const divTipoServicio = document.createElement("DIV");
  divTipoServicio.className = "mb-5";
  const labelTipoServicio = document.createElement("LABEL");
  labelTipoServicio.for = "id_servicetype";
  labelTipoServicio.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelTipoServicio.textContent = "TIPO DE SERVICIO";
  const selectorTipoServicio = document.createElement("SELECT");
  selectorTipoServicio.name = "id_servicetype";
  selectorTipoServicio.id = "id_servicetype";
  selectorTipoServicio.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white ";

  tipoServicio.forEach((tServicio) => {
    const option = document.createElement("OPTION");
    option.value = tServicio.id;
    option.textContent = tServicio.name;
    if (tServicio.id == usuario.id_servicetype) {
      option.selected = true;
    }
    selectorTipoServicio.appendChild(option);
  });
  //estado de servicio
  const divEstadoServicio = document.createElement("DIV");
  divEstadoServicio.className = "mb-5";
  const labelEstadoServicio = document.createElement("LABEL");
  labelEstadoServicio.for = "id_servicestatus";
  labelEstadoServicio.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelEstadoServicio.textContent = "ESTADO DE SERVICIO";
  const selectorEstadoServicio = document.createElement("SELECT");
  selectorEstadoServicio.name = "id_servicestatus";
  selectorEstadoServicio.id = "id_servicestatus";
  selectorEstadoServicio.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white ";

  estadoServicio.forEach((eServicio) => {
    const option = document.createElement("OPTION");
    option.value = eServicio.id;
    option.textContent = eServicio.name;
    if (eServicio.id == usuario.id_servicestatus) {
      option.selected = true;
    }
    selectorEstadoServicio.appendChild(option);
  });

  // Contenedor del selector de drenaje
  const divDrenaje = document.createElement("DIV");
  divDrenaje.className = "mb-5";

  const labelDrenaje = document.createElement("LABEL");
  labelDrenaje.for = "drenaje";
  labelDrenaje.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelDrenaje.textContent = "DRENAJE";

  const selectorDrenaje = document.createElement("SELECT");
  selectorDrenaje.name = "drenaje";
  selectorDrenaje.id = "drenaje";
  selectorDrenaje.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white";

  const options = [
    { value: 1, text: "Sí" },
    { value: 0, text: "No" },
  ];
  options.forEach((option) => {
    const optionEl = document.createElement("OPTION");
    optionEl.value = option.value;
    optionEl.textContent = option.text;
    if (option.value == usuario.drenaje) {
      optionEl.setAttribute("selected", true);
    }
    selectorDrenaje.appendChild(optionEl);
  });

  //selector de tipo de persona
  const divTipoPersona = document.createElement("DIV");
  divTipoPersona.className = "mb-5";
  const labelTipoPersona = document.createElement("LABEL");
  labelTipoPersona.for = "id_typeperson";
  labelTipoPersona.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelTipoPersona.textContent = "TIPO DE PERSONA";
  const selectorTipoPersona = document.createElement("SELECT");
  selectorTipoPersona.name = "id_typeperson";
  selectorTipoPersona.id = "id_typeperson";
  selectorTipoPersona.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white ";
  const optionsTipoPersona = [
    { value: 1, text: "Moral" },
    { value: 0, text: "Fisica" },
  ];
  optionsTipoPersona.forEach((option) => {
    const optionEl = document.createElement("OPTION");
    optionEl.value = option.value;
    optionEl.textContent = option.text;
    if (option.value == usuario.id_typeperson) {
      optionEl.setAttribute("selected", true);
    }
    selectorTipoPersona.appendChild(optionEl);
  });
  // Agregar opciones al selector
  divColony.appendChild(labelColony);
  divColony.appendChild(selectorColony);
  divLocalidad.appendChild(labelLocalidad);
  divLocalidad.appendChild(selectorLocalidad);
  divDrenaje.appendChild(labelDrenaje);
  divDrenaje.appendChild(selectorDrenaje);
  divTipoPersona.appendChild(labelTipoPersona);
  divTipoPersona.appendChild(selectorTipoPersona);
  divZona.appendChild(labelZona);
  divZona.appendChild(selectorZona);
  divTipoToma.appendChild(labelTipoToma);
  divTipoToma.appendChild(selectorTipoToma);
  divTipoConsumo.appendChild(labelTipoConsumo);
  divTipoConsumo.appendChild(selectorTipoConsumo);
  divTipoUsuario.appendChild(labelTipoUsuario);
  divTipoUsuario.appendChild(selectorTipoUsuario);
  divTipoServicio.appendChild(labelTipoServicio);
  divTipoServicio.appendChild(selectorTipoServicio);
  divEstadoServicio.appendChild(labelEstadoServicio);
  divEstadoServicio.appendChild(selectorEstadoServicio);
  divTipoAlmacenamiento.appendChild(labelTipoAlmacenamiento);
  divTipoAlmacenamiento.appendChild(selectorTipoAlmacenamiento);

  // Añadir el divTipoPersona de manera explícita
  const btnGuardar = document.createElement("INPUT");
  btnGuardar.className =
    "w-full mb-2 text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800";
  btnGuardar.value = "Guardar";
  btnGuardar.type = "submit";
  btnGuardar.onclick = (e) => {
    e.preventDefault();

    if (editar) {
      enviarFormulario({ ...usuario });
    } else {
      guardarUsuario();
    }
  };

  //asignacion de las funciones de colonia en el boton
  formulario.appendChild(divTipoPersona);
  crearInput(nombreInputs, formulario, usuario, fieldTraslations);
  formulario.appendChild(divColony);
  formulario.appendChild(divLocalidad);
  formulario.appendChild(divZona);
  formulario.appendChild(divDrenaje);
  formulario.appendChild(divTipoAlmacenamiento);
  formulario.appendChild(divTipoUsuario);
  formulario.appendChild(divEstadoServicio);
  formulario.appendChild(divTipoServicio);
  formulario.appendChild(divTipoToma);
  formulario.appendChild(divTipoConsumo);
  formulario.appendChild(btnGuardar);

  const botonesDiv = document.createElement("DIV");
  botonesDiv.className =
    "flex justify-end p-4 md:p-5 border-t border-gray-200 rounded-b dark:border-gray-600";

  const btnCancelar = document.createElement("BUTTON");
  btnCancelar.className =
    "py-2.5 px-5  text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700";
  btnCancelar.textContent = "Cancelar";
  btnCancelar.onclick = () => {
    divBgModal.remove();
  };
  botonesDiv.appendChild(btnCancelar);
  formulario.appendChild(botonesDiv);

  divContent.appendChild(formulario);
  divModal.appendChild(divContent);
  divBgModal.appendChild(divModal);
  main.appendChild(divBgModal);
}

//actualizar usuario
async function enviarFormulario(usuario) {
  const id = usuario.id;
  const user = document.querySelector("#user").value.trim();
  const lastname = document.querySelector("#lastname").value.trim();
  const phone = document.querySelector("#phone").value.trim();
  const address = document.querySelector("#address").value.trim();
  const reference = document.querySelector("#reference").value.trim();
  const id_colony = document.querySelector("#id_colony").value.trim();
  const id_locality = document.querySelector("#id_locality").value.trim();
  const id_zone = document.querySelector("#id_zone").value.trim();
  const block = document.querySelector("#block").value.trim();
  const int_num = document.querySelector("#int_num").value.trim();
  const ext_num = document.querySelector("#ext_num").value.trim();
  const mail = document.querySelector("#mail").value.trim();
  const rfc = document.querySelector("#rfc").value.trim();
  const clave_elector = document.querySelector("#clave_elector").value.trim();
  const drenaje = document.querySelector("#drenaje").value.trim();

  const id_usertype = document.querySelector("#id_usertype").value.trim();
  const id_intaketype = document.querySelector("#id_intaketype").value.trim();
  const id_servicetype = document.querySelector("#id_servicetype").value.trim();
  const id_servicestatus = document
    .querySelector("#id_servicestatus")
    .value.trim();
  const id_consumtype = document.querySelector("#id_consumtype").value.trim();
  const id_typeperson = document.querySelector("#id_typeperson").value.trim();
  const id_userStorage = document.querySelector("#id_userStorage").value.trim();
  const storage_height = document.querySelector("#storage_height").value.trim();
  const inhabitants = document.querySelector("#inhabitants").value.trim();
  const stored_water = document.querySelector("#stored_water").value.trim();
  const usuarioObj = {
    id: id, // El id debe estar presente aquí
    user: user,
    lastname: lastname,
    phone: phone,
    address: address,
    reference: reference,
    id_colony: id_colony,
    id_locality: id_locality,
    id_zone: id_zone,
    block: block,
    int_num: int_num,
    ext_num: ext_num,
    mail: mail,
    rfc: rfc,
    clave_elector: clave_elector,
    drenaje: drenaje,
    id_usertype: id_usertype,
    id_intaketype: id_intaketype,
    id_servicetype: id_servicetype,
    id_servicestatus: id_servicestatus,
    id_consumtype: id_consumtype,
    //faltantes
    id_userStorage: id_userStorage,
    storage_height: storage_height,
    inhabitants: inhabitants,
    stored_water: stored_water,
    id_typeperson: id_typeperson,
  };

  // Asumiendo que 'mail' es el valor del campo de correo
  if (mail && !esEmailValido(mail)) {
    Swal.fire({
      icon: "error",
      title: "Correo inválido",
      text: "Por favor, ingresa un correo electrónico válido.",
    });
    return;
  }

  const data = new FormData();
  data.append("id", id);
  data.append("user", user);
  data.append("lastname", lastname);
  data.append("phone", phone);
  data.append("id_colony", id_colony);
  data.append("id_locality", id_locality);
  data.append("id_zone", id_zone);
  data.append("address", address);
  data.append("reference", reference);
  data.append("block", block);
  data.append("int_num", int_num);
  data.append("ext_num", ext_num);
  data.append("mail", mail);
  data.append("rfc", rfc);
  data.append("clave_elector", clave_elector);
  data.append("drenaje", drenaje);
  data.append("id_usertype", id_usertype);
  data.append("id_intaketype", id_intaketype);
  data.append("id_servicetype", id_servicetype);
  data.append("id_servicestatus", id_servicestatus);
  data.append("id_consumtype", id_consumtype);
  data.append("id_typeperson", id_typeperson);
  data.append("id_userStorage", id_userStorage);
  data.append("storage_height", storage_height);
  data.append("inhabitants", inhabitants);
  data.append("stored_water", stored_water);

  try {
    const URL = `http://localhost:8000/update-user/${id}`;
    const respuesta = await fetch(URL, {
      method: "POST",
      body: data,
    });
    const resultado = await respuesta.json();
    if (resultado.resultado === "Exito") {
      Swal.fire({
        icon: "success",
        title: resultado.resultado,
        text: "Actualización exitosa",
      });
      document.querySelector("#divBgModal").remove();
      coloniasFilter = colonias.filter(
        (colony) => colony.id == resultado.id_colony
      );
      localidadesFilter = localidades.filter(
        (locality) => locality.id == resultado.id_locality
      );
      zonesFilter = zones.filter((zone) => zone.id == resultado.id_zone);

      tipoUsuarioFilter = tipoUsuario.filter(
        (tUsuario) => tUsuario.id == resultado.id_usertype
      );
      tipoTomaFilter = tipoToma.filter(
        (tToma) => tToma.id == resultado.id_intaketype
      );
      tipoServicioFilter = tipoServicio.filter(
        (tServicio) => tServicio.id == resultado.id_servicetype
      );
      estadoServicioFilter = estadoServicio.filter(
        (eServicio) => eServicio.id == resultado.id_servicestatus
      );
      tipoConsumoFilter = tipoConsumo.filter(
        (tConsumo) => tConsumo.id == resultado.id_consumtype
      );
      tipoStorageFilter = tipoAlmacenamiento.filter(
        (tStorage) => tStorage.id == resultado.id_userStorage
      );

      usuarios = usuarios.map((usuarioMem) => {
        if (usuarioMem.id === id) {
          // Resto de la asignación de datos
          usuarioMem.user = resultado.user;
          usuarioMem.lastname = resultado.lastname;
          usuarioMem.phone = resultado.phone;
          usuarioMem.id_colony = resultado.id_colony;
          usuarioMem.id_locality = resultado.id_locality;
          usuarioMem.id_zone = resultado.id_zone;
          usuarioMem.address = resultado.address;
          usuarioMem.reference = resultado.reference;
          usuarioMem.block = resultado.block;
          usuarioMem.int_num = resultado.int_num;
          usuarioMem.ext_num = resultado.ext_num;
          usuarioMem.mail = resultado.mail;
          usuarioMem.rfc = resultado.rfc;
          usuarioMem.clave_elector = resultado.clave_elector;
          usuarioMem.drenaje = resultado.drenaje;
          usuarioMem.id_usertype = resultado.id_usertype;
          usuarioMem.id_intaketype = resultado.id_intaketype;
          usuarioMem.id_servicetype = resultado.id_servicetype;
          usuarioMem.id_servicestatus = resultado.id_servicestatus;
          usuarioMem.id_consumtype = resultado.id_consumtype;
          usuarioMem.id_typeperson = resultado.id_typeperson;
          usuarioMem.id_userStorage = resultado.id_userStorage;
          usuarioMem.storage_height = resultado.storage_height;
          usuarioMem.inhabitants = resultado.inhabitants;
          usuarioMem.stored_water = resultado.stored_water;
          usuarioMem.name_colony = coloniasFilter[0].name;
          usuarioMem.name_locality = localidadesFilter[0].name;
          usuarioMem.name_zone = zonesFilter[0].name;
          usuarioMem.name_user_type = tipoUsuarioFilter[0].name;
          usuarioMem.name_intake_type = tipoTomaFilter[0].name;
          usuarioMem.name_service_type = tipoServicioFilter[0].name;
          usuarioMem.name_service_status = estadoServicioFilter[0].name;
          usuarioMem.name_consume_type = tipoConsumoFilter[0].name;
          usuarioMem.name_userStorage = tipoStorageFilter[0].name;
        }
        return usuarioMem;
      });

      mostrarUsuarios();
    }
  } catch (error) {
    console.log(error);
  }
}
//guardar usuario
async function guardarUsuario() {
  const user = document.querySelector("#user").value.trim();
  const lastname = document.querySelector("#lastname").value.trim();
  const phone = document.querySelector("#phone").value.trim();
  const address = document.querySelector("#address").value.trim();
  const reference = document.querySelector("#reference").value.trim();
  const id_colony = document.querySelector("#id_colony").value.trim();
  const id_locality = document.querySelector("#id_locality").value.trim();
  const id_zone = document.querySelector("#id_zone").value.trim();
  const block = document.querySelector("#block").value.trim();
  const int_num = document.querySelector("#int_num").value.trim();
  const ext_num = document.querySelector("#ext_num").value.trim();
  const mail = document.querySelector("#mail").value.trim();
  const rfc = document.querySelector("#rfc").value.trim();
  const clave_elector = document.querySelector("#clave_elector").value.trim();
  const drenaje = document.querySelector("#drenaje").value.trim();
  const id_usertype = document.querySelector("#id_usertype").value.trim();
  const id_intaketype = document.querySelector("#id_intaketype").value.trim();
  const id_servicetype = document.querySelector("#id_servicetype").value.trim();
  const id_servicestatus = document
    .querySelector("#id_servicestatus")
    .value.trim();
  const id_consumtype = document.querySelector("#id_consumtype").value.trim();
  const id_typeperson = document.querySelector("#id_typeperson").value.trim();
  const id_userStorage = document.querySelector("#id_userStorage").value.trim();
  const storage_height = document.querySelector("#storage_height").value.trim();
  const inhabitants = document.querySelector("#inhabitants").value.trim();
  const stored_water = document.querySelector("#stored_water").value.trim();

  const usuarioObj = {
    user: user,
    lastname: lastname,
    phone: phone,
    address: address,
    reference: reference,
    id_colony: id_colony,
    id_locality: id_locality,
    id_zone: id_zone,
    block: block,
    int_num: int_num,
    ext_num: ext_num,
    mail: mail,
    rfc: rfc,
    clave_elector: clave_elector,
    drenaje: drenaje,
    id_usertype: id_usertype,
    id_intaketype: id_intaketype,
    id_servicetype: id_servicetype,
    id_servicestatus: id_servicestatus,
    id_consumtype: id_consumtype,
    id_typeperson: id_typeperson,
    id_userStorage: id_userStorage,
    storage_height: storage_height,
    inhabitants: inhabitants,
    stored_water: stored_water,
  };

  if (mail && !esEmailValido(mail)) {
    Swal.fire({
      icon: "error",
      title: "Correo inválido",
      text: "Por favor, ingresa un correo electrónico válido.",
    });
    return;
  }

  const data = new FormData();
  data.append("user", user);
  data.append("lastname", lastname);
  data.append("phone", phone);
  data.append("address", address);
  data.append("reference", reference);
  data.append("id_colony", id_colony);
  data.append("id_locality", id_locality);
  data.append("id_zone", id_zone);
  data.append("block", block);
  data.append("int_num", int_num);
  data.append("ext_num", ext_num);
  data.append("mail", mail);
  data.append("rfc", rfc);
  data.append("clave_elector", clave_elector);
  data.append("drenaje", drenaje);
  data.append("id_usertype", id_usertype);
  data.append("id_intaketype", id_intaketype);
  data.append("id_servicetype", id_servicetype);
  data.append("id_servicestatus", id_servicestatus);
  data.append("id_consumtype", id_consumtype);
  data.append("id_typeperson", id_typeperson);
  data.append("id_userStorage", id_userStorage);
  data.append("storage_height", storage_height);
  data.append("inhabitants", inhabitants);
  data.append("stored_water", stored_water);

  try {
    const URL = `http://localhost:8000/create-user`;
    const respuesta = await fetch(URL, {
      method: "POST",
      body: data,
    });
    const resultado = await respuesta.json();
    if (resultado.resultado === "Exito") {
      Swal.fire({
        icon: "success",
        title: resultado.resultado,
        text: "Creación exitosa",
      });
      document.querySelector("#divBgModal").remove();
      const coloniasFilter = colonias.filter(
        (colony) => colony.id == resultado.id_colony
      );
      const localidadesFilter = localidades.filter(
        (locality) => locality.id == resultado.id_locality
      );
      const zonesFilter = zones.filter((zone) => zone.id == resultado.id_zone);
      const tipoTomaFilter = tipoToma.filter(
        (tToma) => tToma.id == resultado.id_intaketype
      );
      const tipoConsumoFilter = tipoConsumo.filter(
        (tConsumo) => tConsumo.id == resultado.id_consumtype
      );
      const tipoUsuarioFilter = tipoUsuario.filter(
        (tUsuario) => tUsuario.id == resultado.id_usertype
      );
      const tipoServicioFilter = tipoServicio.filter(
        (tServicio) => tServicio.id == resultado.id_servicetype
      );
      const estadoServicioFilter = estadoServicio.filter(
        (eServicio) => eServicio.id == resultado.id_servicestatus
      );
      const tipoStorageFilter = tipoAlmacenamiento.filter(
        (tStorage) => tStorage.id == resultado.id_userStorage
      );

      const nuevoUsuario = {
        id: resultado.id,
        user: user,
        lastname: lastname,
        phone: phone,
        address: address,
        reference: reference,
        id_colony: id_colony,
        id_locality: id_locality,
        id_zone: id_zone,
        block: block,
        int_num: int_num,
        ext_num: ext_num,
        mail: mail,
        rfc: rfc,
        clave_elector: clave_elector,
        drenaje: drenaje,
        id_usertype: id_usertype,
        id_intaketype: id_intaketype,
        id_servicetype: id_servicetype,
        id_servicestatus: id_servicestatus,
        id_consumtype: id_consumtype,
        id_typeperson: id_typeperson,
        id_userStorage: id_userStorage,
        storage_height: storage_height,
        inhabitants: inhabitants,
        stored_water: stored_water,
        id_colony: coloniasFilter[0].name,
        name_colony: coloniasFilter[0].name,
        name_locality: localidadesFilter[0].name,
        name_zone: zonesFilter[0].name,
        name_user_type: tipoUsuarioFilter[0].name,
        name_intake_type: tipoTomaFilter[0].name,
        name_service_type: tipoServicioFilter[0].name,
        name_service_status: estadoServicioFilter[0].name,
        name_consume_type: tipoConsumoFilter[0].name,
        name_userStorage: tipoStorageFilter[0].name,
      };
      usuarios = [...usuarios, nuevoUsuario];
      mostrarUsuarios();
    }
  } catch (error) {
    console.log(error);
  }
}
//date de eliminar dato de usuario
async function confirmaDelete(usuario) {
  Swal.fire({
    title: "¿Estás seguro?",
    text: "Esta acción no se puede deshacer",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Sí, eliminar",
    cancelButtonText: "Cancelar",
  }).then((result) => {
    if (result.isConfirmed) {
      eliminarUsuario(usuario);
    }
  });
}
async function eliminarUsuario(usuario) {
  const data = new FormData();
  data.append("id", usuario.id);
  try {
    const URL = `http://localhost:8000/delete-user/${usuario.id}`;
    const respuesta = await fetch(URL, {
      method: "POST",
      body: data,
    });
    const resultado = await respuesta.json();
    if (resultado.resultado === "Exito") {
      Swal.fire({
        icon: "success",
        title: resultado.resultado,
        text: "Eliminación exitosa",
      });
      usuarios = usuarios.filter((usuarioMem) => usuarioMem.id !== usuario.id);

      mostrarUsuarios();
    }
  } catch (error) {
    console.log(error);
  }
}
