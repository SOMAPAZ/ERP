//llamados server
obtenerUsers();
obtenerColonias();
obtenerLocalidades();
obtenerZones();
obtenerTipoToma();
obtenerTipoConsumo();
obtenerTipoUsuario();
obtenerTipoServicio();
obtenerEstadosServicio();
//paginacion
let paginaActual = 1;
const usuariosPorPagina = 10;
const usuarioObj = {
  id: "",
  user: "",
  lastname: "",
  phone: "",
  address: "",
  reference: "",
  id_colony: "",
  id_locality: "",
  id_zone: "",
  block: "",
  int_num: "",
  ext_num: "",
  mail: "",
  rfc: "",
  clave_elector: "",
  drenaje: "",
  id_usertype: "",
  id_intaketype: "",
  id_servicetype: "",
  id_servicestatus: "",
  id_consumtype: "",
  id_typeperson: "",
};
//tabla
const tablaUsuarios = document.querySelector("#usuario-tabla");
const controlesPaginacion = document.querySelector("#controles-paginacion");
const trVacio = document.querySelector("#userdatos");
const crearUsuario = document.querySelector("#crear-usuario");

let usuarios = [];
//colonias
let colonias = [];
let coloniasFilter = [];
//localidades
let localidades = [];
let localidadesFilter = [];
//ZONA
let zones = [];
let zonesFilter = [];
//tipo de toma
let tipoToma = [];
let tipoTomaFilter = [];
//tipo de consumo
let tipoConsumo = [];
let tipoConsumoFilter = [];
//tipo de usuario
let tipoUsuario = [];
let tipoUsuarioFilter = [];
//tipo de servicio
let tipoServicio = [];
let tipoServicioFilter = [];
//estado de servicio
let estadoServicio = [];
let estadoServicioFilter = [];
//drenaje
let drenaje = [];
//typeperson
let tipoPersona = [];
document.addEventListener("DOMContentLoaded", () => {
  inicializarPagina();
});
crearUsuario.addEventListener("click", () => {
  mostrarFormulario({});
});
//paginacion
function inicializarPagina() {
  const urlParams = new URLSearchParams(window.location.search);
  const pagina = parseInt(urlParams.get("pagina")) || 1;
  paginaActual = pagina;
  obtenerUsers();
}
function cambiarPagina(nuevaPagina) {
  paginaActual = nuevaPagina;

  const urlParams = new URLSearchParams(window.location.search);
  urlParams.set("pagina", nuevaPagina);
  window.history.pushState({}, "", `${window.location.pathname}?${urlParams}`);

  mostrarUsuarios();
  crearControlesPaginacion();
}
function crearControlesPaginacion() {
  controlesPaginacion.innerHTML = "";

  const totalPaginas = Math.ceil(usuarios.length / usuariosPorPagina);
  const rango = 2;

  if (totalPaginas < 1) return;

  controlesPaginacion.appendChild(crearBotonPagina(1));

  if (paginaActual - rango > 2) {
    const puntosInicio = document.createElement("SPAN");
    puntosInicio.textContent = "...";
    puntosInicio.className = "px-2 text-gray-500 justify-center";
    controlesPaginacion.appendChild(puntosInicio);
  }

  for (
    let i = Math.max(2, paginaActual - rango);
    i <= Math.min(totalPaginas - 1, paginaActual + rango);
    i++
  ) {
    controlesPaginacion.appendChild(crearBotonPagina(i));
  }

  if (paginaActual + rango < totalPaginas - 1) {
    const puntosFin = document.createElement("SPAN");
    puntosFin.textContent = "...";
    puntosFin.className = "px-2 text-gray-500";
    controlesPaginacion.appendChild(puntosFin);
  }

  if (totalPaginas > 1) {
    controlesPaginacion.appendChild(crearBotonPagina(totalPaginas));
  }
}
function crearBotonPagina(numeroPagina) {
  const botonPagina = document.createElement("BUTTON");
  botonPagina.textContent = numeroPagina;
  botonPagina.className = `px-4 py-2 ${
    numeroPagina === paginaActual
      ? "bg-blue-500 text-white"
      : "bg-gray-200 text-black"
  }`;
  botonPagina.onclick = () => cambiarPagina(numeroPagina);
  return botonPagina;
}
//limpiar html
function limpiarHtml() {
  while (tablaUsuarios.firstChild) {
    tablaUsuarios.removeChild(tablaUsuarios.firstChild);
  }
}
//creacion de inputs
function crearInput(array, formulario, valores) {
  // const fieldTranslations = {
  //   user: "Nombre de Usuario",
  //   lastname: "Apellido (S)",
  //   phone: "Teléfono",
  //   address: "Dirección",
  //   reference: "Referencias",
  //   block: "Cuadra",
  //   int_num: "# Int",
  //   ext_num: "# Ext",
  //   mail: "Correo Electrónico",
  //   rfc: "RFC",
  //   clave_elector: "Clave de Elector",
  // };

  array.forEach((element) => {
    const div = document.createElement("DIV");
    div.className = "mb-5";

    // Traducir el nombre del campo o usar el original si no hay traducción
    const labelName = element;

    const label = document.createElement("LABEL");
    label.for = element;
    label.className =
      "block mb-2 text-sm font-medium text-gray-900 text-sm uppercase dark:text-white";
    label.textContent = labelName;

    const input = document.createElement("INPUT");
    input.type = "text";
    input.id = element;
    input.name = element;
    input.className =
      "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white";
    input.placeholder = `Ingrese el ${labelName.toLowerCase()}`;
    input.value = valores[element] || ""; // Prellenar con los valores si existen

    div.appendChild(label);
    div.appendChild(input);
    formulario.appendChild(div);
  });
}

// Obtener usuarios
async function obtenerUsers() {
  try {
    const URL = "http://localhost:8000/api/user";
    const respuesta = await fetch(URL);
    const resultado = await respuesta.json();
    usuarios = resultado;
    mostrarUsuarios();
    crearControlesPaginacion();
  } catch (error) {
    console.log(error);
  }
}
//obtener colonias
async function obtenerColonias() {
  try {
    const URL = "http://localhost:8000/api/colonies";
    const respuesta = await fetch(URL);
    const resultado = await respuesta.json();
    colonias = resultado;
  } catch (error) {
    console.log(error);
  }
}
//obtener localidades
async function obtenerLocalidades() {
  try {
    const URL = "http://localhost:8000/api/locality";
    const respuesta = await fetch(URL);
    const resultado = await respuesta.json();
    localidades = resultado;
  } catch (error) {
    console.log(error);
  }
}
//obtener zonas
async function obtenerZones() {
  try {
    const URL = "http://localhost:8000/api/zone";
    const respuesta = await fetch(URL);
    const resultado = await respuesta.json();
    zones = resultado;
  } catch (error) {
    console.log(error);
  }
}
//tipo toma
async function obtenerTipoToma() {
  try {
    const URL = "http://localhost:8000/api/intake_type";
    const respuesta = await fetch(URL);
    const resultado = await respuesta.json();
    tipoToma = resultado;
  } catch (error) {
    console.log(error);
  }
}
//tipo de consumo
async function obtenerTipoConsumo() {
  try {
    const URL = "http://localhost:8000/api/consumetypes";
    const respuesta = await fetch(URL);
    const resultado = await respuesta.json();
    tipoConsumo = resultado;
  } catch (error) {
    console.log(error);
  }
}
//tipo de usuario
async function obtenerTipoUsuario() {
  try {
    const URL = "http://localhost:8000/api/usertype";
    const respuesta = await fetch(URL);
    const resultado = await respuesta.json();
    tipoUsuario = resultado;
  } catch (error) {
    console.log(error);
  }
}
//tipo de servicio
async function obtenerTipoServicio() {
  try {
    const URL = "http://localhost:8000/api/servicetype";
    const respuesta = await fetch(URL);
    const resultado = await respuesta.json();
    tipoServicio = resultado;
  } catch (error) {
    console.log(error);
  }
}
//estado de servicio
async function obtenerEstadosServicio() {
  try {
    const URL = "http://localhost:8000/api/servicestatus";
    const respuesta = await fetch(URL);
    const resultado = await respuesta.json();
    estadoServicio = resultado;
  } catch (error) {
    console.log(error);
  }
}
//creacion de formulario
function mostrarFormulario(usuario, editar = false) {
  const fieldTraslations = {
    user: "Nombre de Usuario",
    lastname: "Apellido (s)",
    phone: "Telefono",
    address: "Direccion",
    reference: "Referencias",
    block: "Cuadra",
    int_num: "# Int",
    ext_num: "# Ext",
    mail: "Correo",
    rfc: "RFC",
    clave_elector: "Clave de Elector",
  };
  const main = document.querySelector("main");
  const divBgModal = document.createElement("DIV"); //contenedor modal
  divBgModal.id = "divBgModal";

  const divModal = document.createElement("DIV"); //modal
  divModal.className =
    "overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 bottom-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%)] max-h-full bg-gray-900";

  const divContent = document.createElement("DIV");
  divContent.className =
    "relative p-4 w-full max-w-2xl max-h-full mx-auto mt-5";

  const formulario = document.createElement("FORM");
  formulario.className =
    "relative bg-white rounded-lg p-4 shadow dark:bg-gray-700";
  let nombreInputs = [
    "user",
    "lastname",
    "phone",
    "address",
    "reference",
    "block",
    "int_num",
    "ext_num",
    "mail",
    "rfc",
    "clave_elector",
  ];
  crearInput(nombreInputs, formulario, usuario);

  //creacion del selector de colonias
  const divColony = document.createElement("DIV");
  divColony.className = "mb-5";
  const labelColony = document.createElement("LABEL");
  labelColony.for = "id_colony";
  labelColony.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelColony.textContent = "COLONIA";
  const selectorColony = document.createElement("SELECT");

  selectorColony.name = "id_colony";
  selectorColony.id = "id_colony";
  selectorColony.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white ";

  colonias.forEach((colony) => {
    const option = document.createElement("OPTION");
    option.value = colony.id;
    option.textContent = colony.name;

    colony.id == usuario.id_colony ? (option.selected = true) : null;

    selectorColony.appendChild(option);
  });

  //creacion del selector de localidades
  const divLocalidad = document.createElement("DIV");
  divLocalidad.className = "mb-5";
  const labelLocalidad = document.createElement("LABEL");
  labelLocalidad.for = "id_locality";
  labelLocalidad.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelLocalidad.textContent = "LOCALIDAD";
  const selectorLocalidad = document.createElement("SELECT");

  selectorLocalidad.name = "id_locality";
  selectorLocalidad.id = "id_locality";
  selectorLocalidad.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white ";

  localidades.forEach((locality) => {
    const option = document.createElement("OPTION");
    option.value = locality.id;
    option.textContent = locality.name;

    locality.id == usuario.id_locality ? (option.selected = true) : null;

    selectorLocalidad.appendChild(option);
  });

  //creacion del selector de zonas
  const divZona = document.createElement("DIV");
  divZona.className = "mb-5";
  const labelZona = document.createElement("LABEL");
  labelZona.for = "id_zone";
  labelZona.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelZona.textContent = "ZONA";
  const selectorZona = document.createElement("SELECT");

  selectorZona.name = "id_zone";
  selectorZona.id = "id_zone";
  selectorZona.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white ";

  zones.forEach((zone) => {
    const option = document.createElement("OPTION");
    option.value = zone.id;
    option.textContent = zone.name;

    zone.id == usuario.id_zone ? (option.selected = true) : null;

    selectorZona.appendChild(option);
  });
  //creacion del selector de tipo de toma
  const divTipoToma = document.createElement("DIV");
  divTipoToma.className = "mb-5";
  const labelTipoToma = document.createElement("LABEL");
  labelTipoToma.for = "id_intaketype";
  labelTipoToma.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelTipoToma.textContent = "TIPO DE TOMA";
  const selectorTipoToma = document.createElement("SELECT");
  selectorTipoToma.name = "id_intaketype";
  selectorTipoToma.id = "id_intaketype";
  selectorTipoToma.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white ";
  tipoToma.forEach((tipoToma) => {
    const option = document.createElement("OPTION");
    option.value = tipoToma.id;
    option.textContent = tipoToma.name;
    tipoToma.id == usuario.id_intaketype ? (option.selected = true) : null;
    selectorTipoToma.appendChild(option);

    selectorTipoToma.appendChild(option);
  });
  //creacion del selector de tipo de consumo
  const divTipoConsumo = document.createElement("DIV");
  divTipoConsumo.className = "mb-5";
  const labelTipoConsumo = document.createElement("LABEL");
  labelTipoConsumo.for = "id_consumtype";
  labelTipoConsumo.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelTipoConsumo.textContent = "TIPO DE CONSUMO";
  const selectorTipoConsumo = document.createElement("SELECT");
  selectorTipoConsumo.name = "id_consumtype";
  selectorTipoConsumo.id = "id_consumtype";
  selectorTipoConsumo.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white ";
  tipoConsumo.forEach((tipoConsumo) => {
    const option = document.createElement("OPTION");
    option.value = tipoConsumo.id;
    option.textContent = tipoConsumo.name;
    tipoConsumo.id == usuario.id_consumtype ? (option.selected = true) : null;
    selectorTipoConsumo.appendChild(option);
  });
  //tipo de usuario
  const divTipoUsuario = document.createElement("DIV");
  divTipoUsuario.className = "mb-5";
  const labelTipoUsuario = document.createElement("LABEL");
  labelTipoUsuario.for = "id_usertype";
  labelTipoUsuario.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelTipoUsuario.textContent = "TIPO DE USUARIO";
  const selectorTipoUsuario = document.createElement("SELECT");
  selectorTipoUsuario.name = "id_usertype";
  selectorTipoUsuario.id = "id_usertype";
  selectorTipoUsuario.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white";
  tipoUsuario.forEach((tipoUsuario) => {
    const option = document.createElement("OPTION");
    option.value = tipoUsuario.id;
    option.textContent = tipoUsuario.name;
    tipoUsuario.id = usuario.id_usertype ? (option.selected = true) : null;
    selectorTipoUsuario.appendChild(option);
  });
  //creacion del selector de tipo de servicio
  const divTipoServicio = document.createElement("DIV");
  divTipoServicio.className = "mb-5";
  const labelTipoServicio = document.createElement("LABEL");
  labelTipoServicio.for = "id_servicetype";
  labelTipoServicio.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelTipoServicio.textContent = "TIPO DE SERVICIO";
  const selectorTipoServicio = document.createElement("SELECT");
  selectorTipoServicio.name = "id_servicetype";
  selectorTipoServicio.id = "id_servicetype";
  selectorTipoServicio.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white ";

  tipoServicio.forEach((tipoServicio) => {
    const option = document.createElement("OPTION");
    option.value = tipoServicio.id;
    option.textContent = tipoServicio.name;
    tipoServicio.id == usuario.id_servicetype ? (option.selected = true) : null;
    selectorTipoServicio.appendChild(option);
  });
  //estado de servicio
  const divEstadoServicio = document.createElement("DIV");
  divEstadoServicio.className = "mb-5";
  const labelEstadoServicio = document.createElement("LABEL");
  labelEstadoServicio.for = "id_servicestatus";
  labelEstadoServicio.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelEstadoServicio.textContent = "ESTADO DE SERVICIO";
  const selectorEstadoServicio = document.createElement("SELECT");
  selectorEstadoServicio.name = "id_servicestatus";
  selectorEstadoServicio.id = "id_servicestatus";
  selectorEstadoServicio.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white ";

  estadoServicio.forEach((estadoServicio) => {
    const option = document.createElement("OPTION");
    option.value = estadoServicio.id;
    option.textContent = estadoServicio.name;
    estadoServicio.id == usuario.id_servicestatus
      ? (option.selected = true)
      : null;
    selectorEstadoServicio.appendChild(option);
  });
  // Contenedor del selector de drenaje
  const divDrenaje = document.createElement("DIV");
  divDrenaje.className = "mb-5";
  const labelDrenaje = document.createElement("LABEL");
  labelDrenaje.for = "drenaje";
  labelDrenaje.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelDrenaje.textContent = "DRENAJE";
  const selectorDrenaje = document.createElement("SELECT");
  selectorDrenaje.name = "drenaje";
  selectorDrenaje.id = "drenaje";
  selectorDrenaje.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white";
  const optionSi = document.createElement("OPTION");
  optionSi.value = 1;
  optionSi.textContent = "Sí";
  const optionNo = document.createElement("OPTION");
  optionNo.value = 0;
  optionNo.textContent = "No";
  usuario.drenaje === 1
    ? (optionSi.selected = true)
    : (optionNo.selected = true);
  selectorDrenaje.appendChild(optionSi);
  selectorDrenaje.appendChild(optionNo);
  //selector de tipo de persona
  const divTipoPersona = document.createElement("DIV");
  divTipoPersona.className = "mb-5";
  const labelTipoPersona = document.createElement("LABEL");
  labelTipoPersona.for = "id_typeperson";
  labelTipoPersona.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelTipoPersona.textContent = "TIPO DE PERSONA";
  const selectorTipoPersona = document.createElement("SELECT");
  selectorTipoPersona.name = "id_typeperson";
  selectorTipoPersona.id = "id_typeperson";
  selectorTipoPersona.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white ";
  const optionMoral = document.createElement("OPTION");
  optionMoral.value = 1;
  optionMoral.textContent = "Moral";
  const optionFisica = document.createElement("OPTION");
  optionFisica.value = 2;
  optionFisica.textContent = "Fisica";
  usuario.id_typeperson === 1
    ? (optionMoral.selected = true)
    : (optionFisica.selected = true);
  selectorTipoPersona.appendChild(optionMoral);
  selectorTipoPersona.appendChild(optionFisica);
  // Agregar opciones al selector
  divColony.appendChild(labelColony);
  divColony.appendChild(selectorColony);
  divLocalidad.appendChild(labelLocalidad);
  divLocalidad.appendChild(selectorLocalidad);
  divDrenaje.appendChild(labelDrenaje);
  divDrenaje.appendChild(selectorDrenaje);
  divTipoPersona.appendChild(labelTipoPersona);
  divTipoPersona.appendChild(selectorTipoPersona);
  divZona.appendChild(labelZona);
  divZona.appendChild(selectorZona);
  divTipoToma.appendChild(labelTipoToma);
  divTipoToma.appendChild(selectorTipoToma);
  divTipoConsumo.appendChild(labelTipoConsumo);
  divTipoConsumo.appendChild(selectorTipoConsumo);
  divTipoUsuario.appendChild(labelTipoUsuario);
  divTipoUsuario.appendChild(selectorTipoUsuario);
  divTipoServicio.appendChild(labelTipoServicio);
  divTipoServicio.appendChild(selectorTipoServicio);
  divEstadoServicio.appendChild(labelEstadoServicio);
  divEstadoServicio.appendChild(selectorEstadoServicio);

  // Añadir el divTipoPersona de manera explícita
  const btnGuardar = document.createElement("INPUT");
  btnGuardar.className =
    "w-full mb-2 text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800";
  btnGuardar.value = "Guardar";
  btnGuardar.type = "submit";
  btnGuardar.onclick = (e) => {
    e.preventDefault();
    if (editar) {
      enviarFormulario({ ...usuario });
    } else {
      guardarUsuario();
    }
  };
  //asignacion de las funciones de colonia en el boton
  formulario.appendChild(divTipoPersona);

  formulario.appendChild(divColony);
  formulario.appendChild(divLocalidad);
  formulario.appendChild(divZona);
  formulario.appendChild(divDrenaje);

  formulario.appendChild(divTipoUsuario);
  formulario.appendChild(divEstadoServicio);
  formulario.appendChild(divTipoServicio);
  formulario.appendChild(divTipoToma);
  formulario.appendChild(divTipoConsumo);
  formulario.appendChild(btnGuardar);

  const botonesDiv = document.createElement("DIV");
  botonesDiv.className =
    "flex justify-end p-4 md:p-5 border-t border-gray-200 rounded-b dark:border-gray-600";

  const btnCancelar = document.createElement("BUTTON");
  btnCancelar.className =
    "py-2.5 px-5  text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700";
  btnCancelar.textContent = "Cancelar";
  btnCancelar.onclick = () => {
    divBgModal.remove();
  };
  botonesDiv.appendChild(btnCancelar);
  formulario.appendChild(botonesDiv);

  divContent.appendChild(formulario);
  divModal.appendChild(divContent);
  divBgModal.appendChild(divModal);
  main.appendChild(divBgModal);
}
//mostrar usuarios
async function mostrarUsuarios() {
  limpiarHtml();
  const inicio = (paginaActual - 1) * usuariosPorPagina;
  const fin = inicio + usuariosPorPagina;
  const usuariosPagina = usuarios.slice(inicio, fin);

  trVacio.remove();
  usuariosPagina.forEach((usuario) => {
    const {
      id,
      user,
      lastname,
      phone,
      address,
      reference,
      id_colony,
      id_locality,
      id_zone,
      name_colony,
      name_locality,
      name_zone,
      block,
      int_num,
      ext_num,
      mail,
      rfc,
      clave_elector,
      drenaje,
      id_usertype,
      id_intaketype,
      id_servicetype,
      id_servicestatus,
      id_consumtype,
      id_typeperson,
      name_user_type,
      name_intake_type,
      name_service_type,
      name_service_status,
      name_consume_type,
    } = usuario;
    const fila = document.createElement("TR");
    fila.className = "bg-white border-b dark:bg-gray-800 dark:border-gray-700";

    const celdaId = document.createElement("TD");
    celdaId.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaId.textContent = id;
    const celdaNombre = document.createElement("TD");
    celdaNombre.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaNombre.textContent = `${user} ${lastname}`;

    const celtaTipoPersona = document.createElement("TD");
    celtaTipoPersona.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celtaTipoPersona.textContent = id_typeperson === 1 ? "Moral" : "Fisica";

    const celdaTelefono = document.createElement("TD");
    celdaTelefono.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaTelefono.textContent = phone === 0 || phone > 0 ? phone : "N/A";

    const celdaDireccion = document.createElement("TD");
    celdaDireccion.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaDireccion.textContent =
      address === 0 || address > "" ? address : "N/A";
    const celdaReferencias = document.createElement("TD");
    celdaReferencias.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaReferencias.textContent =
      reference === 0 || reference > "" ? reference : "N/A";

    const celdaColonia = document.createElement("TD");
    celdaColonia.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaColonia.textContent = name_colony;

    const celdaLocalidad = document.createElement("TD");
    celdaLocalidad.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaLocalidad.textContent = name_locality;

    const celdaZona = document.createElement("TD");
    celdaZona.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaZona.textContent = name_zone;

    const celdaCuadra = document.createElement("TD");
    celdaCuadra.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaCuadra.textContent = name_zone;

    const celdaInt = document.createElement("TD");
    celdaInt.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaInt.textContent = int_num === 0 || int_num > 0 ? int_num : "N/A";

    const celdaExt = document.createElement("TD");
    celdaExt.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaExt.textContent = ext_num === 0 || ext_num > 0 ? ext_num : "N/A";

    const celdaCorreo = document.createElement("TD");
    celdaCorreo.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaCorreo.textContent = mail === 0 || mail > "" ? mail : "N/A";

    const celdaRFC = document.createElement("TD");
    celdaRFC.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaRFC.textContent = rfc === 0 || rfc > "" ? rfc : "N/A";

    const celdaClaveElector = document.createElement("TD");
    celdaClaveElector.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaClaveElector.textContent =
      clave_elector === 0 || clave_elector > "" ? clave_elector : "N/A";

    const celdaDrenaje = document.createElement("TD");
    celdaDrenaje.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaDrenaje.textContent = drenaje === 0 || drenaje === 1 ? "Sí" : "No";

    const celdaTipoUsuario = document.createElement("TD");
    celdaTipoUsuario.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaTipoUsuario.textContent = name_user_type;

    const celdaTipoToma = document.createElement("TD");
    celdaTipoToma.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaTipoToma.textContent = name_intake_type;

    const celdaTipoServicio = document.createElement("TD");
    celdaTipoServicio.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaTipoServicio.textContent = name_service_type;

    const celdaEstadoServicio = document.createElement("TD");
    celdaEstadoServicio.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaEstadoServicio.textContent = name_service_status;

    const celdaTipoConsumo = document.createElement("TD");
    celdaTipoConsumo.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaTipoConsumo.textContent = name_consume_type;

    const celdaAcciones = document.createElement("TD");
    celdaAcciones.className =
      "flex justify-between px-6 py-3 whitespace-nowrap gap-3";

    const btnEditar = document.createElement("BUTTON");
    btnEditar.className =
      "bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded";
    btnEditar.textContent = "Editar";
    btnEditar.onclick = () => {
      mostrarFormulario(usuario, true);
    };
    const btnEliminar = document.createElement("BUTTON");
    btnEliminar.className =
      "bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded";
    btnEliminar.textContent = "Eliminar";
    // btnEliminar.onclick = () => {
    //   confimarDelete(usuario);
    // };

    celdaAcciones.appendChild(btnEditar);
    celdaAcciones.appendChild(btnEliminar);

    fila.appendChild(celdaAcciones);
    fila.appendChild(celdaId);
    fila.appendChild(celdaNombre);
    fila.appendChild(celtaTipoPersona);
    fila.appendChild(celdaTelefono);
    fila.appendChild(celdaDireccion);
    fila.appendChild(celdaReferencias);
    fila.appendChild(celdaColonia);
    fila.appendChild(celdaLocalidad);
    fila.appendChild(celdaZona);
    fila.appendChild(celdaCuadra);
    fila.appendChild(celdaInt);
    fila.appendChild(celdaExt);
    fila.appendChild(celdaCorreo);
    fila.appendChild(celdaRFC);
    fila.appendChild(celdaClaveElector);
    fila.appendChild(celdaDrenaje);
    fila.appendChild(celdaTipoUsuario);
    fila.appendChild(celdaTipoToma);
    fila.appendChild(celdaTipoServicio);
    fila.appendChild(celdaEstadoServicio);
    fila.appendChild(celdaTipoConsumo);

    tablaUsuarios.appendChild(fila);
  });
}
//actualizar usuario
async function enviarFormulario(usuario) {
  const id = usuario.id;
  console.log("datos", id);
  const user = document.querySelector("#user").value.trim();
  const lastname = document.querySelector("#lastname").value.trim();
  const phone = document.querySelector("#phone").value.trim();
  const address = document.querySelector("#address").value.trim();
  const reference = document.querySelector("#reference").value.trim();
  const id_colony = document.querySelector("#id_colony").value.trim();
  const id_locality = document.querySelector("#id_locality").value.trim();
  const id_zone = document.querySelector("#id_zone").value.trim();
  const block = document.querySelector("#block").value.trim();
  const int_num = document.querySelector("#int_num").value.trim();
  const ext_num = document.querySelector("#ext_num").value.trim();
  const mail = document.querySelector("#mail").value.trim();
  const rfc = document.querySelector("#rfc").value.trim();
  const clave_elector = document.querySelector("#clave_elector").value.trim();
  const drenaje = document.querySelector("#drenaje").value.trim();
  const id_usertype = document.querySelector("#id_usertype").value.trim();
  const id_intaketype = document.querySelector("#id_intaketype").value.trim();
  const id_servicetype = document.querySelector("#id_servicetype").value.trim();
  const id_servicestatus = document
    .querySelector("#id_servicestatus")
    .value.trim();
  const id_consumtype = document.querySelector("#id_consumtype").value.trim();
  const id_typeperson = document.querySelector("#id_typeperson").value.trim();
  const usuarioObj = {
    id: id, // El id debe estar presente aquí
    user: user,
    lastname: lastname,
    phone: phone,
    address: address,
    reference: reference,
    id_colony: id_colony,
    id_locality: id_locality,
    id_zone: id_zone,
    block: block,
    int_num: int_num,
    ext_num: ext_num,
    mail: mail,
    rfc: rfc,
    clave_elector: clave_elector,
    drenaje: drenaje,
    id_usertype: id_usertype,
    id_intaketype: id_intaketype,
    id_servicetype: id_servicetype,
    id_servicestatus: id_servicestatus,
    id_consumtype: id_consumtype,
    id_typeperson: id_typeperson,
  };

  if (Object.values(usuarioObj).some((v) => v === "")) {
    console.log("El campo no puede estar vacío");
    return;
  }

  const data = new FormData();
  data.append("id", id);
  data.append("user", user);
  data.append("lastname", lastname);
  data.append("phone", phone);
  data.append("id_colony", id_colony);
  data.append("id_locality", id_locality);
  data.append("id_zone", id_zone);
  data.append("address", address);
  data.append("reference", reference);
  data.append("block", block);
  data.append("int_num", int_num);
  data.append("ext_num", ext_num);
  data.append("mail", mail);
  data.append("rfc", rfc);
  data.append("clave_elector", clave_elector);
  data.append("drenaje", drenaje);
  data.append("id_usertype", id_usertype);
  data.append("id_intaketype", id_intaketype);
  data.append("id_servicetype", id_servicetype);
  data.append("id_servicestatus", id_servicestatus);
  data.append("id_consumtype", id_consumtype);
  data.append("id_typeperson", id_typeperson);

  try {
    const URL = `http://localhost:8000/update-user/${id}`;
    const respuesta = await fetch(URL, {
      method: "POST",
      body: data,
    });
    const resultado = await respuesta.json();
    if (resultado.resultado === "Exito") {
      Swal.fire({
        icon: "success",
        title: resultado.resultado,
        text: "Actualización exitosa",
      });
      document.querySelector("#divBgModal").remove();
      coloniasFilter = colonias.filter(
        (colony) => colony.id == resultado.id_colony
      );
      localidadesFilter = localidades.filter(
        (locality) => locality.id == resultado.id_locality
      );
      zonesFilter = zones.filter((zone) => zone.id == resultado.id_zone);
      tipoTomaFilter = tipoToma.filter(
        (tipoToma) => tipoToma.id == resultado.id_intaketype
      );
      tipoUsuarioFilter = tipoUsuario.filter(
        (tipoUsuario) => tipoUsuario.id == resultado.id_usertype
      );
      tipoServicioFilter = tipoServicio.filter(
        (tipoServicio) => tipoServicio.id == resultado.id_servicetype
      );
      estadoServicioFilter = estadoServicio.filter(
        (estadoServicio) => estadoServicio.id == resultado.id_servicestatus
      );
      tipoConsumoFilter = tipoConsumo.filter(
        (tipoConsumo) => tipoConsumo.id == resultado.id_consumtype
      );

      tipoPersonaFilter = tipoPersona.filter(
        (tipoPersona) => tipoPersona.id == resultado.id_typeperson
      );
      usuarios = usuarios.map((usuarioMem) => {
        if (usuarioMem.id === id) {
          console.log(usuarioMem);
          usuarioMem.user = resultado.user;
          usuarioMem.lastname = resultado.lastname;
          usuarioMem.phone = resultado.phone;
          usuarioMem.id_colony = resultado.id_colony;
          usuarioMem.name_colony = coloniasFilter[0].name;
          usuarioMem.id_locality = resultado.id_locality;
          usuarioMem.name_locality = localidadesFilter[0].name;
          usuarioMem.id_zone = resultado.id_zone;
          usuarioMem.name_zone = zonesFilter[0].name;
          usuarioMem.address = resultado.address;
          usuarioMem.reference = resultado.reference;
          usuarioMem.block = resultado.block;
          usuarioMem.int_num = resultado.int_num;
          usuarioMem.ext_num = resultado.ext_num;
          usuarioMem.mail = resultado.mail;
          usuarioMem.rfc = resultado.rfc;
          usuarioMem.clave_elector = resultado.clave_elector;
          usuarioMem.drenaje = resultado.drenaje;
          usuarioMem.id_usertype = resultado.id_usertype;
          if (tipoUsuarioFilter && tipoUsuarioFilter.length > 0) {
            usuarioMem.name_user_type = tipoUsuarioFilter[0].name;
          } else {
            console.error("Error: tipoUsuarioFilter está vacío o indefinido.");
            usuarioMem.name_user_type = "Desconocido"; // O cualquier valor por defecto
          }
          usuarioMem.id_intaketype = resultado.id_intaketype;
          usuarioMem.name_intake_type = tipoTomaFilter[0].name;
          usuarioMem.id_servicetype = resultado.id_servicetype;
          usuarioMem.name_service_type = tipoServicioFilter[0].name;
          usuarioMem.id_servicestatus = resultado.id_servicestatus;
          usuarioMem.name_service_status = estadoServicioFilter[0].name;
          usuarioMem.id_consumtype = resultado.id_consumtype;
          usuarioMem.name_consume_type = tipoConsumoFilter[0].name;
          usuarioMem.id_typeperson = resultado.id_typeperson;
        }
        return usuarioMem;
      });
      mostrarUsuarios();
    }
  } catch (error) {
    console.log(error);
  }
}
//creacion de inputs
async function guardarUsuario() {
  const user = document.querySelector("#user").value.trim();
  const lastname = document.querySelector("#lastname").value.trim();
  const phone = document.querySelector("#phone").value.trim();
  const address = document.querySelector("#address").value.trim();
  const reference = document.querySelector("#reference").value.trim();
  const id_colony = document.querySelector("#id_colony").value.trim();
  const id_locality = document.querySelector("#id_locality").value.trim();
  const id_zone = document.querySelector("#id_zone").value.trim();
  const block = document.querySelector("#block").value.trim();
  const int_num = document.querySelector("#int_num").value.trim();
  const ext_num = document.querySelector("#ext_num").value.trim();
  const mail = document.querySelector("#mail").value.trim();
  const rfc = document.querySelector("#rfc").value.trim();
  const clave_elector = document.querySelector("#clave_elector").value.trim();
  const drenaje = document.querySelector("#drenaje").value.trim();
  const id_usertype = document.querySelector("#id_usertype").value.trim();
  const id_intaketype = document.querySelector("#id_intaketype").value.trim();
  const id_servicetype = document.querySelector("#id_servicetype").value.trim();
  const id_servicestatus = document
    .querySelector("#id_servicestatus")
    .value.trim();
  const id_consumtype = document.querySelector("#id_consumtype").value.trim();
  const id_typeperson = document.querySelector("#id_typeperson").value.trim();

  const usuarioObj = {
    user: user,
    lastname: lastname,
    phone: phone,
    address: address,
    reference: reference,
    id_colony: id_colony,
    id_locality: id_locality,
    id_zone: id_zone,
    block: block,
    int_num: int_num,
    ext_num: ext_num,
    mail: mail,
    rfc: rfc,
    clave_elector: clave_elector,
    drenaje: drenaje,
    id_usertype: id_usertype,
    id_intaketype: id_intaketype,
    id_servicetype: id_servicetype,
    id_servicestatus: id_servicestatus,
    id_consumtype: id_consumtype,
    id_typeperson: id_typeperson,
  };

  // if (Object.values(usuarioObj).some((v) => v === "")) {
  //   console.log("El campo no puede estar vacío");
  //   return;
  // }
  const data = new FormData();
  data.append("user", user);
  data.append("lastname", lastname);
  data.append("phone", phone);
  data.append("address", address);
  data.append("reference", reference);
  data.append("id_colony", id_colony);
  data.append("id_locality", id_locality);
  data.append("id_zone", id_zone);
  data.append("block", block);
  data.append("int_num", int_num);
  data.append("ext_num", ext_num);
  data.append("mail", mail);
  data.append("rfc", rfc);
  data.append("clave_elector", clave_elector);
  data.append("drenaje", drenaje);
  data.append("id_usertype", id_usertype);
  data.append("id_intaketype", id_intaketype);
  data.append("id_servicetype", id_servicetype);
  data.append("id_servicestatus", id_servicestatus);
  data.append("id_consumtype", id_consumtype);
  data.append("id_typeperson", id_typeperson);

  try {
    const URL = `http://localhost:8000/create-user`;
    const respuesta = await fetch(URL, {
      method: "POST",
      body: data,
    });
    const resultado = await respuesta.json();
    if (resultado.resultado === "Exito") {
      Swal.fire({
        icon: "success",
        title: resultado.resultado,
        text: "Creación exitosa",
      });
      document.querySelector("#divBgModal").remove();
      const coloniasFilter = colonias.filter(
        (colony) => colony.id == resultado.id_colony
      );
      const localidadesFilter = localidades.filter(
        (locality) => locality.id == resultado.id_locality
      );
      const zonesFilter = zones.filter((zone) => zone.id == resultado.id_zone);
      const tipoTomaFilter = tipoToma.filter(
        (tipoToma) => tipoToma.id == resultado.id_intaketype
      );
      const tipoConsumoFilter = tipoConsumo.filter(
        (tipoConsumo) => tipoConsumo.id == resultado.id_consumtype
      );
      const tipoUsuarioFilter = tipoUsuario.filter(
        (tipoUsuario) => tipoUsuario.id == resultado.id_usertype
      );
      const tipoServicioFilter = tipoServicio.filter(
        (tipoServicio) => tipoServicio.id == resultado.id_servicetype
      );
      const estadoServicioFilter = estadoServicio.filter(
        (estadoServicio) => estadoServicio.id == resultado.id_servicestatus
      );
      const tipoPersonaFilter = tipoPersona.filter(
        (tipoPersona) => tipoPersona.id == resultado.id_typeperson
      );

      const nuevoUsuario = {
        id: resultado.id,
        user: user,
        lastname: lastname,
        phone: phone,
        address: address,
        reference: reference,
        id_colony: id_colony,
        id_locality: id_locality,
        id_zone: id_zone,
        block: block,
        int_num: int_num,
        ext_num: ext_num,
        mail: mail,
        rfc: rfc,
        clave_elector: clave_elector,
        drenaje: drenaje,
        id_usertype: id_usertype,
        id_intaketype: id_intaketype,
        id_servicetype: id_servicetype,
        id_servicestatus: id_servicestatus,
        id_consumtype: id_consumtype,
        id_typeperson: id_typeperson,
        name_colony: coloniasFilter[0].name,
        name_locality: localidadesFilter[0].name,
        name_zone: zonesFilter[0].name,
        name_user_type: tipoUsuarioFilter[0].name,
        name_intake_type: tipoTomaFilter[0].name,
        name_service_type: tipoServicioFilter[0].name,
        name_service_status: estadoServicioFilter[0].name,
        name_consume_type: tipoConsumoFilter[0].name,
      };
      usuarios = [...usuarios, nuevoUsuario];
      mostrarUsuarios();
    }
  } catch (error) {
    console.log(error);
  }
}
