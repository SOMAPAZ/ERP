obtenerServicios();
obtenercuentas();
obtenerTipoToma();
const tablaServicios = document.querySelector("#servicios-tabla");
const crearServicio = document.querySelector("#crear-servicio");
const trVacio = document.querySelector("#nodatos");
const servicioObj = {
  id: "",
  year: "",
  nombre: "",
  id_service: "",
  id_intaketype: "",
  iva: "",
  amount: "",
};
let serviciosderechos = [];
let servicios = [];
let serviciosFilter = [];
let iva = [];
let edit = [];
let tipoToma = [];
let tipoTomaFilter = [];

crearServicio.addEventListener("click", () => {
  mostrarFormulario({});
});
async function obtenerServicios() {
  try {
    const URL = "http://localhost:8000/api/servicerights";
    const respuesta = await fetch(URL);
    const resultado = await respuesta.json();
    serviciosderechos = resultado;
    mostrarServiciosderechos();
  } catch (error) {
    console.log(error);
  }
}
async function obtenercuentas() {
  try {
    const URL = "http://localhost:8000/api/services";
    const respuesta = await fetch(URL);
    const resultado = await respuesta.json();
    servicios = resultado;
  } catch (error) {
    console.log(error);
  }
}
async function obtenerTipoToma() {
  try {
    const URL = "http://localhost:8000/api/intake_type";
    const respuesta = await fetch(URL);
    const resultado = await respuesta.json();
    tipoToma = resultado;
  } catch (error) {
    console.log(error);
  }
}
function limpiarHtml() {
  while (tablaServicios.firstChild) {
    tablaServicios.removeChild(tablaServicios.firstChild);
  }
}

function mostrarServiciosderechos() {
  limpiarHtml();
  trVacio.remove();
  serviciosderechos.forEach((servicioderecho) => {
    const {
      id,
      id_service,
      id_intaketype,
      year,
      iva,
      amount,
      servicio,
      tipo_toma,
    } = servicioderecho;
    const fila = document.createElement("TR");
    fila.className = "bg-white border-b dark:bg-gray-800 dark:border-gray-700";

    const celdaId = document.createElement("TD");
    celdaId.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaId.textContent = id;

    const celdaNombre = document.createElement("TD");
    celdaNombre.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaNombre.textContent = year;

    const celdaServicio = document.createElement("TD");
    celdaServicio.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaServicio.textContent = servicio;

    const celdaTipoToma = document.createElement("TD");
    celdaTipoToma.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaTipoToma.textContent = tipo_toma;

    const celdaIva = document.createElement("TD");
    celdaIva.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaIva.textContent = iva == 1 ? "Sí" : "No";

    const celdaMonto = document.createElement("TD");
    celdaMonto.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaMonto.textContent = Number(amount).toLocaleString("es-MX", {
      style: "currency",
      currency: "MXN",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });

    const celdaAcciones = document.createElement("TD");
    celdaAcciones.className =
      "flex justify-between px-6 py-3 whitespace-nowrap gap-3";
    const btnEditar = document.createElement("BUTTON");
    btnEditar.className =
      "bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded";
    btnEditar.textContent = "Editar";
    btnEditar.onclick = () => {
      mostrarFormulario({ ...servicioderecho }, true);
    };
    const btnEliminar = document.createElement("BUTTON");
    btnEliminar.className =
      "bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded";
    btnEliminar.textContent = "Eliminar";
    btnEliminar.onclick = () => {
      confirmDelete(servicioderecho);
    };

    celdaAcciones.appendChild(btnEditar);
    celdaAcciones.appendChild(btnEliminar);

    fila.appendChild(celdaId);
    fila.appendChild(celdaNombre);
    fila.appendChild(celdaServicio);
    fila.appendChild(celdaTipoToma);
    fila.appendChild(celdaMonto);
    fila.appendChild(celdaIva);
    fila.appendChild(celdaAcciones);
    tablaServicios.appendChild(fila);
  });
}
function mostrarFormulario(servicioderecho, editar = false) {
  const main = document.querySelector("main");
  const divBgModal = document.createElement("DIV"); //contenedor modal
  divBgModal.id = "divBgModal";

  const divModal = document.createElement("DIV"); //modal
  divModal.className =
    "overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 bottom-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%)] max-h-full dark:bg-gray-900 bg-gray-300";

  const divContent = document.createElement("DIV");
  divContent.className =
    "relative p-4 w-full max-w-2xl max-h-full mx-auto mt-5";

  const formulario = document.createElement("FORM");
  formulario.className =
    "relative bg-white rounded-lg p-4 shadow dark:bg-gray-700";
  //creacion de año
  const divAño = document.createElement("DIV");
  divAño.className = "mb-5";
  const labelAño = document.createElement("LABEL");
  labelAño.for = "year";
  labelAño.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelAño.textContent = "Año";
  const selectAño = document.createElement("SELECT");
  selectAño.id = "year";
  selectAño.name = "year";
  selectAño.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white";

  const startYear = 2007;
  const currentYear = new Date().getFullYear();
  const endYear = currentYear + 2;
  for (let year = startYear; year <= endYear; year++) {
    const option = document.createElement("OPTION");
    option.value = year;
    option.textContent = year;
    selectAño.appendChild(option);
  }
  selectAño.value = servicios.year || currentYear;
  //creacion del monto
  const divMonto = document.createElement("DIV");
  divMonto.className = "mb-5";
  const labelMonto = document.createElement("LABEL");
  labelMonto.for = "amount";
  labelMonto.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelMonto.textContent = "Monto";
  const inputMonto = document.createElement("INPUT");
  inputMonto.type = "text";
  inputMonto.id = "amount";
  inputMonto.name = "amount";
  inputMonto.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white";
  inputMonto.value = servicioderecho.amount || "";
  inputMonto.maxLength = 10;

  inputMonto.addEventListener("input", () => {
    inputMonto.value = inputMonto.value.replace(/[^0-9.]/g, "");
    const pointIndex = inputMonto.value.indexOf(".");
    if (pointIndex !== -1) {
      inputMonto.value =
        inputMonto.value.slice(0, pointIndex + 1) +
        inputMonto.value.slice(pointIndex + 1).replace(/\./g, "");
    }

    const [integer, decimal] = inputMonto.value.split(".");
    if (integer && integer.length > 10) {
      inputMonto.value = integer.slice(0, 10) + (decimal ? "." + decimal : "");
    }
    if (decimal && decimal.length > 2) {
      inputMonto.value = integer + "." + decimal.slice(0, 2);
    }
  });
  //creacion del selector servicios
  const divServiciosCuenta = document.createElement("DIV");
  divServiciosCuenta.className = "mb-5";
  const labelServiciosCuenta = document.createElement("LABEL");
  labelServiciosCuenta.for = "id_service";
  labelServiciosCuenta.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelServiciosCuenta.textContent = "SERVICIOS";
  const selectorServiciosCuenta = document.createElement("SELECT");
  selectorServiciosCuenta.name = "id_service";
  selectorServiciosCuenta.id = "id_service";
  selectorServiciosCuenta.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white ";

  servicios.forEach((servicio) => {
    const option = document.createElement("OPTION");
    option.value = servicio.id;
    option.textContent = servicio.name;
    if (servicio.id == servicioderecho.id_service) {
      option.selected = true;
    }
    selectorServiciosCuenta.appendChild(option);
  });
  //selector tipo de toma
  const divTipoToma = document.createElement("DIV");
  divTipoToma.className = "mb-5";
  const labelTipoToma = document.createElement("LABEL");
  labelTipoToma.for = "id_intaketype";
  labelTipoToma.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelTipoToma.textContent = "TIPO DE TOMA";
  const selectorTipoToma = document.createElement("SELECT");
  selectorTipoToma.name = "id_intaketype";
  selectorTipoToma.id = "id_intaketype";
  selectorTipoToma.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white ";
  tipoToma.forEach((tToma) => {
    const option = document.createElement("OPTION");
    option.value = tToma.id;
    option.textContent = tToma.name;
    if (tToma.id == servicioderecho.id_intaketype) {
      option.selected = true;
    }
    selectorTipoToma.appendChild(option);
  });

  //creacion del selector de iva
  const divIva = document.createElement("DIV");
  divIva.className = "mb-5";
  const labelIva = document.createElement("LABEL");
  labelIva.for = "iva";
  labelIva.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelIva.textContent = "IVA";
  const selectorIva = document.createElement("SELECT");
  selectorIva.name = "iva";
  selectorIva.id = "iva";
  selectorIva.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white ";
  const options = [
    { value: 1, text: "Sí" },
    { value: 0, text: "No" },
  ];
  options.forEach((option) => {
    const optionEl = document.createElement("OPTION");
    optionEl.value = option.value;
    optionEl.textContent = option.text;
    if (option.value == servicioderecho.iva) {
      optionEl.setAttribute("selected", true);
    }
    selectorIva.appendChild(optionEl);
  });

  divAño.appendChild(labelAño);
  divAño.appendChild(selectAño);
  divMonto.appendChild(labelMonto);
  divMonto.appendChild(inputMonto);
  divServiciosCuenta.appendChild(labelServiciosCuenta);
  divServiciosCuenta.appendChild(selectorServiciosCuenta);
  divIva.appendChild(labelIva);
  divIva.appendChild(selectorIva);
  divTipoToma.appendChild(labelTipoToma);
  divTipoToma.appendChild(selectorTipoToma);
  divIva.appendChild(labelIva);
  divIva.appendChild(selectorIva);

  //creacion de los botones
  const btnGuardar = document.createElement("INPUT");
  btnGuardar.className =
    "w-full mb-2 text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800";
  btnGuardar.value = "Guardar";
  btnGuardar.type = "submit";
  btnGuardar.onclick = (e) => {
    e.preventDefault();
    if (editar) {
      enviarFormulario({ ...servicioderecho });
    } else {
      guardarServicioderecho();
    }
  };
  formulario.appendChild(divAño);
  formulario.appendChild(divMonto);
  formulario.appendChild(divServiciosCuenta);
  formulario.appendChild(divIva);
  formulario.appendChild(divTipoToma);
  formulario.appendChild(btnGuardar);

  const botonesDiv = document.createElement("DIV");
  botonesDiv.className =
    "flex justify-end p-4 md:p-5 border-t border-gray-200 rounded-b dark:border-gray-600";

  const btnCancelar = document.createElement("BUTTON");
  btnCancelar.className =
    "py-2.5 px-5  text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700";
  btnCancelar.textContent = "Cancelar";
  btnCancelar.onclick = () => {
    divBgModal.remove();
  };
  botonesDiv.appendChild(btnCancelar);
  formulario.appendChild(botonesDiv);

  divContent.appendChild(formulario);
  divModal.appendChild(divContent);
  divBgModal.appendChild(divModal);
  main.appendChild(divBgModal);
}
async function enviarFormulario(servicioderecho) {
  const id = servicioderecho.id;
  const id_service = document.querySelector("#id_service").value.trim();
  const year = document.querySelector("#year").value.trim();
  const amount = document.querySelector("#amount").value.trim();
  const iva = document.querySelector("#iva").value.trim();
  const id_intaketype = document.querySelector("#id_intaketype").value.trim();
  const servicioObj = {
    id: id,
    id_service: id_service,
    year: year,
    amount: amount,
    iva: iva,
    id_intaketype: id_intaketype,
  };
  if (Object.values(servicioObj).some((v) => v === "")) {
    Swal.fire({
      icon: "error",
      title: "Campo vacío",
      text: "El campo no puede estar vacío.",
    });
    return;
  }

  const data = new FormData();
  data.append("id", id);
  data.append("id_service", id_service);
  data.append("year", year);
  data.append("amount", amount);
  data.append("iva", iva);
  data.append("id_intaketype", id_intaketype);
  try {
    const URL = `http://localhost:8000/update-serviceRights/${id}`;
    const respuesta = await fetch(URL, {
      method: "POST",
      body: data,
    });
    const resultado = await respuesta.json();

    if (resultado.resultado === "Exito") {
      Swal.fire({
        icon: "success",
        title: resultado.resultado,
        text: "Actualización exitosa",
      });
      document.querySelector("#divBgModal").remove();
      serviciosFilter = servicios.filter(
        (servicio) => servicio.id == resultado.id_service
      );
      tipoTomaFilter = tipoToma.filter(
        (tToma) => tToma.id == resultado.id_intaketype
      );
      serviciosderechos = serviciosderechos.map((serviciosMem) => {
        if (serviciosMem.id === id) {
          serviciosMem.id_service = resultado.id_service;
          serviciosMem.year = resultado.year;
          serviciosMem.amount = resultado.amount;
          serviciosMem.iva = resultado.iva;
          serviciosMem.id_intaketype = resultado.id_intaketype;
          serviciosMem.servicio = serviciosFilter[0].name;
          serviciosMem.tipo_toma = tipoTomaFilter[0].name;
        }
        return serviciosMem;
      });
      mostrarServiciosderechos();
    }
  } catch (error) {
    console.log(error);
  }
}
async function confirmDelete(servicioderecho) {
  Swal.fire({
    title: "¿Estás seguro?",
    text: "Esta acción no se puede deshacer",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Sí, eliminar",
    cancelButtonText: "Cancelar",
  }).then((result) => {
    if (result.isConfirmed) {
      eliminarServicio(servicioderecho);
    }
  });
}
async function eliminarServicio(servicioderecho) {
  const data = new FormData();
  data.append("id", servicioderecho.id);
  try {
    const URL = `http://localhost:8000/delete-serviceRights/${servicioderecho.id}`;
    const respuesta = await fetch(URL, {
      method: "POST",
      body: data,
    });
    const resultado = await respuesta.json();
    if (resultado.resultado === "Exito") {
      Swal.fire({
        icon: "success",
        title: resultado.resultado,
        text: "Eliminación exitosa",
      });
      serviciosderechos = serviciosderechos.filter(
        (servicioMem) => servicioMem.id !== servicioderecho.id
      );
      mostrarServiciosderechos();
    }
  } catch (error) {
    console.log(error);
  }
}
async function guardarServicioderecho() {
  const id_service = document.querySelector("#id_service").value.trim();
  const year = document.querySelector("#year").value.trim();
  const amount = document.querySelector("#amount").value.trim();
  const iva = document.querySelector("#iva").value.trim();
  const id_intaketype = document.querySelector("#id_intaketype").value.trim();
  const servicioObj = {
    id_service: id_service,
    year: year,
    amount: amount,
    iva: iva,
    id_intaketype: id_intaketype,
  };
  if (Object.values(servicioObj).some((v) => v === "")) {
    Swal.fire({
      icon: "error",
      title: "Campo vacío",
      text: "El campo no puede estar vacío.",
    });
    return;
  }
  const data = new FormData();
  data.append("id_service", id_service);
  data.append("year", year);
  data.append("amount", amount);
  data.append("iva", iva);
  data.append("id_intaketype", id_intaketype);
  try {
    const URL = `http://localhost:8000/create-serviceRights`;
    const respuesta = await fetch(URL, {
      method: "POST",
      body: data,
    });
    const resultado = await respuesta.json();
    if (resultado.resultado === "Exito") {
      Swal.fire({
        icon: "success",
        title: resultado.resultado,
        text: "Creación exitosa",
      });
      document.querySelector("#divBgModal").remove();
      const serviciosFilter = servicios.filter(
        (servicio) => servicio.id == resultado.id_service
      );
      const tipoTomaFilter = tipoToma.filter(
        (tToma) => tToma.id == resultado.id_intaketype
      );
      const nuevoServicio = {
        id: resultado.id,
        id_service: id_service,
        year: year,
        amount: amount,
        iva: parseInt(iva),
        id_intaketype: id_intaketype,
        servicio: serviciosFilter[0].name,
        tipo_toma: tipoTomaFilter[0].name,
      };
      serviciosderechos = [...serviciosderechos, nuevoServicio];
      mostrarServiciosderechos();
    }
  } catch (error) {
    console.log(error);
  }
}
