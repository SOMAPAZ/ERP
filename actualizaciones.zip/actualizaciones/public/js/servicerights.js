async function obtenerServicios() {
  try {
    const URL = "http://localhost:8000/api/servicerights";
    const response = await fetch(URL);
    const serviceRights = await response.json();
    console.log(serviceRights);
  } catch (error) {
    console.log(error);
  }
}
