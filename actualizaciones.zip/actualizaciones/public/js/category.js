async function obtenerCategorias() {
  try {
    const URL = "http://localhost:8000/api/categories";
    const response = await fetch(URL);

    if (!response.ok) {
      throw new Error("Error en la respuesta: " + response.status);
    }

    const categories = await response.json();

    // Obtener el elemento contenedor
    const contenedor = document.getElementById("categoria-tabla");

    // Crear la tabla
    const table = document.createElement("table");
    table.classList.add("table");
    const thead = table.createTHead();
    const headerRow = thead.insertRow();
    const headers = ["ID", "Nombre", "Acciones"];
    headers.forEach((headerText) => {
      const th = document.createElement("th");
      th.textContent = headerText;
      headerRow.appendChild(th);
    });

    const tbody = table.createTBody();
    categories.forEach((category) => {
      const row = tbody.insertRow();
      const idCell = row.insertCell();
      idCell.textContent = category.id;
      const nameCell = row.insertCell();
      nameCell.textContent = category.name;
      const actionsCell = row.insertCell();

      // Crear enlaces para editar y eliminar
      const editLink = document.createElement("a");
      editLink.href = `/update-category/${category.id}`;
      editLink.textContent = "Editar";
      editLink.classList.add("btn", "btn-warning");
      actionsCell.appendChild(editLink);

      const deleteLink = document.createElement("a");
      deleteLink.href = `/delete-category/${category.id}`;
      deleteLink.textContent = "Eliminar";
      deleteLink.classList.add("btn", "btn-danger");
      deleteLink.addEventListener("click", () => {
        if (confirm("¿Estás seguro de que deseas eliminar esta categoría?")) {
          fetch(`/api/categories/${category.id}`, {
            method: "DELETE",
            headers: {
              "Content-Type": "application/json",
            },
          })
            .then(() => {
              obtenerCategorias();
            })
            .catch((error) => {
              console.error("Error al eliminar la categoría:", error);
              const errorMessage = document.createElement("p");
              errorMessage.textContent =
                "Ocurrió un error al eliminar la categoría.";
              contenedor.appendChild(errorMessage);
            });
        }
      });
      actionsCell.appendChild(deleteLink);
    });

    contenedor.appendChild(table);
  } catch (error) {
    console.error("Error al obtener las categorías:", error);
    const errorMessage = document.createElement("p");
    errorMessage.textContent = "Ocurrió un error al cargar las categorías.";
    contenedor.appendChild(errorMessage);
  }
}

obtenerCategorias();
