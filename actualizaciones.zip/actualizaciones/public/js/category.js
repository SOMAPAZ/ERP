async function obtenerCategorias() {
  try {
    const URL = "http://localhost:8000/api/categories";
    const response = await fetch(URL);

    // Si la respuesta no es 2xx (éxito), lanzamos un error
    if (!response.ok) {
      throw new Error("Error en la respuesta: " + response.status);
    }

    const categories = await response.json();
    console.log(categories);
  } catch (error) {
    console.log("Error al obtener las categorías:", error);
  }
}
