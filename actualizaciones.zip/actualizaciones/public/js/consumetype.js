document.addEventListener("DOMContentLoaded", () => {
  obtenerConsumeTypes();
});

async function obtenerConsumeTypes() {
  try {
    const URL = "http://localhost:8000/api/consumetypes";
    const response = await fetch(URL);
    const consumeTypes = await response.json();
    console.log(consumeTypes);
  } catch (error) {
    console.log(error);
  }
}
