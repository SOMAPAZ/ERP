document.addEventListener("DOMContentLoaded", () => {
  obtenerFormatos();
});

async function obtenerFormatos() {
  try {
    const URL = "http://localhost:8000/api/format";
    const response = await fetch(URL);
    if (!response.ok) {
      throw new Error("Error en la respuesta: " + response.status);
    }
    const formats = await response.json();
    console.log(formats);
  } catch (error) {
    console.log(error);
  }
}
