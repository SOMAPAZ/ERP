async function obtenerStorages() {
  try {
    const URL = "http://localhost:8000/api/userstorage";
    const response = await fetch(URL);
    const storages = await response.json();
    console.log(storages);
  } catch (error) {
    console.log(error);
  }
}
