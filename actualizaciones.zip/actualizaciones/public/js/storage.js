obtenerStorage();
const tablaStorage = document.querySelector("#storage-tabla");
const crearStorage = document.querySelector("#crear-storage");
const trVacio = document.querySelector("#nodatos");

const storageObj = {
  id: "",
  name: "",
};
let storages = [];

async function obtenerStorage() {
  try {
    const URL = "http://localhost:8000/api/userstorage";
    const respuesta = await fetch(URL);
    const resultado = await respuesta.json();
    storages = resultado;
    mostrarStorage();
    console.log(storages);
  } catch (error) {
    console.log(error);
  }
}
crearStorage.addEventListener("click", () => {
  mostrarFormulario({});
});
//funciones declarativas del sistema
function limpiarHtml() {
  while (tablaStorage.firstChild) {
    tablaStorage.removeChild(tablaStorage.firstChild);
  }
}
function mostrarStorage() {
  limpiarHtml();
  trVacio.remove();
  storages.forEach((storage) => {
    const { id, name } = storage;
    const fila = document.createElement("TR");
    fila.className = "bg-white border-b dark:bg-gray-800 dark:border-gray-700";

    const celdaId = document.createElement("TD");
    celdaId.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaId.textContent = id;

    const celdaNombre = document.createElement("TD");
    celdaNombre.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaNombre.textContent = name;

    const celdaAcciones = document.createElement("TD");
    celdaAcciones.className = "flex px-3 py-3 gap-3";
    const btnEditar = document.createElement("BUTTON");
    btnEditar.className =
      "bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded";
    btnEditar.textContent = "Editar";
    btnEditar.onclick = () => {
      mostrarFormulario(storage, true);
    };
    const btnEliminar = document.createElement("BUTTON");
    btnEliminar.className =
      "bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded";
    btnEliminar.textContent = "Eliminar";
    btnEliminar.onclick = () => {
      confirmaDelete(storage);
    };

    celdaAcciones.appendChild(btnEditar);
    celdaAcciones.appendChild(btnEliminar);

    fila.appendChild(celdaId);
    fila.appendChild(celdaNombre);
    fila.appendChild(celdaAcciones);
    tablaStorage.appendChild(fila);
  });
}
//mostrar datos
function mostrarFormulario(storage, editar = false) {
  const main = document.querySelector("main");
  const divBgModal = document.createElement("DIV");
  divBgModal.id = "divBgModal";

  const divModal = document.createElement("DIV");
  divModal.className =
    "overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 bottom-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%)] max-h-full dark:bg-gray-900 bg-gray-300";
  const divContent = document.createElement("DIV");
  divContent.className =
    "relative p-4 w-full max-w-2xl max-h-full mx-auto mt-5";
  const formulario = document.createElement("FORM");
  formulario.className =
    "relative bg-white rounded-lg p-4 shadow dark:bg-gray-700";

  const divNombre = document.createElement("DIV");
  divNombre.className = "mb-5";
  const labelNombre = document.createElement("LABEL");
  labelNombre.for = "name";
  labelNombre.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelNombre.textContent = "Nombre";
  const inputNombre = document.createElement("INPUT");
  inputNombre.type = "text";
  inputNombre.id = "name";
  inputNombre.name = "name";
  inputNombre.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white";
  inputNombre.value = storage.name || "";
  inputNombre.maxLength = 20;
  inputNombre.addEventListener("input", () => {
    inputNombre.value = inputNombre.value.replace(/[^a-zA-ZáéíóúÁÉÍÓÚ\s]/g, "");
    if (inputNombre.value.length > 20) {
      inputNombre.value = inputNombre.value.slice(0, 20);
    }
  });
  divNombre.appendChild(labelNombre);
  divNombre.appendChild(inputNombre);

  const btnGuardar = document.createElement("INPUT");
  btnGuardar.className =
    "w-full mb-2 text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800";
  btnGuardar.value = "Guardar";
  btnGuardar.type = "submit";
  btnGuardar.onclick = (e) => {
    e.preventDefault();
    if (editar) {
      enviarFormulario({ ...storage });
    } else {
      guardarStorage();
    }
  };

  formulario.appendChild(divNombre);
  formulario.appendChild(btnGuardar);

  const botonesDiv = document.createElement("DIV");
  botonesDiv.className =
    "flex justify-end p-4 md:p-5 border-t border-gray-200 rounded-b dark:border-gray-600";

  const btnCancelar = document.createElement("BUTTON");
  btnCancelar.className =
    "py-2.5 px-5  text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700";
  btnCancelar.textContent = "Cancelar";
  btnCancelar.onclick = () => {
    divBgModal.remove();
  };
  botonesDiv.appendChild(btnCancelar);
  formulario.appendChild(botonesDiv);

  divContent.appendChild(formulario);
  divModal.appendChild(divContent);
  divBgModal.appendChild(divModal);
  main.appendChild(divBgModal);
}
//actualizar storage
async function enviarFormulario(storage) {
  const id = storage.id;
  const name = document.querySelector("#name").value.trim();
  const storageObj = {
    id: id,
    name: name,
  };
  if (Object.values(storageObj).some((v) => v === "")) {
    Swal.fire({
      icon: "error",
      title: "Campo vacío",
      text: "El campo no puede estar vacío.",
    });
    return;
  }
  const existe = storages.some(
    (storage) => storage.name.toLowerCase() === name.toLowerCase()
  );
  if (existe) {
    Swal.fire({
      icon: "error",
      title: "Nombre ya existe",
      text: "El nombre ya existe",
    });
    return;
  }
  const data = new FormData();
  data.append("id", id);
  data.append("name", name);
  try {
    const URL = `http://localhost:8000/update-userStorage/${id}`;
    const respuesta = await fetch(URL, {
      method: "POST",
      body: data,
    });
    if (Object.values(storageObj).some((v) => v === "")) {
      Swal.fire({
        icon: "error",
        title: "Campo vacío",
        text: "El campo no puede estar vacío.",
      });
      return;
    }

    const resultado = await respuesta.json();
    if (resultado.resultado === "Exito") {
      Swal.fire({
        icon: "success",
        title: resultado.resultado,
        text: "Actualización exitosa",
      });
      document.querySelector("#divBgModal").remove();
      storages = storages.map((storageMem) => {
        if (storageMem.id === id) {
          storageMem.name = resultado.name;
        }
        return storageMem;
      });
      mostrarStorage();
    }
  } catch (error) {
    console.log(error);
  }
}

//eliminar storage
async function confirmaDelete(storage) {
  Swal.fire({
    title: "¿Estás seguro?",
    text: "Esta acción no se puede deshacer",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Sí, eliminar",
    cancelButtonText: "Cancelar",
  }).then((result) => {
    if (result.isConfirmed) {
      eliminarStorage(storage);
    }
  });
}
async function eliminarStorage(storage) {
  const data = new FormData();
  data.append("id", storage.id);
  try {
    const URL = `http://localhost:8000/delete-userStorage/${storage.id}`;
    const respuesta = await fetch(URL, {
      method: "POST",
      body: data,
    });
    const resultado = await respuesta.json();
    // Verifica el contenido de la respuesta
    if (resultado.resultado === "Exito") {
      Swal.fire({
        icon: "success",
        title: resultado.resultado,
        text: "Eliminación exitosa",
      });
      storages = storages.filter((storageMem) => storageMem.id !== storage.id);
      mostrarStorage();
    }
  } catch (error) {
    console.error("No se puede Eliminar el Tipo de Almacenamiento de Usuario");
    Swal.fire({
      icon: "error",
      title: "Error",
      text: "No se pudo completar la operación. Por favor, contacte con el administrador.",
    });
  }
}
//crear storage
async function guardarStorage() {
  const name = document.querySelector("#name").value.trim();
  const storageObj = {
    name: name,
  };
  if (Object.values(storageObj).some((v) => v === "")) {
    Swal.fire({
      icon: "error",
      title: "Campo vacío",
      text: "El campo no puede estar vacío.",
    });
    return;
  }
  const existe = storages.some(
    (storage) => storage.name.toLowerCase() === name.toLowerCase()
  );
  if (existe) {
    Swal.fire({
      icon: "error",
      title: "Nombre ya existe",
      text: "El nombre ya existe",
    });
    return;
  }
  const data = new FormData();
  data.append("name", name);
  try {
    const URL = `http://localhost:8000/create-userStorage`;
    const respuesta = await fetch(URL, {
      method: "POST",
      body: data,
    });
    const resultado = await respuesta.json();
    if (resultado.resultado === "Exito") {
      Swal.fire({
        icon: "success",
        title: resultado.resultado,
        text: "Creación exitosa",
      });
      document.querySelector("#divBgModal").remove();

      const nuevoStorage = {
        id: resultado.id,
        name: name,
      };
      storages = [...storages, nuevoStorage];
      mostrarStorage();
    }
  } catch (error) {
    console.log(error);
  }
}
