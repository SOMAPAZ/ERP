document.addEventListener("DOMContentLoaded", () => {
  obtenerTarifas();
});

async function obtenerTarifas() {
  try {
    const URL = "http://localhost:8000/api/measured";
    const response = await fetch(URL);
    const measured = await response.json();
    console.log(measured);
  } catch (error) {
    console.log(error);
  }
}
