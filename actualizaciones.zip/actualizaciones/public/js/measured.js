obtenerServicioMedido();
obtenerTipoToma();
obtenerTipoConsumo();
const tablaMedidas = document.querySelector("#medidas-tabla");
const crearMedida = document.querySelector("#crear-medida");
const trVacio = document.querySelector("#nodatos");
const controlesPaginacion = document.querySelector("#controles-paginacion");
const medidaObj = {
  id: "",
  year: "",
  nombre: "",
  id_intaketype: "",
  id_consumtype: "",
  amount: "",
  iva: "",
  liminf: "",
  limsup: "",
  excm3: "",
  iva_exc: "",
};
//paginacion
let paginaActual = 1;
let fijoPorPagina = 8;
let medido = [];
let iva = [];
let tipotoma = [];
let tipotomaFilter = [];
let tipoconsumo = [];
let tipoconsumoFilter = [];

document.addEventListener("DOMContentLoaded", () => {
  inicializarPagina();
});
crearMedida.addEventListener("click", () => {
  mostrarFormulario({});
});
//funciones para paginacion
function inicializarPagina() {
  const urlParams = new URLSearchParams(window.location.search);
  const pagina = parseInt(urlParams.get("pagina")) || 1;
  paginaActual = pagina;
  obtenerServicioMedido();
}
function cambiarPagina(nuevaPagina) {
  paginaActual = nuevaPagina;

  const urlParams = new URLSearchParams(window.location.search);
  urlParams.set("pagina", nuevaPagina);
  window.history.pushState({}, "", `${window.location.pathname}?${urlParams}`);

  mostrarserviciomedido();
  crearControlesPaginacion();
}
function crearControlesPaginacion() {
  controlesPaginacion.innerHTML = "";
  const totalPaginas = Math.ceil(serviciomedido.length / fijoPorPagina);
  const rango = 2;
  if (totalPaginas < 1) return;

  controlesPaginacion.appendChild(crearBotonPagina(1));

  if (paginaActual - rango > 2) {
    const puntosInicio = document.createElement("SPAN");
    puntosInicio.textContent = "...";
    puntosInicio.className = "px-2 text-gray-500 justify-center";
    controlesPaginacion.appendChild(puntosInicio);
  }

  for (
    let i = Math.max(2, paginaActual - rango);
    i <= Math.min(totalPaginas - 1, paginaActual + rango);
    i++
  ) {
    controlesPaginacion.appendChild(crearBotonPagina(i));
  }

  if (paginaActual + rango < totalPaginas - 1) {
    const puntosFin = document.createElement("SPAN");
    puntosFin.textContent = "...";
    puntosFin.className = "px-2 text-gray-500";
    controlesPaginacion.appendChild(puntosFin);
  }

  if (totalPaginas > 1) {
    controlesPaginacion.appendChild(crearBotonPagina(totalPaginas));
  }
}

function crearBotonPagina(numeroPagina) {
  const botonPagina = document.createElement("BUTTON");
  botonPagina.textContent = numeroPagina;
  botonPagina.className = `px-4 py-2 ${
    numeroPagina === paginaActual
      ? "bg-blue-500 text-white"
      : "bg-gray-200 text-black"
  }`;
  botonPagina.onclick = () => cambiarPagina(numeroPagina);
  return botonPagina;
}
async function obtenerServicioMedido() {
  try {
    const URL = "http://localhost:8000/api/measured";
    const respuesta = await fetch(URL);
    const resultado = await respuesta.json();
    serviciomedido = resultado;
    mostrarserviciomedido();
    crearControlesPaginacion();
  } catch (error) {
    console.log(error);
  }
}
async function obtenerTipoToma() {
  try {
    const URL = "http://localhost:8000/api/intake_type";
    const respuesta = await fetch(URL);
    const resultado = await respuesta.json();
    tipotoma = resultado;
  } catch (error) {
    console.log(error);
  }
}
async function obtenerTipoConsumo() {
  try {
    const URL = "http://localhost:8000/api/consumetypes";
    const respuesta = await fetch(URL);
    const resultado = await respuesta.json();
    tipoconsumo = resultado;
  } catch (error) {
    console.log(error);
  }
}

function limpiarHtml() {
  while (tablaMedidas.firstChild) {
    tablaMedidas.removeChild(tablaMedidas.firstChild);
  }
}
function mostrarserviciomedido() {
  const inicio = (paginaActual - 1) * fijoPorPagina;
  const fin = inicio + fijoPorPagina;
  let serviciomedidoPagina = serviciomedido.slice(inicio, fin);
  limpiarHtml();
  trVacio.remove();
  serviciomedidoPagina.forEach((medido) => {
    const {
      id,
      id_intaketype,
      id_consumtype,
      year,
      amount,
      iva,
      liminf,
      limsup,
      excm3,
      iva_exc,
      tipo_toma,
      tipo_consumo,
    } = medido;

    const fila = document.createElement("TR");
    fila.className = "bg-white border-b dark:bg-gray-800 dark:border-gray-700";

    const celdaId = document.createElement("TD");
    celdaId.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaId.textContent = id;

    const celdatipotoma = document.createElement("TD");
    celdatipotoma.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdatipotoma.textContent = tipo_toma;

    const celdaconsume = document.createElement("TD");
    celdaconsume.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaconsume.textContent = tipo_consumo;

    const celdayear = document.createElement("TD");
    celdayear.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdayear.textContent = year;
    const celdaamount = document.createElement("TD");
    celdaamount.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaamount.textContent = Number(amount).toLocaleString("es-MX", {
      style: "currency",
      currency: "MXN", // Moneda en pesos mexicanos
      minimumFractionDigits: 2, // Mostrar siempre dos decimales
      maximumFractionDigits: 2, // Mostrar hasta dos decimales
    });

    const celdaiva = document.createElement("TD");
    celdaiva.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaiva.textContent = iva == 1 ? "Sí" : "No";

    const celdaliminf = document.createElement("TD");
    celdaliminf.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaliminf.textContent = liminf;

    const celdalimsup = document.createElement("TD");
    celdalimsup.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdalimsup.textContent = limsup;

    const celdaexcm3 = document.createElement("TD");
    celdaexcm3.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaexcm3.textContent = Number(excm3).toLocaleString("es-MX", {
      style: "currency",
      currency: "MXN", // Moneda en pesos mexicanos
      minimumFractionDigits: 2, // Mostrar siempre dos decimales
      maximumFractionDigits: 2, // Mostrar hasta dos decimales
    });

    const celdaivaexc = document.createElement("TD");
    celdaivaexc.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaivaexc.textContent = iva_exc == 1 ? "Sí" : "No";

    const celdaAcciones = document.createElement("TD");
    celdaAcciones.className =
      "flex justify-between px-6 py-3 whitespace-nowrap gap-3";
    const btnEditar = document.createElement("BUTTON");
    btnEditar.className =
      "bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded";
    btnEditar.textContent = "Editar";
    btnEditar.onclick = () => {
      mostrarFormulario(medido, true);
    };
    const btnEliminar = document.createElement("BUTTON");
    btnEliminar.className =
      "bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded";
    btnEliminar.textContent = "Eliminar";
    btnEliminar.onclick = () => {
      confirmDelete(medido);
    };
    celdaAcciones.appendChild(btnEditar);
    celdaAcciones.appendChild(btnEliminar);
    fila.appendChild(celdaId);
    fila.appendChild(celdayear);
    fila.appendChild(celdatipotoma);
    fila.appendChild(celdaconsume);

    fila.appendChild(celdaamount);
    fila.appendChild(celdaiva);
    fila.appendChild(celdaliminf);
    fila.appendChild(celdalimsup);
    fila.appendChild(celdaexcm3);
    fila.appendChild(celdaivaexc);
    fila.appendChild(celdaAcciones);
    tablaMedidas.appendChild(fila);
  });
}
function mostrarFormulario(medido, editar = false) {
  const main = document.querySelector("main");
  const divBgModal = document.createElement("DIV"); //contenedor modal
  divBgModal.id = "divBgModal";

  const divModal = document.createElement("DIV"); //modal
  divModal.className =
    "overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 bottom-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%)] max-h-full dark:bg-gray-900 bg-gray-300";

  const divContent = document.createElement("DIV");
  divContent.className =
    "relative p-4 w-full max-w-2xl max-h-full mx-auto mt-5";

  const formulario = document.createElement("FORM");
  formulario.className =
    "relative bg-white rounded-lg p-4 shadow dark:bg-gray-700";

  const divAño = document.createElement("DIV");
  divAño.className = "mb-5";
  const labelAño = document.createElement("LABEL");
  labelAño.for = "year";
  labelAño.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelAño.textContent = "Año";
  const selectAño = document.createElement("SELECT");
  selectAño.id = "year";
  selectAño.name = "year";
  selectAño.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white";

  const startYear = 2007;
  const currentYear = new Date().getFullYear();
  const endYear = currentYear + 2;
  for (let year = startYear; year <= endYear; year++) {
    const option = document.createElement("OPTION");
    option.value = year;
    option.textContent = year;
    selectAño.appendChild(option);
  }
  selectAño.value = medido.year || currentYear;

  const divTipotoma = document.createElement("DIV");
  divTipotoma.className = "mb-5";
  const labelTipotoma = document.createElement("LABEL");
  labelTipotoma.for = "id_intaketype";
  labelTipotoma.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelTipotoma.textContent = "TIPO DE TOMA";
  const selectorTipotoma = document.createElement("SELECT");
  selectorTipotoma.name = "id_intaketype";
  selectorTipotoma.id = "id_intaketype";
  selectorTipotoma.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white ";
  tipotoma.forEach((tToma) => {
    const option = document.createElement("OPTION");
    option.value = tToma.id;
    option.textContent = tToma.name;
    if (tToma.id == medido.id_intaketype) {
      option.selected = true;
    }
    selectorTipotoma.appendChild(option);
  });

  const divTipoconsumo = document.createElement("DIV");
  divTipoconsumo.className = "mb-5";
  const labelTipoconsumo = document.createElement("LABEL");
  labelTipoconsumo.for = "id_consumtype";
  labelTipoconsumo.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelTipoconsumo.textContent = "TIPO DE CONSUMO";
  const selectorTipoconsumo = document.createElement("SELECT");
  selectorTipoconsumo.name = "id_consumtype";
  selectorTipoconsumo.id = "id_consumtype";
  selectorTipoconsumo.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white ";
  tipoconsumo
    .filter(
      (tConsumo) =>
        tConsumo.name !== "Menor Consumo Fijo" &&
        tConsumo.name !== "Mayor Consumo Fijo"
    )
    .forEach((tConsumo) => {
      const option = document.createElement("OPTION");
      option.value = tConsumo.id;
      option.textContent = tConsumo.name;
      if (tConsumo.id == medido.id_consumtype) {
        option.selected = true;
      }
      selectorTipoconsumo.appendChild(option);
    });

  const divamount = document.createElement("DIV");
  divamount.className = "mb-5";
  const labelamount = document.createElement("LABEL");
  labelamount.for = "amount";
  labelamount.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelamount.textContent = "MONTO";
  const inputamount = document.createElement("INPUT");
  inputamount.type = "text";
  inputamount.id = "amount";
  inputamount.name = "amount";
  inputamount.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white";
  inputamount.value = medido.amount || "";
  inputamount.maxLength = 10;

  inputamount.addEventListener("input", () => {
    inputamount.value = inputamount.value.replace(/[^0-9.]/g, "");
    const pointIndex = inputamount.value.indexOf(".");
    if (pointIndex !== -1) {
      inputamount.value =
        inputamount.value.slice(0, pointIndex + 1) +
        inputamount.value.slice(pointIndex + 1).replace(/\./g, "");
    }

    const [integer, decimal] = inputamount.value.split(".");
    if (integer && integer.length > 10) {
      inputamount.value = integer.slice(0, 10) + (decimal ? "." + decimal : ""); // Limitar a 10 dígitos en la parte entera
    }
    if (decimal && decimal.length > 2) {
      inputamount.value = integer + "." + decimal.slice(0, 2);
    }
  });
  //creacion del selector de iva
  const divIva = document.createElement("DIV");
  divIva.className = "mb-5";
  const labelIva = document.createElement("LABEL");
  labelIva.for = "iva";
  labelIva.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelIva.textContent = "IVA";
  const selectorIva = document.createElement("SELECT");
  selectorIva.name = "iva";
  selectorIva.id = "iva";
  selectorIva.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white ";

  const options = [
    { value: 1, text: "Sí" },
    { value: 0, text: "No" },
  ];
  options.forEach((option) => {
    const optionEl = document.createElement("OPTION");
    optionEl.value = option.value;
    optionEl.textContent = option.text;
    if (option.value == medido.iva) {
      optionEl.setAttribute("selected", true);
    }
    selectorIva.appendChild(optionEl);
  });
  //creacion del limite inferior del servicio medido
  const divlimitinf = document.createElement("DIV");
  divlimitinf.className = "mb-5";
  const labellimitinf = document.createElement("LABEL");
  labellimitinf.for = "liminf";
  labellimitinf.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labellimitinf.textContent = "LIM INF";
  const inputlimitinf = document.createElement("INPUT");
  inputlimitinf.type = "text";
  inputlimitinf.id = "liminf";
  inputlimitinf.name = "liminf";
  inputlimitinf.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white";
  inputlimitinf.value = medido.liminf || "";
  inputlimitinf.maxLength = 10;

  inputlimitinf.addEventListener("input", () => {
    inputlimitinf.value = inputlimitinf.value.replace(/[^0-9.]/g, "");
    const pointIndex = inputlimitinf.value.indexOf(".");
    if (pointIndex !== -1) {
      inputlimitinf.value =
        inputlimitinf.value.slice(0, pointIndex + 1) +
        inputlimitinf.value.slice(pointIndex + 1).replace(/\./g, "");
    }

    const [integer, decimal] = inputlimitinf.value.split(".");
    if (integer && integer.length > 10) {
      inputlimitinf.value =
        integer.slice(0, 10) + (decimal ? "." + decimal : ""); // Limitar a 10 dígitos en la parte entera
    }
    if (decimal && decimal.length > 2) {
      inputlimitinf.value = integer + "." + decimal.slice(0, 2);
    }
  });
  //creacion del limite superior del servicio medido
  const divlimsup = document.createElement("DIV");
  divlimsup.className = "mb-5";
  const labellimsup = document.createElement("LABEL");
  labellimsup.for = "limsup";
  labellimsup.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labellimsup.textContent = "LIM SUP";
  const inputlimsup = document.createElement("INPUT");
  inputlimsup.type = "text";
  inputlimsup.id = "limsup";
  inputlimsup.name = "limsup";
  inputlimsup.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white";
  inputlimsup.value = medido.limsup || "";
  inputlimsup.maxLength = 10;

  inputlimsup.addEventListener("input", () => {
    inputlimsup.value = inputlimsup.value.replace(/[^0-9.]/g, "");
    const pointIndex = inputlimsup.value.indexOf(".");
    if (pointIndex !== -1) {
      inputlimsup.value =
        inputlimsup.value.slice(0, pointIndex + 1) +
        inputlimsup.value.slice(pointIndex + 1).replace(/\./g, "");
    }

    const [integer, decimal] = inputlimsup.value.split(".");
    if (integer && integer.length > 10) {
      inputlimsup.value = integer.slice(0, 10) + (decimal ? "." + decimal : ""); // Limitar a 10 dígitos en la parte entera
    }
    if (decimal && decimal.length > 2) {
      inputlimsup.value = integer + "." + decimal.slice(0, 2);
    }
  });
  //creacion del exc m3
  const divexcm3 = document.createElement("DIV");
  divexcm3.className = "mb-5";
  const labelexcm3 = document.createElement("LABEL");
  labelexcm3.for = "excm3";
  labelexcm3.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelexcm3.textContent = "EXC M3";
  const inputexcm3 = document.createElement("INPUT");
  inputexcm3.type = "text";
  inputexcm3.id = "excm3";
  inputexcm3.name = "excm3";
  inputexcm3.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white";
  inputexcm3.value = medido.excm3 || "";
  inputexcm3.maxLength = 10;

  inputexcm3.addEventListener("input", () => {
    inputexcm3.value = inputexcm3.value.replace(/[^0-9.]/g, "");
    const pointIndex = inputexcm3.value.indexOf(".");
    if (pointIndex !== -1) {
      inputexcm3.value =
        inputexcm3.value.slice(0, pointIndex + 1) +
        inputexcm3.value.slice(pointIndex + 1).replace(/\./g, "");
    }

    const [integer, decimal] = inputexcm3.value.split(".");
    if (integer && integer.length > 10) {
      inputexcm3.value = integer.slice(0, 10) + (decimal ? "." + decimal : ""); // Limitar a 10 dígitos en la parte entera
    }
    if (decimal && decimal.length > 2) {
      inputexcm3.value = integer + "." + decimal.slice(0, 2);
    }
  });
  //creacion del iva exc
  const divexac = document.createElement("DIV");
  divexac.className = "mb-5";
  const labelexac = document.createElement("LABEL");
  labelexac.for = "excm3";
  labelexac.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelexac.textContent = "IVA EXC";
  const selectorivaexc = document.createElement("SELECT");
  selectorivaexc.name = "iva_exc";
  selectorivaexc.id = "iva_exc";
  selectorivaexc.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white ";
  const optionsivaexc = [
    { value: 1, text: "Sí" },
    { value: 0, text: "No" },
  ];
  optionsivaexc.forEach((optionivaexc) => {
    const optionElivaexc = document.createElement("OPTION");
    optionElivaexc.value = optionivaexc.value;
    optionElivaexc.textContent = optionivaexc.text;
    if (optionivaexc.value == medido.iva_exc) {
      optionElivaexc.setAttribute("selected", true);
    }
    selectorivaexc.appendChild(optionElivaexc);
  });

  divAño.appendChild(labelAño);
  divAño.appendChild(selectAño);
  divTipotoma.appendChild(labelTipotoma);
  divTipotoma.appendChild(selectorTipotoma);
  divTipoconsumo.appendChild(labelTipoconsumo);
  divTipoconsumo.appendChild(selectorTipoconsumo);
  divamount.appendChild(labelamount);
  divamount.appendChild(inputamount);
  divIva.appendChild(labelIva);
  divIva.appendChild(selectorIva);
  divlimitinf.appendChild(labellimitinf);
  divlimitinf.appendChild(inputlimitinf);
  divlimsup.appendChild(labellimsup);
  divlimsup.appendChild(inputlimsup);
  divexcm3.appendChild(labelexcm3);
  divexcm3.appendChild(inputexcm3);
  divexac.appendChild(labelexac);
  divexac.appendChild(selectorivaexc);

  formulario.appendChild(divTipotoma);
  formulario.appendChild(divTipoconsumo);
  formulario.appendChild(divamount);
  formulario.appendChild(divIva);
  formulario.appendChild(divlimitinf);
  formulario.appendChild(divlimsup);
  formulario.appendChild(divexcm3);
  formulario.appendChild(divexac);

  const btnGuardar = document.createElement("INPUT");
  btnGuardar.className =
    "w-full mb-2 text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800";
  btnGuardar.value = "Guardar";
  btnGuardar.type = "submit";
  btnGuardar.onclick = (e) => {
    e.preventDefault();
    if (editar) {
      enviarFormulario({ ...medido });
    } else {
      guardarMedido();
    }
  };
  formulario.appendChild(divAño);
  formulario.appendChild(divTipotoma);
  formulario.appendChild(divTipoconsumo);
  formulario.appendChild(divamount);
  formulario.appendChild(divIva);
  formulario.appendChild(divlimitinf);
  formulario.appendChild(divlimsup);
  formulario.appendChild(divexcm3);
  formulario.appendChild(divexac);
  formulario.appendChild(btnGuardar);

  const botonesDiv = document.createElement("DIV");
  botonesDiv.className =
    "flex justify-end p-4 md:p-5 border-t border-gray-200 rounded-b dark:border-gray-600";

  const btnCancelar = document.createElement("BUTTON");
  btnCancelar.className =
    "py-2.5 px-5  text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700";
  btnCancelar.textContent = "Cancelar";
  btnCancelar.onclick = () => {
    divBgModal.remove();
  };
  botonesDiv.appendChild(btnCancelar);
  formulario.appendChild(botonesDiv);

  divContent.appendChild(formulario);
  divModal.appendChild(divContent);
  divBgModal.appendChild(divModal);
  main.appendChild(divBgModal);
}
function getCsrfToken() {
  return document
    .querySelector('meta[name="csrf-token"]')
    .getAttribute("content");

  return token;
}
document.addEventListener("DOMContentLoaded", () => {
  const csrfToken = getCsrfToken();
});
async function enviarFormulario(medido) {
  const csrfToken = getCsrfToken();
  const id = medido.id;
  const id_intaketype = document.querySelector("#id_intaketype").value.trim();
  const id_consumtype = document.querySelector("#id_consumtype").value.trim();
  const year = document.querySelector("#year").value.trim();
  const amount = document.querySelector("#amount").value.trim();
  const iva = document.querySelector("#iva").value.trim();
  const liminf = document.querySelector("#liminf").value.trim();
  const limsup = document.querySelector("#limsup").value.trim();
  const excm3 = document.querySelector("#excm3").value.trim();
  const iva_exc = document.querySelector("#iva_exc").value.trim();
  const medidoObj = {
    id: id,
    id_intaketype: id_intaketype,
    id_consumtype: id_consumtype,
    year: year,
    amount: amount,
    iva: iva,
    liminf: liminf,
    limsup: limsup,
    excm3: excm3,
    iva_exc: iva_exc,
  };
  if (Object.values(medidoObj).some((v) => v === "")) {
    Swal.fire({
      icon: "error",
      title: "Campo vacío",
      text: "El campo no puede estar vacío.",
    });
    return;
  }
  const data = new FormData();
  data.append("id", id);
  data.append("id_intaketype", id_intaketype);
  data.append("id_consumtype", id_consumtype);
  data.append("year", year);
  data.append("amount", amount);
  data.append("iva", iva);
  data.append("liminf", liminf);
  data.append("limsup", limsup);
  data.append("excm3", excm3);
  data.append("iva_exc", iva_exc);
  data.append("csrf_token", csrfToken);
  try {
    const URL = `http://localhost:8000/update-measured/${id}`;
    const respuesta = await fetch(URL, {
      method: "POST",
      body: data,
    });
    const resultado = await respuesta.json();
    if (resultado.resultado === "Exito") {
      Swal.fire({
        icon: "success",
        title: resultado.resultado,
        text: "Actualización exitosa",
      });
      document.querySelector("#divBgModal").remove();
      tipotomaFilter = tipotoma.filter(
        (tToma) => tToma.id == resultado.id_intaketype
      );
      tipoconsumoFilter = tipoconsumo.filter(
        (tConsumo) => tConsumo.id == resultado.id_consumtype
      );
      serviciomedido = serviciomedido.map((medidosMem) => {
        if (medidosMem.id === id) {
          medidosMem.id_intaketype = resultado.id_intaketype;
          medidosMem.id_consumtype = resultado.id_consumtype;
          medidosMem.year = resultado.year;
          medidosMem.amount = resultado.amount;
          medidosMem.iva = resultado.iva;
          medidosMem.liminf = resultado.liminf;
          medidosMem.limsup = resultado.limsup;
          medidosMem.excm3 = resultado.excm3;
          medidosMem.iva_exc = resultado.iva_exc;
          medidosMem.tipo_toma = tipotomaFilter[0].name;
          medidosMem.tipo_consumo = tipoconsumoFilter[0].name;
        }
        return medidosMem;
      });
      mostrarserviciomedido();
    }
  } catch (error) {
    console.log(error);
  }
}

function confirmDelete(medido) {
  Swal.fire({
    title: "¿Estás seguro?",
    text: "Esta acción no se puede deshacer",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Sí, eliminar",
    cancelButtonText: "Cancelar",
  }).then((result) => {
    if (result.isConfirmed) {
      eliminarMedido(medido);
    }
  });
}
async function eliminarMedido(medido) {
  const csrfToken = getCsrfToken(); // Obtener el token CSRF
  const data = new FormData();
  data.append("id", medido.id);
  data.append("csrf_token", csrfToken);
  try {
    const URL = `http://localhost:8000/delete-measured/${medido.id}`;
    const respuesta = await fetch(URL, {
      method: "POST",
      body: data,
    });
    const resultado = await respuesta.json();
    if (resultado.resultado === "Exito") {
      Swal.fire({
        icon: "success",
        title: resultado.resultado,
        text: "Eliminación exitosa",
      });
      serviciomedido = serviciomedido.filter(
        (medidoMem) => medidoMem.id !== medido.id
      );
      mostrarserviciomedido();
    }
  } catch (error) {
    console.log(error);
  }
}

//funcion para crear servicio medido
async function guardarMedido() {
  const id_intaketype = document.querySelector("#id_intaketype").value.trim();
  const id_consumtype = document.querySelector("#id_consumtype").value.trim();
  const year = document.querySelector("#year").value.trim();
  const amount = document.querySelector("#amount").value.trim();
  const iva = document.querySelector("#iva").value.trim();
  const liminf = document.querySelector("#liminf").value.trim();
  const limsup = document.querySelector("#limsup").value.trim();
  const excm3 = document.querySelector("#excm3").value.trim();
  const iva_exc = document.querySelector("#iva_exc").value.trim();
  const medidoObj = {
    id_intaketype: id_intaketype,
    id_consumtype: id_consumtype,
    year: year,
    amount: amount,
    iva: iva,
    liminf: liminf,
    limsup: limsup,
    excm3: excm3,
    iva_exc: iva_exc,
  };
  if (Object.values(medidoObj).some((v) => v === "")) {
    Swal.fire({
      icon: "error",
      title: "Campo vacío",
      text: "El campo no puede estar vacío.",
    });
    return;
  }
  const data = new FormData();
  data.append("id_intaketype", id_intaketype);
  data.append("id_consumtype", id_consumtype);
  data.append("year", year);
  data.append("amount", amount);
  data.append("iva", iva);
  data.append("liminf", liminf);
  data.append("limsup", limsup);
  data.append("excm3", excm3);
  data.append("iva_exc", iva_exc);
  data.append("csrf_token", getCsrfToken());
  try {
    const URL = `http://localhost:8000/create-measured`;
    const respuesta = await fetch(URL, {
      method: "POST",
      body: data,
    });
    const resultado = await respuesta.json();
    if (resultado.resultado === "Exito") {
      Swal.fire({
        icon: "success",
        title: resultado.resultado,
        text: "Creación exitosa",
      });
      document.querySelector("#divBgModal").remove();
      const tipotomaFilter = tipotoma.filter(
        (tToma) => tToma.id == resultado.id_intaketype
      );
      const tipoconsumoFilter = tipoconsumo.filter(
        (tConsumo) => tConsumo.id == resultado.id_consumtype
      );
      const nuevoMedido = {
        id: resultado.id,
        id_intaketype: id_intaketype,
        id_consumtype: id_consumtype,
        year: year,
        amount: amount,
        iva: iva,
        liminf: liminf,
        limsup: limsup,
        excm3: excm3,
        iva_exc: iva_exc,
        tipo_toma: tipotomaFilter[0].name,
        tipo_consumo: tipoconsumoFilter[0].name,
      };
      serviciomedido = [...serviciomedido, nuevoMedido];
      mostrarserviciomedido();
    }
  } catch (error) {
    console.log(error);
  }
}
