async function obtenerTipoUsuario() {
  try {
    const URL = "http://localhost:8000/api/usertype";
    const response = await fetch(URL);
    const usertype = await response.json();
  } catch (error) {
    console.log(error);
  }
}
