async function obtenerPrioridades() {
  try {
    const URL = "http://localhost:8000/api/priority";
    const response = await fetch(URL);
    const priorities = await response.json();
    console.log(priorities);
  } catch (error) {
    console.log(error);
  }
}
