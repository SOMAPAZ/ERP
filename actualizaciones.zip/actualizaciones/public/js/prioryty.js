async function obtenerPrioridades() {
  try {
    const URL = "http://localhost:8000/api/priority";
    const response = await fetch(URL);
    const priorities = await response.json();
    console.log(priorities);
    const contenedor = document.getElementById("prioridad-tabla");

    //creacion de la tabla
    const table = document.createElement("table");
    table.classList.add("table");
    const thead = table.createTHead();
    const headerRow = thead.insertRow();
    const headers = ["ID", "Nombre", "Acciones"];
    headers.forEach((headerText) => {
      const th = document.createElement("th");
      th.textContent = headerText;
      headerRow.appendChild(th);
    });
    const tbody = table.createTBody();
    priorities.forEach((priority) => {
      const row = tbody.insertRow();
      const idCell = row.insertCell();
      idCell.textContent = priority.id;
      const nameCell = row.insertCell();
      nameCell.textContent = priority.name;
      const actionsCell = row.insertCell();

      //creacion de enlaces para editar y eliminar
      const editLink = document.createElement("a");
      editLink.href = `/update-priority/${priority.id}`;
      editLink.textContent = "Editar";
      editLink.classList.add("btn", "btn-warning");
      actionsCell.appendChild(editLink);

      const deleteLink = document.createElement("a");
      deleteLink.href = `/delete-priority/${priority.id}`;
      deleteLink.textContent = "Eliminar";
      deleteLink.classList.add("btn", "btn-danger");
      deleteLink.addEventListener("click", () => {
        if (confirm("¿Estas seguro de que deseas eliminar esta prioridad?")) {
          fetch(`/api/priority/${priority.id}`, {
            method: "DELETE",
            headers: {
              "Content-type": "application/json",
            },
          })
            .then(() => {
              obtenerPrioridades();
            })
            .catch((error) => {
              const errorMessage = document.createElement("p");
              errorMessage.textContent =
                "Ocurrio un error al eliminar la prioridad.";
              contenedor.appendChild(errorMessage);
            });
        }
      });
      actionsCell.appendChild(deleteLink);
    });
    contenedor.appendChild(table);
  } catch (error) {
    console.log(error);
  }
}
obtenerPrioridades();
