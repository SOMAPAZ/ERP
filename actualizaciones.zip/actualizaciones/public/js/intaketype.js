async function obtenerIntakeTypes() {
  try {
    const URL = "http://localhost:8000/api/intake_type";
    const response = await fetch(URL);
    const intakeTypes = await response.json();

    const contenedor = document.getElementById("intaketype-tabla");
    //creacion de la tabla
    const table = document.createElement("table");
    table.classList.add("table");
    const thead = table.createTHead();
    const headerRow = thead.insertRow();
    const headers = ["ID", "Nombre", "Acciones"];
    headers.forEach((headerText) => {
      const th = document.createElement("th");
      th.textContent = headerText;
      headerRow.appendChild(th);
    });
    const tbody = table.createTBody();
    intakeTypes.forEach((intakeTypes) => {
      const row = tbody.insertRow();
      const idCell = row.insertCell();
      idCell.textContent = intakeTypes.id;
      const nameCell = row.insertCell();
      nameCell.textContent = intakeTypes.name;
      const actionsCell = row.insertCell();

      //creacion de enlaces para editar y eliminar
      const editLink = document.createElement("a");
      editLink.href = `/update-intakeType/${intakeTypes.id}`;
      editLink.textContent = "Editar";
      editLink.classList.add("btn", "btn-warning");
      actionsCell.appendChild(editLink);

      const deleteLink = document.createElement("a");
      deleteLink.href = `/delete-intakeType/${intakeTypes.id}`;
      deleteLink.textContent = "Eliminar";
      deleteLink.classList.add("btn", "btn-danger");
      deleteLink.addEventListener("click", () => {
        if (
          confirm("¿Estas seguro de que deseas eliminar este tipo de toma?")
        ) {
          fetch(`/api/intake_type/${intakeTypes.id}`, {
            method: "DELETE",
            headers: {
              "Content-type": "application/json",
            },
          })
            .then(() => {
              obtenerIntakeTypes();
            })
            .catch((error) => {
              const errorMessage = document.createElement("p");
              errorMessage.textContent =
                "Ocurrio un error al eliminar el tipo de toma.";
              contenedor.appendChild(errorMessage);
            });
        }
      });
      actionsCell.appendChild(deleteLink);
    });

    contenedor.appendChild(table);
  } catch (error) {
    console.log("Error al obtener los tipos de toma:", error);
    const errorMessage = document.createElement("p");
    errorMessage.textContent = "Ocurrió un error al cargar los tipos de toma.";
  }
}
obtenerIntakeTypes();
