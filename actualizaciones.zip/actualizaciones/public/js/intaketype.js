document.addEventListener("DOMContentLoaded", () => {
  obtenerIntakeTypes();
});

async function obtenerIntakeTypes() {
  try {
    const URL = "http://localhost:8000/api/intake_type";
    const response = await fetch(URL);
    const intakeTypes = await response.json();
    console.log(intakeTypes);
  } catch (error) {
    console.log(error);
  }
}
