async function obtenerUnidades() {
  try {
    const URL = "http://localhost:8000/api/unities";
    const response = await fetch(URL);
    const unities = await response.json();
    console.log(unities);
  } catch (error) {
    console.log(error);
  }
}
