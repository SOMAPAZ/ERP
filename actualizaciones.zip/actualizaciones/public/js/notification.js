document.addEventListener("DOMContentLoaded", () => {
  obtenerNotifications();
});

async function obtenerNotifications() {
  try {
    const URL = "http://localhost:8000/api/notification";
    const response = await fetch(URL);
    const notifications = await response.json();
    console.log(notifications);
  } catch (error) {
    console.log(error);
  }
}
