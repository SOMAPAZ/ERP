document.addEventListener("DOMContentLoaded", () => {
  obtenerZonas();
});

async function obtenerZonas() {
  try {
    const URL = "http://localhost:8000/api/zone";
    const response = await fetch(URL);
    const zones = await response.json();
    console.log(zones);
  } catch (error) {
    console.log(error);
  }
}
