obtenerZones();
const tablaZones = document.querySelector("#zones-tabla");
const crearZona = document.querySelector("#crear-zona");
const trVacio = document.querySelector("#nodatos");
const controlesPaginacion = document.querySelector("#controles-paginacion");

const zoneObj = {
  id: "",
  name: "",
};
let paginaActual = 1;
let zonaPorPagina = 15;

let zones = [];

async function obtenerZones() {
  try {
    const URL = "http://localhost:8000/api/zone";
    const respuesta = await fetch(URL);
    const resultado = await respuesta.json();
    zones = resultado;
    mostrarZones();
    crearControlesPaginacion();
  } catch (error) {
    console.log(error);
  }
}
document.addEventListener("DOMContentLoaded", () => {
  inicializarPagina();
});
crearZona.addEventListener("click", () => {
  mostrarFormulario({});
});
//funciones paginacion
function inicializarPagina() {
  const urlParams = new URLSearchParams(window.location.search);
  const pagina = parseInt(urlParams.get("pagina")) || 1;
  paginaActual = pagina;
  obtenerZones();
}
function cambiarPagina(nuevaPagina) {
  paginaActual = nuevaPagina;

  const urlParams = new URLSearchParams(window.location.search);
  urlParams.set("pagina", nuevaPagina);
  window.history.pushState({}, "", `${window.location.pathname}?${urlParams}`);
  obtenerZones();
  crearControlesPaginacion();
}
function crearControlesPaginacion() {
  controlesPaginacion.innerHTML = "";
  const totalPaginas = Math.ceil(zones.length / zonaPorPagina);
  const rango = 2;
  if (totalPaginas < 1) return;

  controlesPaginacion.appendChild(crearBotonPagina(1));
  if (paginaActual - rango > 2) {
    const puntosInicio = document.createElement("SPAN");
    puntosInicio.textContent = "...";
    puntosInicio.className = "px-2 text-gray-500 justify-center";
    controlesPaginacion.appendChild(puntosInicio);
  }
  for (
    let i = Math.max(2, paginaActual - rango);
    i <= Math.min(totalPaginas - 1, paginaActual + rango);
    i++
  ) {
    controlesPaginacion.appendChild(crearBotonPagina(i));
  }

  if (paginaActual + rango < totalPaginas - 1) {
    const puntosFin = document.createElement("SPAN");
    puntosFin.textContent = "...";
    puntosFin.className = "px-2 text-gray-500";
    controlesPaginacion.appendChild(puntosFin);
  }

  if (totalPaginas > 1) {
    controlesPaginacion.appendChild(crearBotonPagina(totalPaginas));
  }
}

function crearBotonPagina(numeroPagina) {
  const botonPagina = document.createElement("BUTTON");
  botonPagina.textContent = numeroPagina;
  botonPagina.className = `px-4 py-2 ${
    numeroPagina === paginaActual
      ? "bg-blue-500 text-white"
      : "bg-gray-200 text-black"
  }`;
  botonPagina.onclick = () => cambiarPagina(numeroPagina);
  return botonPagina;
}
//funciones declarativas del sistema
function limpiarHtml() {
  while (tablaZones.firstChild) {
    tablaZones.removeChild(tablaZones.firstChild);
  }
}
function mostrarZones() {
  const inicio = (paginaActual - 1) * zonaPorPagina;
  const fin = inicio + zonaPorPagina;
  let zonaPagina = zones.slice(inicio, fin);
  limpiarHtml();
  trVacio.remove();
  zonaPagina.forEach((zone) => {
    const { id, name } = zone;
    const fila = document.createElement("TR");
    fila.className = "bg-white border-b dark:bg-gray-800 dark:border-gray-700";

    const celdaId = document.createElement("TD");
    celdaId.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaId.textContent = id;

    const celdaNombre = document.createElement("TD");
    celdaNombre.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white ";
    celdaNombre.textContent = name;

    const celdaAcciones = document.createElement("TD");
    celdaAcciones.className = "flex px-3 py-3 gap-3";
    const btnEditar = document.createElement("BUTTON");
    btnEditar.className =
      "bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded";
    btnEditar.textContent = "Editar";
    btnEditar.onclick = () => {
      mostrarFormulario(zone, true);
    };
    const btnEliminar = document.createElement("BUTTON");
    btnEliminar.className =
      "bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded";
    btnEliminar.textContent = "Eliminar";
    btnEliminar.onclick = () => {
      confirmaDelete(zone);
    };

    celdaAcciones.appendChild(btnEditar);
    celdaAcciones.appendChild(btnEliminar);

    fila.appendChild(celdaId);
    fila.appendChild(celdaNombre);
    fila.appendChild(celdaAcciones);
    tablaZones.appendChild(fila);
  });
}
//mostrar datos
function mostrarFormulario(zone, editar = false) {
  const main = document.querySelector("main");
  const divBgModal = document.createElement("DIV");
  divBgModal.id = "divBgModal";

  const divModal = document.createElement("DIV");
  divModal.className =
    "overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 bottom-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%)] max-h-full dark:bg-gray-900 bg-gray-300";
  const divContent = document.createElement("DIV");
  divContent.className =
    "relative p-4 w-full max-w-2xl max-h-full mx-auto mt-5";
  const formulario = document.createElement("FORM");
  formulario.className =
    "relative bg-white rounded-lg p-4 shadow dark:bg-gray-700";

  const divNombre = document.createElement("DIV");
  divNombre.className = "mb-5";
  const labelNombre = document.createElement("LABEL");
  labelNombre.for = "name";
  labelNombre.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelNombre.textContent = "Nombre";
  const inputNombre = document.createElement("INPUT");
  inputNombre.type = "text";
  inputNombre.id = "name";
  inputNombre.name = "name";
  inputNombre.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white";
  inputNombre.value = zone.name || "";
  inputNombre.maxLength = 20;
  inputNombre.addEventListener("input", () => {
    inputNombre.value = inputNombre.value.replace(/[^a-zA-ZáéíóúÁÉÍÓÚ\s]/g, "");
    if (inputNombre.value.length > 20) {
      inputNombre.value = inputNombre.value.slice(0, 20);
    }
  });
  divNombre.appendChild(labelNombre);
  divNombre.appendChild(inputNombre);

  const btnGuardar = document.createElement("INPUT");
  btnGuardar.className =
    "w-full mb-2 text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800";
  btnGuardar.value = "Guardar";
  btnGuardar.type = "submit";
  btnGuardar.onclick = (e) => {
    e.preventDefault();
    if (editar) {
      enviarFormulario({ ...zone });
    } else {
      guardarZone();
    }
  };

  formulario.appendChild(divNombre);
  formulario.appendChild(btnGuardar);

  const botonesDiv = document.createElement("DIV");
  botonesDiv.className =
    "flex justify-end p-4 md:p-5 border-t border-gray-200 rounded-b dark:border-gray-600";

  const btnCancelar = document.createElement("BUTTON");
  btnCancelar.className =
    "py-2.5 px-5  text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700";
  btnCancelar.textContent = "Cancelar";
  btnCancelar.onclick = () => {
    divBgModal.remove();
  };
  botonesDiv.appendChild(btnCancelar);
  formulario.appendChild(botonesDiv);

  divContent.appendChild(formulario);
  divModal.appendChild(divContent);
  divBgModal.appendChild(divModal);
  main.appendChild(divBgModal);
}
function getCsrfToken() {
  return document
    .querySelector('meta[name="csrf-token"]')
    .getAttribute("content");

  return token;
}
document.addEventListener("DOMContentLoaded", () => {
  const csrfToken = getCsrfToken();
  console.log("Enviando token CSRF: " + csrfToken); // Verifica que el token sea correcto antes de enviarlo
});
//actualizar zona
async function enviarFormulario(zone) {
  const csrfToken = getCsrfToken();
  const id = zone.id;
  const name = document.querySelector("#name").value.trim();
  const zoneObj = {
    id: id,
    name: name,
  };
  if (Object.values(zoneObj).some((v) => v === "")) {
    Swal.fire({
      icon: "error",
      title: "Campo vacío",
      text: "El campo no puede estar vacío.",
    });
    return;
  }
  const existe = zones.some(
    (zona) => zona.name.toLowerCase() === name.toLowerCase()
  );
  if (existe) {
    Swal.fire({
      icon: "error",
      title: "Nombre ya existe",
      text: "El nombre ya existe",
    });
    return;
  }
  const data = new FormData();
  data.append("id", id);
  data.append("name", name);
  data.append("csrf_token", csrfToken);
  try {
    const URL = `http://localhost:8000/update-zone/${id}`;
    const respuesta = await fetch(URL, {
      method: "POST",
      body: data,
    });
    const resultado = await respuesta.json();
    if (resultado.resultado === "Exito") {
      Swal.fire({
        icon: "success",
        title: resultado.resultado,
        text: "Actualización exitosa",
      });
      document.querySelector("#divBgModal").remove();
      zones = zones.map((zoneMem) => {
        if (zoneMem.id === id) {
          zoneMem.name = resultado.name;
        }
        return zoneMem;
      });
      mostrarZones();
    }
  } catch (error) {
    console.log(error);
  }
}

//eliminar zona
async function confirmaDelete(zone) {
  Swal.fire({
    title: "¿Estás seguro?",
    text: "Esta acción no se puede deshacer",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Sí, eliminar",
    cancelButtonText: "Cancelar",
  }).then((result) => {
    if (result.isConfirmed) {
      eliminarZone(zone);
    }
  });
}
async function eliminarZone(zone) {
  const csrfToken = getCsrfToken(); // Obtener el token CSRF
  const data = new FormData();
  data.append("id", zone.id);
  data.append("csrf_token", csrfToken);
  try {
    const URL = `http://localhost:8000/delete-zone/${zone.id}`;
    const respuesta = await fetch(URL, {
      method: "POST",
      body: data,
    });
    const resultado = await respuesta.json();
    // Verifica el contenido de la respuesta
    if (resultado.resultado === "Exito") {
      Swal.fire({
        icon: "success",
        title: resultado.resultado,
        text: "Eliminación exitosa",
      });
      zones = zones.filter((zoneMem) => zoneMem.id !== zone.id);
      mostrarZones();
    }
  } catch (error) {
    console.error("No se puede Eliminar la zona");
    Swal.fire({
      icon: "error",
      title: "Error",
      text: "No se pudo completar la operación. Por favor, contacte con el administrador.",
    });
  }
}
//crear zona
async function guardarZone() {
  const name = document.querySelector("#name").value.trim();
  const zoneObj = {
    name: name,
  };
  if (Object.values(zoneObj).some((v) => v === "")) {
    Swal.fire({
      icon: "error",
      title: "Campo vacío",
      text: "El campo no puede estar vacío.",
    });
    return;
  }
  const existe = zones.some(
    (zone) => zone.name.toLowerCase() === name.toLowerCase()
  );
  if (existe) {
    Swal.fire({
      icon: "error",
      title: "Nombre ya existe",
      text: "El nombre ya existe",
    });
    return;
  }
  const data = new FormData();
  data.append("name", name);
  data.append("csrf_token", getCsrfToken());
  try {
    const URL = `http://localhost:8000/create-zone`;
    const respuesta = await fetch(URL, {
      method: "POST",
      body: data,
    });
    const resultado = await respuesta.json();
    if (resultado.resultado === "Exito") {
      Swal.fire({
        icon: "success",
        title: resultado.resultado,
        text: "Creación exitosa",
      });
      document.querySelector("#divBgModal").remove();

      const nuevoZone = {
        id: resultado.id,
        name: name,
      };
      zones = [...zones, nuevoZone];
      mostrarZones();
    }
  } catch (error) {
    console.log(error);
  }
}
