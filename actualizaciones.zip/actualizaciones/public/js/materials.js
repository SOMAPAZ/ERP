async function obtenerMateriales() {
  try {
    const URL = "http://localhost:8000/api/materials";
    const response = await fetch(URL);
    const materials = await response.json();
    console.log(materials);
  } catch (error) {
    console.log(error);
  }
}
