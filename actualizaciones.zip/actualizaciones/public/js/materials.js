async function obtenerMateriales() {
  try {
    const URL = "http://localhost:8000/api/materials";
    const response = await fetch(URL);
    const materials = await response.json();

    const contenedor = document.getElementById("material-tabla");
    //creacion de la tabla
    const table = document.createElement("table");
    table.classList.add("table");
    const thead = table.createTHead();
    const headerRow = thead.insertRow();
    const headers = ["ID", "Nombre", "Acciones"];
    headers.forEach((headerText) => {
      const th = document.createElement("th");
      th.textContent = headerText;
      headerRow.appendChild(th);
    });
    const tbody = table.createTBody();
    materials.forEach((material) => {
      const row = tbody.insertRow();
      const idCell = row.insertCell();
      idCell.textContent = material.id;
      const nameCell = row.insertCell();
      nameCell.textContent = material.name;
      const actionsCell = row.insertCell();

      //creacion de enlaces para editar y eliminar
      const editLink = document.createElement("a");
      editLink.href = `/update-materials/${material.id}`;
      editLink.textContent = "Editar";
      editLink.classList.add("btn", "btn-warning");
      actionsCell.appendChild(editLink);

      const deleteLink = document.createElement("a");
      deleteLink.href = `/delete-materials/${material.id}`;
      deleteLink.textContent = "Eliminar";
      deleteLink.classList.add("btn", "btn-danger");
      deleteLink.addEventListener("click", () => {
        if (confirm("¿Estas seguro de que deseas eliminar este material?")) {
          fetch(`/api/materials/${material.id}`, {
            method: "DELETE",
            headers: {
              "Content-type": "application/json",
            },
          })
            .then(() => {
              obtenerMateriales();
            })
            .catch((error) => {
              const errorMessage = document.createElement("p");
              errorMessage.textContent =
                "Ocurrio un error al eliminar el material.";
              contenedor.appendChild(errorMessage);
            });
        }
      });
      actionsCell.appendChild(deleteLink);
    });
    contenedor.appendChild(table);
  } catch (error) {
    console.log("Error al obtener los materiales:", error);
    const errorMessage = document.createElement("p");
    errorMessage.textContent = "Ocurrió un error al cargar los materiales.";
    contenedor.appendChild(errorMessage);
  }
}
obtenerMateriales();
