async function obtenerTarifas() {
  try {
    const URL = "http://localhost:8000/api/rate";
    const response = await fetch(URL);
    const rate = await response.json();
    console.log(rate);
  } catch (error) {
    console.log(error);
  }
}
