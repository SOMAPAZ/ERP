obtenerTarifas();
consumoIntake();
const tablaTarifas = document.querySelector("#tarifas-tabla");
const crearTarifa = document.querySelector("#crear-tarifa");
const trVacio = document.querySelector("#nodatos");
const controlesPaginacion = document.querySelector("#controles-paginacion");
const tarifaObj = {
  id: "",
  year: "",
  id_consum_intake: "",
  iva: "",
  amount: "",
};

//paginacion
let paginaActual = 1;
let fijoPorPagina = 8;

let intake = [];
let intakeFilter = [];

document.addEventListener("DOMContentLoaded", () => {
  inicializarPagina();
});
crearTarifa.addEventListener("click", () => {
  mostrarFormulario({});
});
//funciones para paginacion
function inicializarPagina() {
  const urlParams = new URLSearchParams(window.location.search);
  const pagina = parseInt(urlParams.get("pagina")) || 1;
  paginaActual = pagina;
  obtenerTarifas();
}
function cambiarPagina(nuevaPagina) {
  paginaActual = nuevaPagina;

  const urlParams = new URLSearchParams(window.location.search);
  urlParams.set("pagina", nuevaPagina);
  window.history.pushState({}, "", `${window.location.pathname}?${urlParams}`);

  mostrarTarifas();
  crearControlesPaginacion();
}
function crearControlesPaginacion() {
  controlesPaginacion.innerHTML = "";
  const totalPaginas = Math.ceil(serviciofijo.length / fijoPorPagina);
  const rango = 2;
  if (totalPaginas < 1) return;

  controlesPaginacion.appendChild(crearBotonPagina(1));

  if (paginaActual - rango > 2) {
    const puntosInicio = document.createElement("SPAN");
    puntosInicio.textContent = "...";
    puntosInicio.className = "px-2 text-gray-500 justify-center";
    controlesPaginacion.appendChild(puntosInicio);
  }

  for (
    let i = Math.max(2, paginaActual - rango);
    i <= Math.min(totalPaginas - 1, paginaActual + rango);
    i++
  ) {
    controlesPaginacion.appendChild(crearBotonPagina(i));
  }

  if (paginaActual + rango < totalPaginas - 1) {
    const puntosFin = document.createElement("SPAN");
    puntosFin.textContent = "...";
    puntosFin.className = "px-2 text-gray-500";
    controlesPaginacion.appendChild(puntosFin);
  }

  if (totalPaginas > 1) {
    controlesPaginacion.appendChild(crearBotonPagina(totalPaginas));
  }
}

function crearBotonPagina(numeroPagina) {
  const botonPagina = document.createElement("BUTTON");
  botonPagina.textContent = numeroPagina;
  botonPagina.className = `px-4 py-2 ${
    numeroPagina === paginaActual
      ? "bg-blue-500 text-white"
      : "bg-gray-200 text-black"
  }`;
  botonPagina.onclick = () => cambiarPagina(numeroPagina);
  return botonPagina;
}

async function obtenerTarifas() {
  try {
    const URL = "http://localhost:8000/api/rate";
    const respuesta = await fetch(URL);
    const resultado = await respuesta.json();
    serviciofijo = resultado;
    mostrarTarifas();
    crearControlesPaginacion();
  } catch (error) {
    console.log(error);
  }
}
async function consumoIntake() {
  try {
    const URL = "http://localhost:8000/api/consumeIntake";
    const respuesta = await fetch(URL);
    const resultado = await respuesta.json();
    intake = resultado;
  } catch (error) {
    console.log(error);
  }
}
function limpiarHtml() {
  while (tablaTarifas.firstChild) {
    tablaTarifas.removeChild(tablaTarifas.firstChild);
  }
}
function mostrarTarifas() {
  const inicio = (paginaActual - 1) * fijoPorPagina;
  const fin = inicio + fijoPorPagina;
  let fijoPagina = serviciofijo.slice(inicio, fin);
  limpiarHtml();
  trVacio.remove();
  fijoPagina.forEach((fijo) => {
    const {
      id,
      year,
      id_consum_intake,
      amount,
      iva,
      nombre_intake_type,
      nombre_consume_type,
    } = fijo;
    const fila = document.createElement("tr");
    fila.className = "bg-white border-b dark:bg-gray-800 dark:border-gray-700";

    const celdaId = document.createElement("TD");
    celdaId.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white";
    celdaId.textContent = id;

    const celdaTipotoma = document.createElement("TD");
    celdaTipotoma.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white";
    celdaTipotoma.textContent = nombre_intake_type;

    const celdaTipoconsumo = document.createElement("TD");
    celdaTipoconsumo.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white";
    celdaTipoconsumo.textContent = nombre_consume_type;

    const celdaAño = document.createElement("TD");
    celdaAño.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white";
    celdaAño.textContent = year;

    const celdaMonto = document.createElement("TD");
    celdaMonto.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white";
    celdaMonto.textContent = Number(amount).toLocaleString("es-MX", {
      style: "currency",
      currency: "MXN",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });

    const celdaIva = document.createElement("TD");
    celdaIva.className =
      "px-6 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white";
    celdaIva.textContent = iva == 1 ? "Sí" : "No";

    const celdaAcciones = document.createElement("TD");
    celdaAcciones.className =
      "flex justify-between px-6 py-3 whitespace-nowrap gap-3";

    const btnEditar = document.createElement("BUTTON");
    btnEditar.className =
      "bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded";
    btnEditar.textContent = "Editar";
    btnEditar.onclick = () => {
      mostrarFormulario(fijo, true);
    };
    const btnEliminar = document.createElement("BUTTON");
    btnEliminar.className =
      "bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded";
    btnEliminar.textContent = "Eliminar";
    btnEliminar.onclick = () => {
      confirmDelete(fijo);
    };

    celdaAcciones.appendChild(btnEditar);
    celdaAcciones.appendChild(btnEliminar);

    fila.appendChild(celdaId);
    fila.appendChild(celdaAño);
    fila.appendChild(celdaTipotoma);
    fila.appendChild(celdaTipoconsumo);
    fila.appendChild(celdaMonto);
    fila.appendChild(celdaIva);
    fila.appendChild(celdaAcciones);
    tablaTarifas.appendChild(fila);
  });
}
function mostrarFormulario(fijo, editar = false) {
  const main = document.querySelector("main");
  const divBgModal = document.createElement("DIV");
  divBgModal.id = "divBgModal";

  const divModal = document.createElement("DIV");
  divModal.className =
    "overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 bottom-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%)] max-h-full dark:bg-gray-900 bg-gray-300";

  const divContent = document.createElement("DIV");
  divContent.className =
    "relative p-4 w-full max-w-2xl max-h-full mx-auto mt-5";

  const formulario = document.createElement("FORM");
  formulario.className =
    "relative bg-white rounded-lg p-4 shadow dark:bg-gray-700";
  const divAño = document.createElement("DIV");
  divAño.className = "mb-5";
  const labelAño = document.createElement("LABEL");
  labelAño.for = "year";
  labelAño.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelAño.textContent = "Año";
  const selectAño = document.createElement("SELECT");
  selectAño.id = "year";
  selectAño.name = "year";
  selectAño.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white";

  const startYear = 2007;
  const currentYear = new Date().getFullYear();
  const endYear = currentYear + 2;
  for (let year = startYear; year <= endYear; year++) {
    const option = document.createElement("OPTION");
    option.value = year;
    option.textContent = year;
    selectAño.appendChild(option);
  }
  selectAño.value = fijo.year || currentYear;

  //selector de toma consumo
  const divConsume_intake = document.createElement("DIV");
  divConsume_intake.className = "mb-5";
  const labelConsume_intake = document.createElement("LABEL");
  labelConsume_intake.for = "id_consum_intake";
  labelConsume_intake.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelConsume_intake.textContent = "Toma - Consumo";
  const selectorConsume_intake = document.createElement("SELECT");
  selectorConsume_intake.name = "id_consum_intake";
  selectorConsume_intake.id = "id_consum_intake";
  selectorConsume_intake.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white ";
  const filteredIntake = intake.filter(
    (tConsumo) =>
      tConsumo.nombre_intake_type !== "Sin establecer" &&
      tConsumo.nombre_consume_type !== "Sin establecer"
  );

  // Iterar sobre los objetos filtrados
  filteredIntake.forEach((tConsumo) => {
    let option = Array.from(selectorConsume_intake.options).find(
      (opt) => opt.value == tConsumo.id
    );

    // Si la opción ya existe, actualizamos su texto
    if (option) {
      const name = `${tConsumo.nombre_intake_type} - ${tConsumo.nombre_consume_type}`;
      option.textContent = name;
    } else {
      // Si no existe, creamos una nueva opción
      option = document.createElement("OPTION");
      option.value = tConsumo.id;
      const name = `${tConsumo.nombre_intake_type} - ${tConsumo.nombre_consume_type}`;
      option.textContent = name;
      selectorConsume_intake.appendChild(option);
    }

    // Marcar como seleccionada si coincide con el valor actual
    if (tConsumo.id === fijo.id_consum_intake) {
      option.selected = true;
    }
  });

  // Asegurar que el valor actual se refleje visualmente
  selectorConsume_intake.value = fijo.id_consum_intake || "";

  const divMonto = document.createElement("DIV");
  divMonto.className = "mb-5";
  const labelMonto = document.createElement("LABEL");
  labelMonto.for = "amount";
  labelMonto.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelMonto.textContent = "Monto";
  const inputMonto = document.createElement("INPUT");
  inputMonto.type = "text";
  inputMonto.id = "amount";
  inputMonto.name = "amount";
  inputMonto.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white";
  inputMonto.value = fijo.amount || "";
  inputMonto.maxLength = 10;

  inputMonto.addEventListener("input", () => {
    inputMonto.value = inputMonto.value.replace(/[^0-9.]/g, "");
    const pointIndex = inputMonto.value.indexOf(".");
    if (pointIndex !== -1) {
      inputMonto.value =
        inputMonto.value.slice(0, pointIndex + 1) +
        inputMonto.value.slice(pointIndex + 1).replace(/\./g, "");
    }

    const [integer, decimal] = inputMonto.value.split(".");
    if (integer && integer.length > 10) {
      inputMonto.value = integer.slice(0, 10) + (decimal ? "." + decimal : ""); // Limitar a 10 dígitos en la parte entera
    }
    if (decimal && decimal.length > 2) {
      inputMonto.value = integer + "." + decimal.slice(0, 2);
    }
  });
  const divIva = document.createElement("DIV");
  divIva.className = "mb-5";
  const labelIva = document.createElement("LABEL");
  labelIva.for = "iva";
  labelIva.className =
    "block mb-2 text-sm font-medium text-gray-900 dark:text-white";
  labelIva.textContent = "IVA";
  const selectorIva = document.createElement("SELECT");
  selectorIva.name = "iva";
  selectorIva.id = "iva";
  selectorIva.className =
    "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white ";
  const options = [
    { value: 1, text: "Sí" },
    { value: 0, text: "No" },
  ];
  options.forEach((option) => {
    const optionEl = document.createElement("OPTION");
    optionEl.value = option.value;
    optionEl.textContent = option.text;
    if (option.value == fijo.iva) {
      optionEl.setAttribute("selected", true);
    }
    selectorIva.appendChild(optionEl);
  });

  const btnGuardar = document.createElement("INPUT");
  btnGuardar.className =
    "w-full mb-2 text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800";
  btnGuardar.value = "Guardar";
  btnGuardar.type = "submit";
  btnGuardar.onclick = (e) => {
    e.preventDefault();
    if (editar) {
      enviarFormulario({ ...fijo });
    } else {
      guardarTarifa();
    }
  };

  divAño.appendChild(labelAño);
  divAño.appendChild(selectAño);
  divConsume_intake.appendChild(labelConsume_intake);
  divConsume_intake.appendChild(selectorConsume_intake);
  divMonto.appendChild(labelMonto);
  divMonto.appendChild(inputMonto);
  divIva.appendChild(labelIva);
  divIva.appendChild(selectorIva);

  formulario.appendChild(divAño);
  formulario.appendChild(divConsume_intake);
  formulario.appendChild(divMonto);
  formulario.appendChild(divIva);
  formulario.appendChild(btnGuardar);

  const botonesDiv = document.createElement("DIV");
  botonesDiv.className =
    "flex justify-end p-4 md:p-5 border-t border-gray-200 rounded-b dark:border-gray-600";

  const btnCancelar = document.createElement("BUTTON");
  btnCancelar.className =
    "py-2.5 px-5  text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700";
  btnCancelar.textContent = "Cancelar";
  btnCancelar.onclick = () => {
    divBgModal.remove();
  };
  botonesDiv.appendChild(btnCancelar);
  formulario.appendChild(botonesDiv);
  divContent.appendChild(formulario);
  divModal.appendChild(divContent);
  divBgModal.appendChild(divModal);
  main.appendChild(divBgModal);
}
function getCsrfToken() {
  return document
    .querySelector('meta[name="csrf-token"]')
    .getAttribute("content");

  return token;
}
document.addEventListener("DOMContentLoaded", () => {
  const csrfToken = getCsrfToken();
  console.log("Enviando token CSRF: " + csrfToken); // Verifica que el token sea correcto antes de enviarlo
});
async function enviarFormulario(fijo) {
  const csrfToken = getCsrfToken();
  const id = fijo.id;
  const id_consum_intake = document
    .querySelector("#id_consum_intake")
    .value.trim();
  const year = document.querySelector("#year").value.trim();
  const amount = document.querySelector("#amount").value.trim();
  const iva = document.querySelector("#iva").value.trim();
  const medidoObj = {
    id: id,
    id_consum_intake: id_consum_intake,
    year: year,
    amount: amount,
    iva: iva,
  };
  if (Object.values(medidoObj).some((v) => v === "")) {
    Swal.fire({
      icon: "error",
      title: "Campo vacío",
      text: "El campo no puede estar vacío.",
    });
    return;
  }
  const data = new FormData();
  data.append("id", id);
  data.append("id_consum_intake", id_consum_intake);
  data.append("year", year);
  data.append("amount", amount);
  data.append("iva", iva);
  data.append("csrf_token", csrfToken);
  try {
    const URL = `http://localhost:8000/update-rate/${id}`;
    const respuesta = await fetch(URL, {
      method: "POST",
      body: data,
    });
    const resultado = await respuesta.json();
    if (resultado.resultado === "Exito") {
      Swal.fire({
        icon: "success",
        title: resultado.resultado,
        text: "Actualización exitosa",
      });
      document.querySelector("#divBgModal").remove();

      intakeFilter = intake.filter(
        (tConsumo) => tConsumo.id == resultado.id_consum_intake
      );

      serviciofijo = serviciofijo.map((medidosMem) => {
        if (medidosMem.id === id) {
          medidosMem.id_consum_intake = resultado.id_consum_intake;
          medidosMem.year = resultado.year;
          medidosMem.amount = resultado.amount;
          medidosMem.iva = resultado.iva;
          medidosMem.nombre_intake_type = intakeFilter[0].nombre_intake_type;
          medidosMem.nombre_consume_type = intakeFilter[0].nombre_consume_type;
        }
        return medidosMem;
      });
      mostrarTarifas(); // Volver a renderizar la tabla
    }
  } catch (error) {
    console.log(error);
  }
}
//complemento para eliminar
function confirmDelete(fijo) {
  Swal.fire({
    title: "¿Estás seguro?",
    text: "Esta acción no se puede deshacer",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Sí, eliminar",
    cancelButtonText: "Cancelar",
  }).then((result) => {
    if (result.isConfirmed) {
      eliminarTarifa(fijo);
    }
  });
}
async function eliminarTarifa(fijo) {
  const csrfToken = getCsrfToken(); // Obtener el token CSRF
  const data = new FormData();
  data.append("id", fijo.id);
  data.append("csrf_token", csrfToken);
  try {
    const URL = `http://localhost:8000/delete-rate/${fijo.id}`;
    const respuesta = await fetch(URL, {
      method: "POST",
      body: data,
    });
    const resultado = await respuesta.json();
    if (resultado.resultado === "Exito") {
      Swal.fire({
        icon: "success",
        title: resultado.resultado,
        text: "Eliminación exitosa",
      });
      // Actualizar el arreglo serviciofijo y luego renderizar
      serviciofijo = serviciofijo.filter(
        (medidoMem) => medidoMem.id !== fijo.id
      );
      mostrarTarifas(); // Volver a renderizar la tabla
    }
  } catch (error) {
    console.log(error);
  }
}
//funcion para crear servicio medido
async function guardarTarifa() {
  const id_consum_intake = document
    .querySelector("#id_consum_intake")
    .value.trim();
  const year = document.querySelector("#year").value.trim();
  const amount = document.querySelector("#amount").value.trim();
  const iva = document.querySelector("#iva").value.trim();
  const medidoObj = {
    id_consum_intake: id_consum_intake,
    year: year,
    amount: amount,
    iva: iva,
  };
  if (Object.values(medidoObj).some((v) => v === "")) {
    Swal.fire({
      icon: "error",
      title: "Campo vacío",
      text: "El campo no puede estar vacío.",
    });
    return;
  }
  const data = new FormData();
  data.append("id_consum_intake", id_consum_intake);
  data.append("year", year);
  data.append("amount", amount);
  data.append("iva", iva);
  data.append("csrf_token", getCsrfToken());
  try {
    const URL = `http://localhost:8000/create-rate`;
    const respuesta = await fetch(URL, {
      method: "POST",
      body: data,
    });
    const resultado = await respuesta.json();
    if (resultado.resultado === "Exito") {
      Swal.fire({
        icon: "success",
        title: resultado.resultado,
        text: "Creación exitosa",
      });
      document.querySelector("#divBgModal").remove();

      intakeFilter = intake.filter(
        (tConsumo) => tConsumo.id == resultado.id_consum_intake
      );
      const nuevoTarifa = {
        id: resultado.id,
        id_consum_intake: id_consum_intake,
        year: year,
        amount: amount,
        iva: iva,
        nombre_consume_type: intakeFilter[0].nombre_consume_type,
        nombre_intake_type: intakeFilter[0].nombre_intake_type,
      };
      serviciofijo = [...serviciofijo, nuevoTarifa];
      mostrarTarifas(); // Volver a renderizar la tabla
    }
  } catch (error) {
    console.log(error);
  }
}
