async function obtenerEstadosServicio() {
  try {
    const URL = "http://localhost:8000/api/servicestatus";
    const response = await fetch(URL);
    const servicestatus = await response.json();
  } catch (error) {
    console.log(error);
  }
}
