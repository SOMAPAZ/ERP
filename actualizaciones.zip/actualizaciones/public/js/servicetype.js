async function obtenerTipoServicio() {
  try {
    const URL = "http://localhost:8000/api/servicetype";
    const response = await fetch(URL);
    const servicetype = await response.json();
  } catch (error) {
    console.log(error);
  }
}
