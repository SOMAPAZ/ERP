async function obtenerLocalidades() {
  try {
    const URL = "http://localhost:8000/api/locality";
    const response = await fetch(URL);
    const localities = await response.json();
    console.log(localities);
  } catch (error) {
    console.log(error);
  }
}
