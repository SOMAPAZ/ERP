async function obtenerRoles() {
  try {
    const URL = "http://localhost:8000/api/roles";
    const response = await fetch(URL);
    const roles = await response.json();
    console.log(roles);
  } catch (error) {
    console.log(error);
  }
}
