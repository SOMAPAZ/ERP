async function obtenerColonias() {
  try {
    const URL = "http://localhost:8000/api/colonies";
    const response = await fetch(URL);

    if (!response.ok) {
      throw new Error("Error en la respuesta: " + response.status);
    }
    const colonies = await response.json();

    //pbtener el elemento contenedor

    const contenedor = document.getElementById("colonia-tabla");

    //creacion de la tabla
    const table = document.createElement("table");
    table.classList.add("table");
    const thead = table.createTHead();
    const headerRow = thead.insertRow();
    const headers = ["ID", "Nombre", "Acciones"];
    headers.forEach((headerText) => {
      const th = document.createElement("th");
      th.textContent = headerText;
      headerRow.appendChild(th);
    });

    const tbody = table.createTBody();
    colonies.forEach((colony) => {
      const row = tbody.insertRow();
      const idCell = row.insertCell();
      idCell.textContent = colony.id;
      const nameCell = row.insertCell();
      nameCell.textContent = colony.name;
      const actionsCell = row.insertCell();

      //creacion de los enlaces para editar y eliminar

      const editLink = document.createElement("a");
      editLink.href = `/update-colony/${colony.id}`;
      editLink.textContent = "Editar";
      editLink.classList.add("btn", "btn-warning");
      actionsCell.appendChild(editLink);

      const deleteLink = document.createElement("a");
      deleteLink.href = `/delete-colony/${colony.id}`;
      deleteLink.textContent = "Eliminar";
      deleteLink.classList.add("btn", "btn-danger");
      deleteLink.addEventListener("click", () => {
        if (confirm("¿Estas Seguro de que deseas eliminar esta colonia?")) {
          fetch(`/api/colonies/${colony.id}`, {
            method: "DELETE",
            headers: {
              "Content-type": "application/json",
            },
          })
            .then(() => {
              obtenerColonias();
            })
            .catch((error) => {
              const errorMessage = document.createElement("p");
              errorMessage.textContent =
                "Ocurrio un error al eliminar la colonia.";
              contenedor.appendChild(errorMessage);
            });
        }
      });
      actionsCell.appendChild(deleteLink);
    });
    contenedor.appendChild(table);
  } catch (error) {
    console.error("Error al obtener las categorías:", error);
    const errorMessage = document.createElement("p");
    errorMessage.textContent = "Ocurrió un error al cargar las categorías.";
    contenedor.appendChild(errorMessage);
  }
}
obtenerColonias();
