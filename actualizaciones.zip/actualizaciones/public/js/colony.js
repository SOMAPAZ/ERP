async function obtenerColonias() {
  try {
    const URL = "http://localhost:8000/api/colonies";
    const response = await fetch(URL);

    if (!response.ok) {
      throw new Error("Error en la respuesta: " + response.status);
    }
    const colonies = await response.json();
    console.log(colonies);
  } catch (error) {
    console.error(error);
  }
}
