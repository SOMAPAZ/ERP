document.addEventListener("DOMContentLoaded", () => {
  obtenerIncidencias();
});

async function obtenerIncidencias() {
  try {
    const URL = "http://localhost:8000/api/incidence";
    const response = await fetch(URL);
    const incidences = await response.json();
    console.log(incidences);
  } catch (error) {
    console.log(error);
  }
}
