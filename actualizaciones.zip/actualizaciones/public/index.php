<?php
require_once __DIR__ . '/../vendor/autoload.php';

use App\Controllers\APIController;
use App\Controllers\ReadController;
use App\Controllers\CreateController;
use App\Controllers\UpdateController;
use App\Controllers\DeleteController;
use App\Core\Router;
// Crear el enrutador
$router = new Router();
// Modelos CRUD
$models = [
    'category',
    'colony',
    'consumeType',
    'intakeType',
    'locality',
    'materials',
    'priority',
    'roles',
    'unities',
    'userStorage',
    'zone',
    'user',
    'employment',
    'incidence',
    'rate',
    'measured',
    'serviceRights',
    'format',
    'notification'
];
// Rutas para la vista de lectura
foreach ($models as $model) {
    $router->get("/{$model}Index", [ReadController::class, "{$model}Index"]);
}
// Rutas para la creación de modelos
foreach ($models as $model) {
    $router->post("/create-{$model}", [CreateController::class, "{$model}Store"]);
}

// Rutas para la actualización de modelos
foreach ($models as $model) {
    $router->post("/update-{$model}/{id}", [UpdateController::class, "{$model}Update"]);
}
//rutas para eliminacion de modelos
foreach ($models as $model) {
    $router->post("/delete-{$model}/{id}", [DeleteController::class, "{$model}Delete"]);
}
// Modelos API
$apiModels = [
    'colonies',
    'categories',
    'consumetypes',
    'employments',
    'format',
    'incidence',
    'intake_type',
    'locality',
    'materials',
    'measured',
    'notification',
    'priority',
    'rate',
    'roles',
    'servicerights',
    'unities',
    'user',
    'userstorage',
    'zone',
    'usertype',
    'servicetype',
    'servicestatus',
    'account',
    'services',
    'consumeIntake',
];
// Rutas de las API
foreach ($apiModels as $apiModel) {
    $router->get("/api/{$apiModel}", [APIController::class, $apiModel]);
}
// Resolución de la ruta
$router->resolve();
