<div class="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"></div>
<div class="bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"></div>
<div class="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"></div>
<div class="bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300"></div>