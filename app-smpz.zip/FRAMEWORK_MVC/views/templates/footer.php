<footer class="text-center text-sm font-semibold text-neutral-base mt-20 uppercase">
    <p>Todos los derechos reservados &copy; <?= date('Y') ?></p>
</footer>