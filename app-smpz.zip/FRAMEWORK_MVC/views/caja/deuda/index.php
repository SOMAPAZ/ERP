<article class="mx-auto max-w-screen-lg px-4 2xl:px-0">
    <div id="datos-usuario"></div>
    <div id="radio_inputs" class="grid selection:sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 mt-6"></div>
    <div id="deuda-usuario" class="grid sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-6"></div>
    <div id="boton" class="mt-6 flex"></div>
</article>