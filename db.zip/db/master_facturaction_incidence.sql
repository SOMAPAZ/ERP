-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: master_facturaction
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `incidence`
--

DROP TABLE IF EXISTS `incidence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `incidence` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(124) DEFAULT NULL,
  `id_category` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `inc_id_cat_fk` (`id_category`),
  CONSTRAINT `inc_id_cat_fk` FOREIGN KEY (`id_category`) REFERENCES `category` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `incidence`
--

LOCK TABLES `incidence` WRITE;
/*!40000 ALTER TABLE `incidence` DISABLE KEYS */;
INSERT INTO `incidence` VALUES (1,'Fuga',1),(2,'Azolve',1),(3,'Nueva toma ó medidor',1),(4,'Poca presión',1),(5,'Sin servicio',1),(6,'Rehubicación de toma',1),(7,'Reconexión',1),(8,'Agua Turbia',1),(9,'Desperdicio',1),(10,'Suspensión',1),(11,'Reparación',1),(12,'Suspención voluntaria',1),(13,'Reconexión voluntaria',1),(14,'Suministro Tinaco/Pipa',1),(15,'Fuga',2),(16,'Mal olor',2),(17,'Azolve',2),(18,'Reconexión',2),(19,'Nueva toma',2),(20,'Suspensión',2),(21,'Reparación',2),(22,'Limpieza',2),(23,'Ampliación y mantenimiento en la red sanitaria',2),(24,'Fuga en calle',3),(25,'Hundimiento',3),(26,'Roptura de concreto',3),(27,'Suavizamiento',3),(28,'Limpieza',3),(29,'Rehubicación de tuberia',3),(30,'Alcantarilla',3),(31,'Registro',3),(32,'Ampliación y mantenimiento en la red hidraúlica',3),(33,'Inspección de tarifa',4),(34,'Inspección de infraestructura',4),(35,'Inspección de adeudo',4),(36,'Detección de uso',4),(37,'Inspección sanitaria',4),(38,'Verificación especial',4),(39,'Factibilidad',4),(40,'Clandestina',1);
/*!40000 ALTER TABLE `incidence` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-28 11:52:14
