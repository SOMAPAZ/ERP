-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: master_facturaction
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employments`
--

DROP TABLE IF EXISTS `employments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employments` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(24) COLLATE utf8mb4_general_ci NOT NULL,
  `lastname` varchar(48) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `mail` varchar(48) COLLATE utf8mb4_general_ci NOT NULL,
  `phone` varchar(10) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `password` char(60) COLLATE utf8mb4_general_ci NOT NULL,
  `id_rol` bigint DEFAULT NULL,
  `token` varchar(13) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `validado` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_rol` (`id_rol`),
  CONSTRAINT `employments_ibfk_1` FOREIGN KEY (`id_rol`) REFERENCES `roles` (`id`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employments`
--

LOCK TABLES `employments` WRITE;
/*!40000 ALTER TABLE `employments` DISABLE KEYS */;
INSERT INTO `employments` VALUES (1,'Juan Bernardo','Amador González','j_b182@hotmail.com','2225070410','$2y$04$/khFCFkAZ7bKaaexw5ZqVutZ8517TbwpWNd40q8LJ4VwcNKPLG1Uy',1,'',1),(2,'Arnoldo','Felix Xocota','fexarnol@gmail.com','2331467525','$2y$04$WoCsPjQmUpmjgSkQH7cdee6NUBU31sM6to.FNgp6pQQU0Zqu8sU9.',2,'',1),(3,'Fernando','Sosa Bonilla','fernando@somapaz.spz','2222386034','$2y$04$BwSv1MvnkWgJ2YU9BYvgduCiLV7eM322H6o4ww/gFbLZnYDq0jv1i',4,'',1),(4,'Beatriz','Rodríguez','beatriz@somapaz.spz','2331536875','$2y$04$rvltzjG13pnOhmjVrdztA..kzWuvPAcxzwYAxTzeKQ/AMksgIuqlu',6,'',1),(5,'Araceli','Morales','aracelimcas@gmail.com','2331233415','$2y$04$HRT8o.PFcMrE3fWcx6vI6elEGjGeMRdygWgIKFrPMQqMbdibQfwBy',4,'',1),(6,'Carlos','Cabrera','carloscabreracarreon@gmail.com','2331258972','$2y$10$g3Lbo.uHmrDRp6X9b1TNwOi64wruRUmYEqfvh1jeewl4uxtMRs4X6',3,'',1),(8,'Mario Alexis','Vázquez','mario@somapaz.spz','2331343478','$2y$04$1FTslRCwY7ZdewvBT7OWU.MLM6AmmRmUaNvQ9xf.Fhaf1urI.XaZi',3,'',1),(9,'Emilio','Bonilla','somapaz.operacion@gmail.com','2331164774','$2y$04$QRV5vzU3vXswbIRO3ZdDbOa1rqayQnHmZKE1gxKeKGOzBNsUQXZCG',4,'',1),(10,'Araceli','Castillo','aracelimcas@gmail.com','2331233415','$2y$04$xJiNlGJgCD0UbNJHM7ufCe.Fu4B44KJtuYQnhRCH4kterceZWVYy2',4,NULL,1),(11,'Cesar Azarí','García Vázquez','cesafage06@gmail.com','5655100017','$2y$04$638m4Nh58k0Vs6zzHF6sseJGRfNtu1ZBlU3jYKxoi3kYnJniSN2za',2,'',1),(12,'Maria Fernanda','González Palafox','laimafe@hotmail.com','2224949789','$2y$04$ZiMCKUxBYRItXKBshZrN6.zU2E697E1cIHnp6ld7/euGPjhpukPJW',4,'',1),(15,'Miguel','Encarnación','encarnacionpolvomiguel@gmail.com','2331266804','$2y$04$s7cpn.xl3FSafqw8Wwcagu0nnAZ37wjDYFqhZJhYX0xtl2ZUI7CWu',6,'',1),(16,'Raúl','Portillo','portilloraul375@gmail.com','0987654321','$2y$04$tgLT.LSB3V1g.BaewnuJjuXimFIulaTx4s8htyYLQ2sDy3aAydUmG',6,'',1),(17,'Lidia','Cordova','lidia@somapaz.com','2331157097','$2y$04$J0P2LxwFMJoChuxa9GAif.gGkUWdvha83P.U5jTuYJf0X0Et.CH.6',6,'',1);
/*!40000 ALTER TABLE `employments` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-28 11:52:21
