-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: master_facturaction
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `zone`
--

DROP TABLE IF EXISTS `zone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `zone` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(240) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zone`
--

LOCK TABLES `zone` WRITE;
/*!40000 ALTER TABLE `zone` DISABLE KEYS */;
INSERT INTO `zone` VALUES (1,'Sin definir'),(2,'4 de Octubre'),(3,'Alonso Luque'),(4,'Andador el Centro Escolar'),(5,'Atehuetzian'),(6,'Av. 16 de septiembre Norte'),(7,'Av. 16 de septiembre Sur'),(8,'Av. 2 de Abril Norte'),(9,'Av. 2 de Abril Sur'),(10,'Av. 5 de Mayo Norte'),(11,'Av. 5 de Mayo Sur'),(12,'Avenida 12 de octubre'),(13,'Ayoco'),(14,'Brigadier Lobato'),(15,'Calcahualco'),(16,'Calle Abraham Sosa'),(17,'Carlos I Betancourt'),(18,'Carretera a Cuetzalan'),(19,'Carretera a Zaragoza'),(20,'Carril Jose Maria Sosa'),(21,'Colonia Independencia'),(22,'Comaltepec'),(23,'Concordia'),(24,'Constantino Molina'),(25,'Constitución'),(26,'Corregidora'),(27,'Cuauhtemoc'),(28,'Direcciones Varias'),(29,'El Fortin'),(30,'El Fresno'),(31,'El Pensador Mexicano'),(32,'El Porvenir'),(33,'F.J Arriaga'),(34,'Fray Bartolome de las Casas'),(35,'Galeana'),(36,'Guillermo Prieto'),(37,'Ignacio Alatorre'),(38,'Ignacio Coeto'),(39,'Independencia'),(40,'Ixticpac'),(41,'J.M. Alcantara'),(42,'J.S Verduzco'),(43,'Juan de Dios Peza'),(44,'La Calzada 25 de Abril'),(45,'La Cañada'),(46,'Lavaderos'),(47,'Leona Vicario'),(48,'Los Arcos'),(49,'Los Pinos'),(50,'Los Reyes'),(51,'Matamoros'),(52,'Mercado 25 de Abril'),(53,'Miguel Negrete'),(54,'Mina'),(55,'Ocotitan'),(56,'Pattoni'),(57,'Puente Colorado'),(58,'Rivapalacio'),(59,'Tatoxcac'),(60,'Teacalco'),(61,'Texpilco'),(62,'Tlalconteno'),(63,'Xaltetela'),(64,'Xalticpac'),(65,'Xoxpan'),(66,'Centro'),(67,'Los Rosales'),(68,'Bachilleres'),(69,'La Cortadura'),(70,'Abraham Sosa'),(71,'Del Artista'),(72,'5 de Febrero'),(73,'La Calzada 2 de Abril'),(74,'Acuesco'),(75,'Insurgentes'),(76,'Libramiento Oriente'),(77,'Los Alcatraces'),(78,'Mariano Arista'),(79,'Libramiento Poniente');
/*!40000 ALTER TABLE `zone` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-28 11:52:16
